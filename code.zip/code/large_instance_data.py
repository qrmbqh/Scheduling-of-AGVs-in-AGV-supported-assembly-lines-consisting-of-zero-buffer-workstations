from datetime import datetime
# performance evaluate

# import GurobiWithStatus as GSLS
# import GurobiWithoutStatus as GS
import newCBSwithLNSdr as CBS
# import CBSWithStatus as CBSWS
import benchmarkWithoutStatus as BM
import GurobiWithoutStatus as G
# import benchmarkWithStatus as BMWS
# import numpy as np
import random
import csv
import s2str
import randomGenerator as rg

def new_performance(wcc, vc, pc, low_d, up_d, h, low_s, up_s, count, fileName):
    for i in range(count):
        s = rg.random_nums(wcc, low_s, up_s)
        d = rg.random_nums(wcc-1, low_d,up_d)
        try:
            # t1 = time.perf_counter()
            print(str(i+1)+"th")
            best_obj, best_bound, optimal_gap, t_consumed = G.newAGVSchedul(vc, pc, wcc, s, d, h,t_limited=3600)
            cbs = CBS.CBS(wcc, pc, vc, s, d, h)
            cbs_makespan, cbs_makespan_t = cbs.CBS_NL(3, 3)
            solver = CBS.SegmentLNSMILP(
                w=wcc, p=pc, v=vc, s=s, d=d, h=h,
                Imax=200,  # 执行多少次破坏和修复
                Ld=4,  # 破坏长度，破坏多少个节点
                K=6,  # 每步从备选的最优分配方案中挑选多少个进行测试
                rollout_depth=0,
                accept_worse=False,
                seed=random.randint(0, 100),
                use_new_find=True
            )
            ms_best, trace_best, tcost = solver.run()
            benchmark = BM.Benchmarks(wcc, pc, vc, s, d, h)
            STT_makespan, STT_makespan_t = benchmark.STT_Rule()
            # print('SST:', STT_makespan, STT_makespan_t)
            benchmark = BM.Benchmarks(wcc, pc, vc, s, d, h)
            EDD_makespan, EDD_makespan_t = benchmark.EDD_Rule()
            # print('EDD:', EDD_makespan, EDD_makespan_t)
            benchmark = BM.Benchmarks(wcc, pc, vc, s, d, h)
            SI_makespan, SI_makespan_t = benchmark.SI_Rule()
            # print('SI:', SI_makespan, SI_makespan_t)
            benchmark = BM.Benchmarks(wcc, pc, vc, s, d, h)
            rSI_makespan, rSI_makespan_t = benchmark.rSI_Rule()
            # print('rSI:', rSI_makespan, rSI_makespan_t)
            benchmark = BM.Benchmarks(wcc, pc, vc, s, d, h)
            EP_makespan, EP_makespan_t = benchmark.Enterprise()
            # print('EP:', EP_makespan, EP_makespan_t)
        except Exception as E_results:
            print("捕捉有异常：",E_results)
            f = open(fileName,'a',newline='')
            writer = csv.writer(f)
            writer.writerow([ vc,
                              pc,
                              wcc,
                              pc*wcc,
                              low_s, up_s,
                              s2str.list2str(s),
                              low_d, up_d,
                              s2str.list2str(d),
                              h
                              ])
            f.close()
        else:
            f = open(fileName,'a',newline='')
            writer = csv.writer(f)
            writer.writerow([ vc,
                              pc,
                              wcc,
                              pc*wcc,
                              low_s, up_s,
                              s2str.list2str(s),
                              low_d, up_d,
                              s2str.list2str(d),
                              h,
                              best_obj, best_bound, optimal_gap, t_consumed,
                              cbs_makespan, cbs_makespan_t,
                              STT_makespan, STT_makespan_t, EDD_makespan, EDD_makespan_t, SI_makespan, SI_makespan_t, rSI_makespan, rSI_makespan_t,
                              EP_makespan, EP_makespan_t,
                              ms_best,tcost
                              ])
            f.close()
    return

WP = [(10,13),(15,10),(15,12),(15,13)]
V = [3,4,5]
D = [(6,14)]
S = [(5,10),(10,15),(15,20),(20,25)]
H = 1
count = 20
total = count*len(D)*len(S)*len(WP)*len(V)
actual = total
current_date = datetime.now().date()
date_str = current_date.strftime('%Y-%m-%d')
#date_str = '2025-09-28'
fileName = 'large_instance_data'+date_str+'.csv'
f = open(fileName,'a',newline='')
writer = csv.writer(f)
writer.writerow([ 'vc',
                  'pc',
                  'wcc',
                  'taskcount',
                  'low_s', 'up_s',
                  'S',
                  'low_d','up_d',
                  'D',
                  'h',
                  'best_obj', 'best_bound', 'optimal_gap', 't_consumed',
                  'cbs_makespan', 'cbs_makespan_t',
                  'STT_makespan', 'STT_makespan_t', 'EDD_makespan', 'EDD_makespan_t', 'SI_makespan', 'SI_makespan_t', 'rSI_makespan', 'rSI_makespan_t',
                  'EP_makespan', 'EP_makespan_t',
                  'Segment-LNS-MILP_ms','Segment-LNS-MILP_t'
                  ])
f.close()
for wcc, pc in WP:
    for vc in V:
        for low_d, up_d in D:
            for low_s, up_s in S:
                new_performance(wcc,vc,pc,low_d,up_d,H,low_s,up_s,count,fileName)
                actual -= count
                print('Progress: {:.2%}'.format(1-actual/total))