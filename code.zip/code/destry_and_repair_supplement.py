# -*- coding: utf-8 -*-
"""
Created on Fri Mar  6 21:09:11 2026

@author: lenovo
"""

import pandas as pd
import numpy as np
import GurobiWithoutStatus as G
# from tqdm import tqdm
import CBSWithoutStatus as CBS
import destry_and_repair as DR

def parse_numbers(s: str):
    """
    将形如 '7,5,10,5,10,8,7,6,6,' 的字符串解析为整数列表
    """
    # 去掉首尾逗号后 split，再过滤掉空字符串
    return [int(x) for x in s.strip(",").split(",") if x]

df = pd.read_excel('补充.xlsx',sheet_name='Sheet1')

for idx, row in df.iterrows():
    vc, pc, wcc, s, d, h = row['vc'], row['pc'], row['wcc'], parse_numbers(row['S']), parse_numbers(row['D']), row['h']
    DR.setGlobalParam(wcc, pc, vc, s, d, h)
    obj = None
    while not obj:
        try:
            obj,_,t = DR.repair_time_percent(50, 0.25)
        except:
            obj = None
    # cbs = CBS.CBS(wcc, pc, wcc, s, d, h)
    # cbs_makespan, cbs_makespan_t = cbs.CBS_NL(3, 3)
    df.loc[idx, "obj_dr"] = obj
    df.loc[idx, "t_dr"] = t
    df.to_csv('补充后.csv')
    print(f"{idx} over!")