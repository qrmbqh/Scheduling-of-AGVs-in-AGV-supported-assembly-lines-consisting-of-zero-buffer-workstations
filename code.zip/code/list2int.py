# -*- coding: utf-8 -*-
"""
Created on Sat Oct 15 21:06:26 2022

@author: qrmbqh
"""

y ='1,8,5,3,3,6,10,'

def list2int(x):
    res = []
    s = ""
    for c in x:
        if c != ',':
            s += c
        else:
            res.append(int(s))
            s = ""
    return res

if __name__ == "__main__":
    print(list2int(y))