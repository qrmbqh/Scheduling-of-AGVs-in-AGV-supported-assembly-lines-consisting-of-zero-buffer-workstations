# -*- coding: utf-8 -*-
"""
Created on Tue Dec  2 00:50:50 2025

@author: DELL
"""
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

df = pd.read_excel('operation_2026_03_06.xlsx',sheet_name='Sheet1')
data = {}
grouped = df.groupby('scale')
# data['size'] = grouped['pw']
data['asp']=grouped['tag_asp'].sum()
data['aspr']=grouped['tag_aspr'].sum()
data['rasp']=grouped['tag_rasp'].sum()
data['vrptw']=grouped['tag_vrptw'].sum()
data['vrptwr']=grouped['tag_vrptwr'].sum()

data['size']=grouped.size()

data['asp_rate'] = data['asp']/data['size']
data['aspr_rate'] = data['aspr']/data['size']
data['rasp_rate'] = data['rasp']/data['size']
data['vrptw_rate'] = data['vrptw']/data['size']
data['vrptwr_rate'] = data['vrptwr']/data['size']

# plt.rcParams['font.sans-serif'] = ['Times new roman']  # 黑体
# plt.rcParams['axes.unicode_minus'] = False

plt.rcParams['font.sans-serif'] = ['SimHei']  # 使用黑体显示中文
plt.rcParams['axes.unicode_minus'] = False    # 解决负号显示问题
plt.rcParams['font.size']=14

plt.figure(figsize=(9,5), dpi=600)
line1, = plt.plot(data['asp_rate'].index, data['asp_rate'].values, marker = 's',linewidth = 2, label = 'ASP')
line2, = plt.plot(data['aspr_rate'].index, data['aspr_rate'].values, marker = 'o', linewidth = 2,label = 'ASPwR')
line3, = plt.plot(data['rasp_rate'].index, data['rasp_rate'].values, marker = 'o', linewidth = 2,label = 'RASP')
line4, = plt.plot(data['vrptw_rate'].index, data['vrptw_rate'].values, marker = '^',linewidth = 2, label = 'VRPTW')
line5, = plt.plot(data['vrptwr_rate'].index, data['vrptwr_rate'].values, marker = 'v', linewidth = 2,label = 'VRPTWwR')
# ─────────────── 1. 设置 y 轴为百分比显示 ───────────────
plt.gca().yaxis.set_major_formatter(FuncFormatter(lambda y, _: f'{y*100:.0f}%'))
# 选项：
# ·:.0f → 整数百分比（如 75%）
# ·:.1f → 保留1位小数（如 75.2%）
# 根据你的成功率精度选择，建议用 :.1f 或 :.0f

# 可选：设置 y 轴范围（让图看起来更合适）
# plt.ylim(0, 1.05)           # 0% ~ 105%，留一点顶部空间给标注
# ─────────────── 新增：为每条线的最后一个点标注数值 ───────────────
lines = [line1, line2, line3, line4, line5]
labels = ['ASP', 'ASPwR', 'RASP', 'VRPTW', 'VRPTWwR']
offset_x = 1.5          # 向右偏移一点（避免盖住点）
offset_y = 0.005        # 轻微向上偏移（根据你的y轴范围可调，0.005≈0.5%）

for line, label in zip(lines, labels):
    # 取最后一个点
    x_last = line.get_xdata()[-1]
    y_last = line.get_ydata()[-1]
    
    # 格式化显示：保留3位小数（可改成2位：:.2f）
    # text = f"{y_last:.3f}"
    text = f"{y_last*100:.2f}%"
    plt.text(
        x_last - offset_x,
        y_last + offset_y,
        text,
        fontsize=11,
        fontweight='bold',
        color=line.get_color(),      # 与折线同色
        ha='left',                   # 左对齐
        va='bottom'                  # 从底部开始向上
    )
plt.legend(handles=[line5, line4, line3,line2,line1],loc='center left')
plt.xlabel('任务/客户数量')
plt.ylabel('成功率')
# plt.xlabel('Number of tasks/customers')
# plt.ylabel('Success rate')
# plt.legend(loc='best')