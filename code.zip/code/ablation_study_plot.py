# -*- coding: utf-8 -*-
"""
Created on Sat Sep 27 14:53:33 2025

@author: DELL
"""

import CBSWithoutStatus as C
import random 
from datetime import datetime
import csv
import s2str
from tqdm import tqdm

current_date = datetime.now()
date_str = current_date.strftime('%Y-%m-%d')
current_date = datetime.now().date()
date_str = current_date.strftime('%Y-%m-%d')
fileName = 'ablation study seed 2'+date_str+'.csv'
f = open(fileName,'a',newline='')
writer = csv.writer(f)
writer.writerow([ 'v','p','w','taskcount','s','d','h','l',
                  'makespan_n', 'makespan_nl'
                  ])
f.close()

h= 1
for l in tqdm([3,5,7,9,11,13], ncols = 100):
    count = 0
    while count < 10:
        # w = random.randint(6, 9)
        # p = random.randint(w, w+2)
        w = 9
        p = 10
        # v = random.randint(2, 4)
        v = 4
        s= [random.randint(2, 20) for _ in range(w)]
        d = [random.randint(2, 10) for _ in range(w-1)]
        m = C.CBS(w, p, v, s, d, h)
        makespan_nl,t= m.CBS_NL(3,l)#对比有没有seed池子的影响
        makespan_n,t= m.CBS_N(3)
        if makespan_nl != makespan_n:
            f = open(fileName,'a',newline='')
            writer = csv.writer(f)
            writer.writerow([ v,p,w,p*w,s2str.list2str(s),s2str.list2str(d),h,l,
                              makespan_n, makespan_nl
                              ])
            f.close()
            count += 1
            print(f'{count} got!')