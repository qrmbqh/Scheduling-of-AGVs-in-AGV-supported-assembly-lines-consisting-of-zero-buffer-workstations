# -*- coding: utf-8 -*-
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Tuple, List
import math
import gurobipy as gp
from gurobipy import GRB
import getSolomonSolutions as gss
import math
from typing import List, Tuple
import neighbourhood_feasible_test as NB
import timeSceduling as ts
@dataclass
class VRPTWInstance:
    name: str
    m: int
    Q: int
    n: int                 # customers are 1..n, depot start=0, depot end=n+1
    x: Dict[int, float]
    y: Dict[int, float]
    demand: Dict[int, float]
    ready: Dict[int, float]
    due: Dict[int, float]
    service: Dict[int, float]


def read_solomon(path: str) -> VRPTWInstance:
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        lines = [ln.rstrip("\n") for ln in f]

    name = next((ln.strip() for ln in lines if ln.strip()), "instance")

    m = Q = None
    for i, ln in enumerate(lines):
        if "NUMBER" in ln and "CAPACITY" in ln:
            j = i + 1
            while j < len(lines) and not lines[j].strip():
                j += 1
            parts = lines[j].split()
            m, Q = int(parts[0]), int(parts[1])
            break
    if m is None or Q is None:
        raise ValueError("Failed to parse VEHICLE NUMBER/CAPACITY.")

    start_idx = None
    for i, ln in enumerate(lines):
        s = ln.strip()
        if s and s.split()[0].isdigit() and s.split()[0] == "0":
            start_idx = i
            break
    if start_idx is None:
        raise ValueError("Failed to find CUSTOMER table start (depot row).")

    xcoord: Dict[int, float] = {}
    ycoord: Dict[int, float] = {}
    demand: Dict[int, float] = {}
    ready: Dict[int, float] = {}
    due: Dict[int, float] = {}
    service: Dict[int, float] = {}

    for ln in lines[start_idx:]:
        s = ln.strip()
        if not s:
            continue
        parts = s.split()
        if not parts[0].isdigit() or len(parts) < 7:
            continue
        i = int(parts[0])
        xcoord[i] = float(parts[1])
        ycoord[i] = float(parts[2])
        demand[i] = float(parts[3])
        ready[i] = float(parts[4])
        due[i] = float(parts[5])
        service[i] = float(parts[6])

    if 0 not in xcoord:
        raise ValueError("Depot (0) missing.")

    n = max(k for k in xcoord.keys() if k != 0)  # customers are 1..n

    # Create end-depot node n+1 (same as depot 0)
    end = n + 1
    xcoord[end] = xcoord[0]
    ycoord[end] = ycoord[0]
    demand[end] = 0.0
    ready[end] = ready[0]
    due[end] = due[0]
    service[end] = 0.0

    return VRPTWInstance(
        name=name, m=m, Q=Q, n=n,
        x=xcoord, y=ycoord,
        demand=demand, ready=ready, due=due, service=service
    )


from dataclasses import dataclass
import random


@dataclass
class VRPTWInstance:
    name: str
    m: int
    Q: int
    n: int                 # customers are 1..n, depot start=0, depot end=n+1
    x: Dict[int, float]
    y: Dict[int, float]
    demand: Dict[int, float]
    ready: Dict[int, float]
    due: Dict[int, float]
    service: Dict[int, float]
    customers:List


def read_solomon_subset(path: str, n: int, seed: int = 0) -> VRPTWInstance:
    """
    Read a Solomon instance and randomly select n customers (excluding depot).
    Depot (0) is always kept. Selected customers are reindexed to 1..n.
    End-depot is added as node n+1 (same as depot).

    Args:
        path: file path
        n: number of customers to keep
        seed: RNG seed for reproducibility
    """
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        lines = [ln.rstrip("\n") for ln in f]

    name = next((ln.strip() for ln in lines if ln.strip()), "instance")

    # parse VEHICLE
    m = Q = None
    for i, ln in enumerate(lines):
        if "NUMBER" in ln and "CAPACITY" in ln:
            j = i + 1
            while j < len(lines) and not lines[j].strip():
                j += 1
            parts = lines[j].split()
            m, Q = int(parts[0]), int(parts[1])
            break
    if m is None or Q is None:
        raise ValueError("Failed to parse VEHICLE NUMBER/CAPACITY.")

    # find customer table start (depot row)
    start_idx = None
    for i, ln in enumerate(lines):
        s = ln.strip()
        if s and s.split()[0].isdigit() and s.split()[0] == "0":
            start_idx = i
            break
    if start_idx is None:
        raise ValueError("Failed to find CUSTOMER table start (depot row).")

    # read all rows first
    x_all: Dict[int, float] = {}
    y_all: Dict[int, float] = {}
    demand_all: Dict[int, float] = {}
    ready_all: Dict[int, float] = {}
    due_all: Dict[int, float] = {}
    service_all: Dict[int, float] = {}

    for ln in lines[start_idx:]:
        s = ln.strip()
        if not s:
            continue
        parts = s.split()
        if not parts[0].isdigit() or len(parts) < 7:
            continue
        idx = int(parts[0])
        x_all[idx] = float(parts[1])
        y_all[idx] = float(parts[2])
        demand_all[idx] = float(parts[3])
        ready_all[idx] = float(parts[4])
        due_all[idx] = float(parts[5])
        service_all[idx] = float(parts[6])

    if 0 not in x_all:
        raise ValueError("Depot (0) missing in the file.")

    # candidate customers (exclude depot)
    all_customers = sorted([i for i in x_all.keys() if i != 0])
    N_all = len(all_customers)
    if n <= 0:
        raise ValueError("n must be positive.")
    if n > N_all:
        raise ValueError(f"n={n} exceeds available customers {N_all} in file.")

    rng = random.Random()
    chosen = sorted(rng.sample(all_customers, n))  # keep sorted for stability

    # reindex: depot stays 0; chosen customers become 1..n
    # mapping old_id -> new_id
    mapping = {old: new for new, old in enumerate(chosen, start=1)}

    x: Dict[int, float] = {0: x_all[0]}
    y: Dict[int, float] = {0: y_all[0]}
    demand: Dict[int, float] = {0: 0.0}
    ready: Dict[int, float] = {0: ready_all[0]}
    due: Dict[int, float] = {0: due_all[0]}
    service: Dict[int, float] = {0: service_all[0]}

    for old_id, new_id in mapping.items():
        x[new_id] = x_all[old_id]
        y[new_id] = y_all[old_id]
        demand[new_id] = demand_all[old_id]
        ready[new_id] = ready_all[old_id]
        due[new_id] = due_all[old_id]
        service[new_id] = service_all[old_id]

    # add end-depot node n+1 (same as depot 0)
    end = n + 1
    x[end] = x[0]
    y[end] = y[0]
    demand[end] = 0.0
    ready[end] = ready[0]
    due[end] = due[0]
    service[end] = 0.0

    return VRPTWInstance(
        name=f"{name.lower()}",
        m=m, Q=Q, n=n,
        x=x, y=y,
        demand=demand, ready=ready, due=due, service=service, customers=chosen
    )

def build_distance(inst: VRPTWInstance) -> Dict[Tuple[int, int], float]:
    start = 0
    end = inst.n + 1
    nodes = list(range(0, inst.n + 2))  # 0..n+1
    dist = {}
    for i in nodes:
        for j in nodes:
            dx = inst.x[i] - inst.x[j]
            dy = inst.y[i] - inst.y[j]
            dist[(i, j)] = math.hypot(dx, dy)
    return dist


def solve_vrptw(inst: VRPTWInstance, time_limit=300.0, mip_gap=1e-4):
    start = 0
    end = inst.n + 1
    customers = list(range(1, inst.n + 1))
    nodes = list(range(0, inst.n + 2))  # 0..n+1
    K = list(range(inst.m))

    dist = build_distance(inst)

    max_due = max(inst.due[i] for i in nodes)
    max_dist = max(dist.values())
    M_time = max_due + max_dist + max(inst.service.values())
    M_load = inst.Q + max(inst.demand.values())

    model = gp.Model(f"VRPTW_{inst.name}")
    model.setParam(GRB.Param.TimeLimit, time_limit)
    model.setParam(GRB.Param.MIPGap, mip_gap)

    # Only allow arcs consistent with start/end depots:
    # - no arcs into start
    # - no arcs out of end
    allowed_arcs = []
    for i in nodes:
        for j in nodes:
            if i == j:
                continue
            if j == start:
                continue
            if i == end:
                continue
            # disallow direct start->end if you want at least one customer when y[k]=1
            allowed_arcs.append((i, j))

    x = model.addVars(allowed_arcs, K, vtype=GRB.BINARY, name="x")
    t = model.addVars(nodes, K, vtype=GRB.CONTINUOUS, lb=0.0, name="t")
    load = model.addVars(nodes, K, vtype=GRB.CONTINUOUS, lb=0.0, ub=inst.Q, name="load")
    y = model.addVars(K, vtype=GRB.BINARY, name="y")

    # Each customer visited exactly once
    model.addConstrs(
        (gp.quicksum(x[i, j, k] for k in K for (i, jj) in allowed_arcs if jj == j) == 1
         for j in customers),
        name="visit_once"
    )

    # If vehicle used: exactly one arc leaves start, exactly one arc enters end
    model.addConstrs(
        (gp.quicksum(x[start, j, k] for (i, j) in allowed_arcs if i == start) == y[k]
         for k in K),
        name="start_out"
    )
    model.addConstrs(
        (gp.quicksum(x[i, end, k] for (i, j) in allowed_arcs if j == end) == y[k]
         for k in K),
        name="end_in"
    )

    # Flow conservation on customers for each vehicle
    for k in K:
        for j in customers:
            in_j = gp.quicksum(x[i, j, k] for (i, jj) in allowed_arcs if jj == j)
            out_j = gp.quicksum(x[j, h, k] for (ii, h) in allowed_arcs if ii == j)
            model.addConstr(in_j == out_j, name=f"flow[{j},{k}]")

    # Time windows (bind only if visited by k)
    for k in K:
        # start depot time can be set to its ready time (often 0)
        model.addConstr(t[start, k] >= inst.ready[start], name=f"tw_start_lb[{k}]")
        model.addConstr(t[start, k] <= inst.due[start],   name=f"tw_start_ub[{k}]")
        # end depot should also be within depot window if needed
        model.addConstr(t[end, k] >= inst.ready[end] - M_time * (1 - y[k]), name=f"tw_end_lb[{k}]")
        model.addConstr(t[end, k] <= inst.due[end]   + M_time * (1 - y[k]), name=f"tw_end_ub[{k}]")

        for j in customers:
            visit_jk = gp.quicksum(x[i, j, k] for (i, jj) in allowed_arcs if jj == j)
            model.addConstr(t[j, k] >= inst.ready[j] - M_time * (1 - visit_jk), name=f"tw_lb[{j},{k}]")
            model.addConstr(t[j, k] <= inst.due[j]   + M_time * (1 - visit_jk), name=f"tw_ub[{j},{k}]")

    # Time propagation along allowed arcs
    model.addConstrs(
        (t[j, k] >= t[i, k] + inst.service[i] + dist[(i, j)] - M_time * (1 - x[i, j, k])
         for (i, j) in allowed_arcs for k in K),
        name="time_prop"
    )

    # Load: start load = 0
    model.addConstrs((load[start, k] == 0 for k in K), name="load_start")

    # Load lower bound if visited
    for k in K:
        for j in customers:
            visit_jk = gp.quicksum(x[i, j, k] for (i, jj) in allowed_arcs if jj == j)
            model.addConstr(load[j, k] >= inst.demand[j] - M_load * (1 - visit_jk), name=f"load_lb[{j},{k}]")

    # Load propagation for arcs into customers (including from start)
    model.addConstrs(
        (load[j, k] >= load[i, k] + inst.demand[j] - M_load * (1 - x[i, j, k])
         for (i, j) in allowed_arcs for k in K if j in customers),
        name="load_prop"
    )

    # Objective: minimize vehicles then distance
    # big_weight = 1e5
    total_dist = gp.quicksum(dist[(i, j)] * x[i, j, k] for (i, j) in allowed_arcs for k in K)
    # total_veh = gp.quicksum(y[k] for k in K)
    model.setObjective(total_dist, GRB.MINIMIZE)

    model.optimize()

    if model.Status not in (GRB.OPTIMAL, GRB.TIME_LIMIT, GRB.SUBOPTIMAL):
        raise RuntimeError(f"Optimization ended with status {model.Status}")

    # Extract routes
    solx = model.getAttr("X", x)
    routes = []
    for k in K:
        if y[k].X < 0.5:
            continue
        route = [start]
        cur = start
        while cur != end:
            nxt = None
            for (i, j) in allowed_arcs:
                if i == cur and solx[i, j, k] > 0.5:
                    nxt = j
                    break
            if nxt is None:
                break
            route.append(nxt)
            cur = nxt
        routes.append((k, route))

    used = sum(1 for k in K if y[k].X > 0.5)
    dist_val = sum(dist[(i, j)] * solx[i, j, k] for (i, j) in allowed_arcs for k in K)
    return {"status": model.Status, "vehicles_used": used, "total_distance": dist_val, "routes": routes}

def getInitialSolutionObj(instance, v_num, customs_selected):
    routes = gss.getSolutionFromFileBySet(instance, v_num, customs_selected)
    return routes

def total_path_length(paths: List[List[Tuple[float, float]]]) -> float:
    """
    Compute the sum of lengths of all paths.
    Each path is a list of (x, y) coordinates; consecutive points are connected by straight lines.
    """
    total = 0.0
    for path in paths:
        if not path or len(path) < 2:
            continue
        for (x1, y1), (x2, y2) in zip(path[:-1], path[1:]):
            total += math.hypot(x2 - x1, y2 - y1)
    return total

import ini_solution as IS
def getOurProbObj():
    _, initial = IS.ini_sol()
    feasible, obj, _,_,_ = NB.evaluation(initial)
    if not feasible:
        raise ValueError("Initial solution infeasible under evaluation.")

    tag_our, obj_our, _, _, _ = NB.evaluation(initial)
    tag_relaxed, obj_relaxed, _, _, _ = NB.evaluation_relaxed(initial)
    tag1, asp = ts.originalProblem()
    tag2,rasp = ts.relaxedProblem()
    return tag_our,obj_our,asp, tag_relaxed,obj_relaxed,rasp
if __name__ == "__main__":
    w = 7
    p=8
    v= random.randint(2, w-1)
    s = [random.randint(3, 10) for _ in range(w)]
    d = [random.randint(2, 5) for _ in range(w-1)]
    h= 1
    ts.setGlobalParam(w, p, v, s, d, h)
    IS.setGlobalParam(w, p, v, s, d, h)
    res1=getOurProbObj()
    
    path = "./VRPTW/c101.txt"
    # inst = read_solomon(path)
    inst = read_solomon_subset(path, n=56, seed=2)
    routes = getInitialSolutionObj(inst.name, inst.m, inst.customers)
    res = solve_vrptw(inst, time_limit=300, mip_gap=1e-4)
    
    total_length = total_path_length(routes)
    print(f'Initial distance = {total_length}')
    print("Optimal distance:", res["total_distance"])
