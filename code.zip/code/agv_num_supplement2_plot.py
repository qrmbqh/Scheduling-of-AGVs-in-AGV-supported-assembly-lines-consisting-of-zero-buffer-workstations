# -*- coding: utf-8 -*-
"""
Created on Wed Feb 25 22:12:00 2026

@author: DELL
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
# ====== 1) 读入Excel ======
infile = r"..\data\agv_num_supplement2.xlsx"
outfile = "with_gain_flag_p.xlsx"

VC_COL = "vc"
S_COL = "S"
MS_COL = "cbs_makespan"   # 如果你的列名不同请修改

# ====== 2) 逐组计算 Gain + 标记 ======
plt.rcParams.update({
    'font.size': 14,  # 字体大小
    'font.family': 'times new roman',  # 字体家族
    'mathtext.fontset': 'stix',  # 让数学公式字体与主字体匹配
})

def process_group(g: pd.DataFrame) -> pd.DataFrame:
    g = g.copy()

    # 同一 vc 多行 -> 用均值（可改成 min/max/first）
    vc2ms = g.groupby(VC_COL)[MS_COL].mean()

    # 如果没有 vc=1 或 vc_max，直接返回
    if 1 not in vc2ms.index:
        g["Gain(%)"] = np.nan
        g["flag"] = 0
        return g

    ms_vc1 = float(vc2ms.loc[1])
    vc_max = int(vc2ms.index.max())
    ms_vcmax = float(vc2ms.loc[vc_max])

    denom = (ms_vc1 - ms_vcmax)
    if abs(denom) < 1e-12:
        g["Gain(%)"] = np.nan
        g["flag"] = 0
        return g

    # 计算 Gain
    ms_this = g[VC_COL].map(vc2ms).astype(float)
    g["Gain(%)"] = (ms_vc1 - ms_this) / denom * 100.0

    # ====== 标记第一次 > 0.9 (90%) ======
    g["flag"] = 0

    # 排序确保是按 vc 从小到大找“第一次”
    g = g.sort_values(VC_COL)

    condition = g["Gain(%)"] > 0.9 * 100  # 因为Gain是百分数

    if condition.any():
        first_index = g[condition].index[0]
        g.loc[first_index, "flag"] = 1

    return g

def dataProcess():
    df = pd.read_excel(infile)
    df = df.groupby(S_COL, group_keys=False).apply(process_group)

    # 保留两位小数
    df["Gain(%)"] = df["Gain(%)"].round(2)

    df.to_excel(outfile, index=False)

    print("Finished. Saved to:", outfile)
    
def getThresholdAgv():
    # 读入已经包含 Gain 和 flag 的文件
    df = pd.read_excel("with_gain_flag_p.xlsx")
    
    PC_COL = "pc"
    VC_COL = "vc"
    
    # 只保留 flag=1 的行
    df_flag = df[df["flag"] == 1]
    
    # 按 pc 分组计算 vc 的平均值
    result = (
        df_flag
        .groupby(PC_COL)[VC_COL]
        .mean()
        .reset_index()
        .rename(columns={VC_COL: "avg_vc_when_flag1"})
    )
    
    print(result)
    plt.figure(figsize=(6,4),dpi=300)
    plt.plot(result[PC_COL], result["avg_vc_when_flag1"], marker='o',linewidth = 3)
    plt.xlabel("$p$")
    plt.ylabel(r"$v$ for achieving 90% gain")#Threshold of achieving 90% gain (v)
    plt.ylim(1, 10)
    plt.grid(True)
    plt.tight_layout()
    # plt.savefig("avg_vc_vs_pc.pdf")
    plt.show()
    # 如需导出
    # result.to_excel("avg_vc_by_pc.xlsx", index=False)

if __name__ == '__main__':
    dataProcess()
    getThresholdAgv()

