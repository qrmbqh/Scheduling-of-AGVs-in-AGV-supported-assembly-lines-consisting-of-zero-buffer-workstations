# -*- coding: utf-8 -*-
"""
Created on Thu Mar  5 17:13:09 2026

@author: DELL
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ====== 1) 配置 ======
infile = r"..\data\agv_num_supplement1.xlsx"
sheet = "数据"

S_COL = "S"
VC_COL = "vc"
MS_COL = "cbs_makespan"

WCC_COL = "wcc"
LOWD_COL = "d/s"

GAIN_COL = "Gain(%)"
FLAG_COL = "flag"
TH_COL = "v_threshold"   # 每个S组对应的阈值vc

GAIN_TARGET = 90.0       # 90%

plt.rcParams.update({
    'font.size': 14,  # 字体大小
    'font.family': 'times new roman',  # 字体家族
    'mathtext.fontset': 'stix',  # 让数学公式字体与主字体匹配
})

# ====== 2) 逐组计算 Gain + 阈值(vc) + flag ======
def process_group(g: pd.DataFrame) -> pd.DataFrame:
    g = g.copy()

    # 同一 vc 多行 -> 用均值（可改成 min/max/first）
    vc2ms = g.groupby(VC_COL)[MS_COL].mean()

    # 缺少 vc=1 或没有其他vc时无法计算
    if 1 not in vc2ms.index or len(vc2ms.index) < 2:
        g[GAIN_COL] = np.nan
        g[FLAG_COL] = 0
        g[TH_COL] = np.nan
        return g

    ms_vc1 = float(vc2ms.loc[1])
    vc_max = int(vc2ms.index.max())
    ms_vcmax = float(vc2ms.loc[vc_max])

    denom = (ms_vc1 - ms_vcmax)
    if abs(denom) < 1e-12:
        g[GAIN_COL] = np.nan
        g[FLAG_COL] = 0
        g[TH_COL] = np.nan
        return g

    # 计算每行对应vc的Gain（用聚合后的makespan）
    ms_this = g[VC_COL].map(vc2ms).astype(float)
    g[GAIN_COL] = (ms_vc1 - ms_this) / denom * 100.0

    # ------- 阈值：最小vc使得 Gain >= 90% -------
    g[FLAG_COL] = 0

    # 为了找“最小vc”，按vc排序；如果你要“按原始顺序第一次”，删掉下一行
    g = g.sort_values(VC_COL)

    meets = g[GAIN_COL] >= GAIN_TARGET
    if meets.any():
        # 这行对应的vc就是阈值（最小vc满足Gain>=90）
        first_idx = g[meets].index[0]
        g.loc[first_idx, FLAG_COL] = 1
        g[TH_COL] = g.loc[first_idx, VC_COL]  # 给组内所有行都填同一个阈值，方便后面汇总
    else:
        g[TH_COL] = np.nan

    return g

def dataProcess():
    df = pd.read_excel(infile, sheet_name=sheet)

    # 先按S分组处理
    df = df.groupby(S_COL, group_keys=False).apply(process_group)

    df[GAIN_COL] = df[GAIN_COL].round(2)

    # 保存含Gain/flag/阈值的明细
    df.to_excel("with_gain_flag.xlsx", index=False)
    return df

def getThresholdByWccLowd(df: pd.DataFrame):
    """
    目标：分别统计不同 (wcc, d/s) 下阈值vc的统计量
    """
    # 每个S组的阈值vc（取flag=1那一行即可；或用TH_COL去重也行）
    th = df[df[FLAG_COL] == 1].copy()

    # 如果一个S组理论上只会有1个flag=1；这里再保险一下
    th = th.drop_duplicates(subset=[S_COL])

    # 按 (wcc, low_d) 汇总阈值vc
    summary = (
        th.groupby([WCC_COL, LOWD_COL])[VC_COL]
          .agg(avg_v_threshold="mean", median_v_threshold="median",
               min_v_threshold="min", max_v_threshold="max",
               std_v_threshold="std", count="count")
          .reset_index()
          .sort_values([WCC_COL, LOWD_COL])
    )

    print(summary)
    summary.to_excel("threshold_v_by_wcc_lowd.xlsx", index=False)
    return summary

def plotThreshold(summary: pd.DataFrame):
    """
    画图方式：对每个wcc画一条线，横轴low_d，纵轴平均阈值vc
    """
    plt.figure(figsize=(6,4), dpi=300)

    for wcc, g in summary.groupby(WCC_COL):
        g = g.sort_values(LOWD_COL)
        plt.plot(g[LOWD_COL], g["avg_v_threshold"], marker='o', label=f"wcc={wcc}")

    plt.xlabel("d/s")
    plt.ylabel("Average threshold vc (Gain ≥ 90%)")
    plt.ylim(1, 10)
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.savefig("threshold_v_wcc_lowd.pdf")
    plt.show()

from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
import matplotlib.pyplot as plt

def plot3d_scatter(summary):
    fig = plt.figure(figsize=(7,5), dpi=300)
    ax = fig.add_subplot(111, projection='3d')

    ax.scatter(
        summary["wcc"].values,
        summary["d/s"].values,
        summary["avg_v_threshold"].values,
        marker='o'
    )

    ax.set_xlabel("wcc")
    ax.set_ylabel("d/s")
    ax.set_zlabel("avg_v_threshold")
    ax.set_zlim(1, 10)

    plt.tight_layout()
    plt.savefig("threshold_3d_scatter.pdf")
    plt.show()
    
import numpy as np
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
import matplotlib.pyplot as plt

def plot3d_surface(summary):
    # 透视成网格：行=wcc，列=low_d，值=avg_v_threshold
    pivot = summary.pivot(index="wcc", columns="d/s", values="avg_v_threshold")

    X = pivot.columns.values
    Y = pivot.index.values
    Xg, Yg = np.meshgrid(X, Y)
    Zg = pivot.values

    fig = plt.figure(figsize=(7,5), dpi=300)
    ax = fig.add_subplot(111, projection='3d')

    # 如果有缺失组合，会出现nan，surface会断；必要时可先插值/填充
    ax.plot_surface(Xg, Yg, Zg)

    ax.set_xlabel("d/s")
    ax.set_ylabel("wcc")
    ax.set_zlabel("avg_v_threshold")
    ax.set_zlim(1, 10)

    plt.tight_layout()
    plt.savefig("threshold_3d_surface.pdf")
    plt.show()
    
def plot_marginal_threshold(summary: pd.DataFrame):
    # ===== 图1：threshold 随 wcc 变化，对不同 low_d 取平均 =====
    by_wcc = (
        summary.groupby("wcc")["avg_v_threshold"]
        .mean()
        .reset_index()
        .sort_values("wcc")
    )
    plt.rcParams['font.sans-serif'] = ['SimHei']  # 使用黑体显示中文
    plt.rcParams['axes.unicode_minus'] = False    # 解决负号显示问题
    plt.rcParams['font.size']=14
    plt.figure(figsize=(6,4), dpi=300)
    plt.rcParams['font.sans-serif'] = ['times new roman']  # 黑体
    plt.plot(by_wcc["wcc"], by_wcc["avg_v_threshold"], marker='o',linewidth = 3)
    plt.xlabel("$w$")
    #plt.ylabel("Threshold of achieving 90% gain (v)")
    plt.ylabel(r"$v$ for achieving 90% gain")#Threshold of achieving 90% gain (v)
    #plt.ylabel("90%收益对应的AGV数量")
    plt.ylim(1, 10)
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("threshold_vs_wcc.pdf")
    plt.show()

    # # ===== 图2：threshold 随 low_d 变化，对不同 wcc 取平均 =====
    by_lowd = (
        summary.groupby("d/s")["avg_v_threshold"]
        .mean()
        .reset_index()
        .sort_values("d/s")
    )
    
    # 
    # plt.rcParams['axes.unicode_minus'] = False
    # 
    plt.rcParams['font.sans-serif'] = ['SimHei']  # 使用黑体显示中文
    plt.rcParams['axes.unicode_minus'] = False    # 解决负号显示问题
    plt.rcParams['font.size']=14
    plt.figure(figsize=(6,4), dpi=300)
    plt.rcParams['font.sans-serif'] = ['times new roman']  # 黑体
    # plt.rcParams['font.size']=16
    plt.plot(by_lowd["d/s"][:5], by_lowd["avg_v_threshold"][:5], marker='o',linewidth = 3)
    plt.xlabel(r"$\tau$")
    # plt.ylabel("Threshold of achieving 90% gain (v)")
    plt.ylabel(r"$v$ for achieving 90% gain")#Threshold of achieving 90% gain (v)
    #plt.ylabel("90%收益对应的AGV数量")
    plt.ylim(3, 6)
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("threshold_vs_low_d.pdf")
    plt.show()

    return by_wcc, by_lowd

def plot_normalized_threshold_vs_wcc(summary):
    summary = summary.copy()

    # 先计算每个 (wcc, low_d) 组合下的归一化 threshold
    summary["normalized_threshold"] = summary["avg_v_threshold"] / summary["wcc"]

    # 再按 wcc 分组，对不同 low_d 取平均
    by_wcc = (
        summary.groupby("wcc")["normalized_threshold"]
        .mean()
        .reset_index()
        .sort_values("wcc")
    )

    print(by_wcc)
    # plt.rcParams['font.sans-serif'] = ['SimHei']  # 使用黑体显示中文
    plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'WenQuanYi Micro Hei', 'Arial Unicode MS', 'DejaVu Sans']
    plt.rcParams['axes.unicode_minus'] = False    # 解决负号显示问题
    plt.rcParams['font.size']=14
    plt.figure(figsize=(6,4), dpi=300)
    plt.plot(by_wcc["wcc"], by_wcc["normalized_threshold"], marker='o',linewidth = 3)
    plt.xlabel("$w$")
    # plt.ylabel("Threshold of achieving 90% gain (v) / w")
    plt.ylabel(r"$v$ for achieving 90% gain / $w$")#Threshold of achieving 90% gain (v)
    #plt.ylabel("90%收益对应的AGV数量/w")
    plt.grid(True)
    plt.tight_layout()
    # plt.savefig("normalized_threshold_vs_wcc.pdf")
    plt.show()

    return by_wcc
if __name__ == "__main__":
    df = dataProcess()                      # 先算Gain/flag/阈值
    summary = getThresholdByWccLowd(df)     # 再按(wcc, low_d)统计阈值
    # plotThreshold(summary)                  # 画图
    # plot3d_scatter(summary)
    # plot3d_surface(summary)
    by_wcc = plot_normalized_threshold_vs_wcc(summary)
    by_wcc, by_lowd = plot_marginal_threshold(summary)