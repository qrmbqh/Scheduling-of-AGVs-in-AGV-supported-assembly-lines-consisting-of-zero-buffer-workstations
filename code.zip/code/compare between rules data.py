# -*- coding: utf-8 -*-
"""
Created on Wed Oct 15 21:04:30 2025

@author: DELL
"""

import benchmarkWithoutStatus as BM
from datetime import datetime
import GurobiWithoutStatus as GS
import CBSWithoutStatus as CBS
import csv
import s2str
import randomGenerator as rg
import time
t1 = time.time()

def new_performance(wcc, vc, pc, low_d, up_d, h, low_s, up_s, time, count, fileName):
    for i in range(count):
        s = rg.random_nums(wcc, low_s, up_s)
        d = rg.random_nums(wcc-1, low_d,up_d)
        try:
            print(str(i+1)+"th")
            cbs = CBS.CBS(wcc, pc, vc, s, d, h)
            cbs_makespan, cbs_makespan_t = cbs.CBS_O()
            benchmark = BM.Benchmarks(wcc, pc, vc, s, d, h)
            STT_makespan, STT_makespan_t = benchmark.STT_Rule()
            benchmark = BM.Benchmarks(wcc, pc, vc, s, d, h)
            EDD_makespan, EDD_makespan_t = benchmark.EDD_Rule()
            benchmark = BM.Benchmarks(wcc, pc, vc, s, d, h)
            rSI_makespan, rSI_makespan_t = benchmark.rSI_Rule()
            benchmark = BM.Benchmarks(wcc, pc, vc, s, d, h)
            EP_makespan, EP_makespan_t = benchmark.Enterprise()
        except Exception as E_results:
            print("捕捉有异常：",E_results)
            f = open(fileName,'a',newline='')
            writer = csv.writer(f)
            writer.writerow([ vc,
                              pc,
                              wcc,
                              pc*wcc,
                              low_s, up_s,
                              s2str.list2str(s),
                              low_d, up_d,
                              s2str.list2str(d),
                              h
                              ])
            f.close()
        else:
            f = open(fileName,'a',newline='')
            writer = csv.writer(f)
            writer.writerow([ vc,
                              pc,
                              wcc,
                              pc*wcc,
                              low_s, up_s,
                              s2str.list2str(s),
                              low_d, up_d,
                              s2str.list2str(d),
                              h,
                              cbs_makespan, cbs_makespan_t,
                              STT_makespan, STT_makespan_t, EDD_makespan, EDD_makespan_t, rSI_makespan, rSI_makespan_t,
                              EP_makespan, EP_makespan_t
                              ])
            f.close()
    return
            
WP = [(7,8)]
V = [3]
D = [(2,5)]
S = [(20,25)]
H = 1
count = 1
total = count*len(D)*len(S)*len(WP)*len(V)
actual = total
current_date = datetime.now()
date_str = current_date.strftime('%Y-%m-%d')
current_date = datetime.now().date()
date_str = current_date.strftime('%Y-%m-%d')
fileName = 'Compare between rules'+date_str+'.csv'
f = open(fileName,'a',newline='')
writer = csv.writer(f)
writer.writerow([ 'vc',
                  'pc',
                  'wcc',
                  'taskcount',
                  'low_s', 'up_s',
                  'S',
                  'low_d','up_d',
                  'D',
                  'h',
                  'cbs_makespan', 'cbs_makespan_t',
                  'STT_makespan', 'STT_makespan_t', 'EDD_makespan', 'EDD_makespan_t', 'rSI_makespan', 'rSI_makespan_t',
                  'EP_makespan', 'EP_makespan_t'
                  ])
f.close()
for wcc, pc in WP:
    for vc in V:
        for low_d, up_d in D:
            for low_s, up_s in S:
                new_performance(wcc,vc,pc,low_d,up_d,H,low_s,up_s, 3600, count,fileName)
                actual -= count
                print('Progress: {:.2%}'.format(1-actual/total))
t2 = time.time()