# -*- coding: utf-8 -*-
"""
Created on Mon Oct 24 23:39:38 2022

@author: qrmbqh
"""

from gurobipy import *

def Heuristic(workStations, AGVs, tasks, Roads, time, T):
    x_d = []
    wc = len(workStations)
    ws = []
    ag = []
    busyWsCount = 0
    for workstation in workStations:
        if workstation.id < wc-1:
            if workstation.status == 1 or workstation.status == 3:
                ws.append(workstation.id)
            if workstation.status in [1,2,3,4]:
                busyWsCount += 1
                
    for agv in AGVs:
        if agv.status == 3:
            ag.append(agv.id)
                 
    for agv in AGVs:
        if len(ag) < len(ws) and agv.status == -1:
            agv.presentLoc = workStations[0]
            agv.status = 3
            ag.append(agv.id)
    
    if len(ag) == 0:
        return
    
    for a in ag:
        for w in ws:
            x_d.append((AGVs[a].presentLoc.id, w))

    if len(x_d) > 0:
        m = Model("model")
        m.setParam('OutputFlag',0)
        x = m.addVars(x_d, vtype = GRB.BINARY, name = 'x')
        obj = LinExpr(0)
        for w in ws:
            for a in ag:
                obj.addTerms(T[AGVs[a].presentLoc.id, w], x[AGVs[a].presentLoc.id, w])
                
        m.setObjective(obj, GRB.MINIMIZE)
        if len(ag) > len(ws):
            for a in ag:
                expr = LinExpr(0)
                for w in ws:
                    expr.addTerms(1, x[AGVs[a].presentLoc.id, w])
                m.addConstr(expr <= 1)
                
            for w in ws:
                expr = LinExpr(0)
                for a in ag:
                    expr.addTerms(1, x[AGVs[a].presentLoc.id, w])
                m.addConstr(expr == 1)
        else:
            for a in ag:
                expr = LinExpr(0)
                for w in ws:
                    expr.addTerms(1, x[AGVs[a].presentLoc.id, w])
                m.addConstr(expr == 1)
                
            for w in ws:
                expr = LinExpr()
                for a in ag:
                    expr.addTerms(1, x[AGVs[a].presentLoc.id, w])
                m.addConstr(expr <= 1)
            
        m.optimize()
        
        for a in ag:
            for w in ws:
                if x[AGVs[a].presentLoc.id, w].x > 0.5:
                    tasks[workStations[w].id, workStations[w].presentProd.id].status = 1
                    tasks[workStations[w].id, workStations[w].presentProd.id].agv = AGVs[a]
                    workStations[w].status = 4
                    AGVs[a].LeaveWorkStation(workStations[w], tasks, T, time, wc)
                    tag = 1
                    break
    for a in ag:
        if AGVs[a].status == 3 and busyWsCount < len(AGVs):
            if AGVs[a].presentLoc.presentProd == None:
                AGVs[a].presentLoc.status = 0
            else:
                AGVs[a].presentLoc.status = 1
            AGVs[a].presentLoc = None
            AGVs[a].status = -1
    workStations[0].timeToFree(workStations, tasks, Roads)