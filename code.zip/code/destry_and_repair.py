# -*- coding: utf-8 -*-
"""
Created on Fri Mar  6 16:14:16 2026

@author: lenovo
"""
import ini_solution as IS
import random
# import timeSceduling as ts
import functions as F
from gurobipy import *
import CBSWithoutStatus as CBS
import time
WG = None
PG = None
VG = None
SG = None
DG = None
HG = None

def setGlobalParam(w,p,v,s,d,h):
    global WG,PG,VG,DG,SG,HG
    IS.setGlobalParam(w, p, v, s, d, h)
    WG,PG,VG,DG,SG,HG = w,p,v,d,s,h

def evaluation(seqs):
    seqs = F.copy(seqs)
    x = seqs2x(seqs)
    tag, obj = timeScheduling(x)
    return tag, obj

def timeScheduling(xp):
    global WG,PG,VG,DG,SG,HG
    wcc, pc, vc, d, s, h = WG,PG,VG,DG,SG,HG
    #计算距离矩阵
    S = [0] + s
    T_d = [(i,j) for i in range(1,wcc+1) for j in range(1,wcc+1)]
    
    T = {}
    for i,j in T_d:
        if i <= j:
            T[i,j] = sum(d[i-1:j-1])
        else:
            T[i,j] = sum(d[j-1:i-1])+2*h
            
    #生成AGV集合
    V = list(range(1, vc+1))
            
    #定义开始的虚拟任务区域
    A = [(0,v) for v in V]
    E = [(0,0)]
    #任务区域zh
    D = [(i,j) for i in range(1,wcc) for j in range(1,pc+1)]
    M = len(D)*max(S)*100
    
    #BD定义
    b1 = [(0,j) for j in range(pc+1)]
    b2 = [(i,0) for i in range(1,wcc)]
    
    #CD定义
    c1 = [(wcc, j) for j in range(pc + 1)]
    c2 = [(i,0) for i in range(1,wcc)]
    #定义结束的虚拟任务区域
    c_d = D + c1 + c2
    b_d = D + b1 + b2
    x_d = [(i,j,m,n) for (i,j) in D + A for (m,n) in D + E]
    #线性化用到的辅助变量区间定义
    # define model
    mdl = Model("Model")
    #define variables
    # x = mdl.addVars(x_d, vtype = GRB.BINARY, name = 'x')
    x = {}
    for key in x_d:
        var = mdl.addVar(lb=xp[key],ub=xp[key],vtype=GRB.BINARY,name=f'x{key}')
        x[key]=var
    b = mdl.addVars(b_d, lb = 0, name = 'b')
    c = mdl.addVars(c_d, lb = 0, name = 'c')
    #objective function #最小化完工时间
    obj1 = LinExpr(0)
    obj1.addTerms(1, c[wcc,pc])
    mdl.setObjective(obj1, GRB.MINIMIZE)
        
    for (i,j) in D + A:
        expr = LinExpr(0)
        for m,n in D + E:
            expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 1)
    
    #c2
    for m,n in D:
        expr = LinExpr(0)
        for i,j in D + A:
            expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 1)
    
    for i,j in D:
        expr = LinExpr(0)
        for m, n in D:
            if m > i and m+n <= i+j:
                expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 0)
        
    #c5
    for i,j in D:
        for m,n in D:
            expr = LinExpr(0)
            expr.addTerms(M, x[i,j,m,n])
            expr.addTerms(1, b[m-1,n])
            expr.addTerms(-1, b[i,j])
            mdl.addConstr(expr <= M + T[i+1,m])
    
    #7
    for i,j in D:
        for m,n in D:
            expr = LinExpr(0)
            expr.addTerms(M, x[i,j,m,n])
            expr.addTerms(-1,c[m,n])
            expr.addTerms(1, b[i,j])
            mdl.addConstr(expr <= M - T[i+1,m])
            
    #8
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(-1, c[i,j])
        expr.addTerms(1, c[i+1,j-1])
        mdl.addConstr(expr <= T[i,i+1])
       
    #9
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(-1, c[i,j])
        expr.addTerms(1, c[i+1,j])
        mdl.addConstr(expr >= T[i,i+1] + S[i+1])
    
    #10
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(1, b[i,j])
        expr.addTerms(-1, c[i,j])
        mdl.addConstr(expr >= T[i,i+1])
        
    for j in range(1, pc+1):
        expr = LinExpr(0)
        expr.addTerms(1, c[1,j])
        expr.addTerms(-1, c[1,j-1])
        mdl.addConstr(expr >= S[1])

    for i,j in b1:
        if j > 1:
            mdl.addConstr(b[i,j]==c[i+1,j-1])
    # mdl.setParam(GRB.Param.PoolGap, 0)
    # mdl.setParam("PoolSearchMode", 0)
    mdl.setParam(GRB.Param.OutputFlag, 0)  
    # mdl.Params.TimeLimit = t_limited
    mdl.optimize()
    if mdl.Status == 2:
        b_repaired = {}
        c_repaired = {}
        for key in b_d:
            b_repaired[key] = b[key].x
        for key in c_d:
            c_repaired[key] = c[key].x
        return True, mdl.ObjVal
    if mdl.Status == 3:
        mdl.computeIIS() 
        mdl.write("abc.ilp")
        return False, None
    
def seqs2x(seqs):
    global WG,PG,VG,DG,SG,HG
    w,p,v = WG,PG,VG
    seqs = F.copy(seqs)
    x = {}
    A = [(0,k) for k in range(1, v+1)]
    E = [(0,0)]
    D = [(i,j) for i in range(1,w) for j in range(1,p+1)]
    x_d = [(i,j,m,n) for (i,j) in D + A for (m,n) in D + E]
    for idx, seq in enumerate(seqs):
        if seq[0][0]!=0:
            seq.insert(0,(0,idx+1))
        if seq[-1]!=(0,0):
            seq.append((0,0))
        for i in range(1, len(seq)):
            node = seq[i]
            last_node = seq[i-1]
            key = (*last_node, *node)          # 先拼接成一个 tuple
            x[key] = 1
            # x[*last_node, *node] = 1
    for key in x_d:
        if key not in x:
            x[key] = 0
    return x

def destory_and_repair_once(xp, percent):
    global WG,PG,VG,DG,SG,HG
    wcc, pc, vc, d, s, h = WG,PG,VG,DG,SG,HG
    #计算距离矩阵
    S = [0] + s
    T_d = [(i,j) for i in range(1,wcc+1) for j in range(1,wcc+1)]
    
    T = {}
    for i,j in T_d:
        if i <= j:
            T[i,j] = sum(d[i-1:j-1])
        else:
            T[i,j] = sum(d[j-1:i-1])+2*h
            
    #生成AGV集合
    V = list(range(1, vc+1))
            
    #定义开始的虚拟任务区域
    A = [(0,v) for v in V]
    E = [(0,0)]
    #任务区域zh
    D = [(i,j) for i in range(1,wcc) for j in range(1,pc+1)]
    M = len(D)*max(S)*100
    
    #BD定义
    b1 = [(0,j) for j in range(pc+1)]
    b2 = [(i,0) for i in range(1,wcc)]
    
    #CD定义
    c1 = [(wcc, j) for j in range(pc + 1)]
    c2 = [(i,0) for i in range(1,wcc)]
    #定义结束的虚拟任务区域
    c_d = D + c1 + c2
    b_d = D + b1 + b2
    x_d = [(i,j,m,n) for (i,j) in D + A for (m,n) in D + E]
    #线性化用到的辅助变量区间定义
    # define model
    mdl = Model("Model")
    #define variables
    # x = mdl.addVars(x_d, vtype = GRB.BINARY, name = 'x')
    if percent is None:
        percent = 0.0
    if percent > 1.0:
        percent = percent / 100.0
    percent = max(0.0, min(1.0, float(percent)))
    free_cnt = int(round(len(x_d) * percent))
    free_keys = set(random.sample(x_d, free_cnt)) if free_cnt > 0 else set()
    x = {}
    for key in x_d:
        # xp 必须提供该 key，否则报错更早暴露问题
        # if key not in xp:
        #     raise KeyError(f"xp 缺少 key={key} 的取值，无法固定/放开该变量。")

        if key in free_keys:
            # 放开：自由二进制
            var = mdl.addVar(lb=0, ub=1, vtype=GRB.BINARY, name=f"x{key}")
        else:
            # 固定：lb=ub=xp[key]
            # val = int(round(xp[key]))
            var = mdl.addVar(lb=xp[key], ub=xp[key], vtype=GRB.BINARY, name=f"x{key}")
        x[key] = var
    
    # for key in x_d:
    #     var = mdl.addVar(lb=xp[key],ub=xp[key],vtype=GRB.BINARY,name=f'x{key}')
    #     x[key]=var
    b = mdl.addVars(b_d, lb = 0, name = 'b')
    c = mdl.addVars(c_d, lb = 0, name = 'c')
    #objective function #最小化完工时间
    obj1 = LinExpr(0)
    obj1.addTerms(1, c[wcc,pc])
    mdl.setObjective(obj1, GRB.MINIMIZE)
        
    for (i,j) in D + A:
        expr = LinExpr(0)
        for m,n in D + E:
            expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 1)
    
    #c2
    for m,n in D:
        expr = LinExpr(0)
        for i,j in D + A:
            expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 1)
    
    for i,j in D:
        expr = LinExpr(0)
        for m, n in D:
            if m > i and m+n <= i+j:
                expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 0)
        
    #c5
    for i,j in D:
        for m,n in D:
            expr = LinExpr(0)
            expr.addTerms(M, x[i,j,m,n])
            expr.addTerms(1, b[m-1,n])
            expr.addTerms(-1, b[i,j])
            mdl.addConstr(expr <= M + T[i+1,m])
    
    #7
    for i,j in D:
        for m,n in D:
            expr = LinExpr(0)
            expr.addTerms(M, x[i,j,m,n])
            expr.addTerms(-1,c[m,n])
            expr.addTerms(1, b[i,j])
            mdl.addConstr(expr <= M - T[i+1,m])
            
    #8
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(-1, c[i,j])
        expr.addTerms(1, c[i+1,j-1])
        mdl.addConstr(expr <= T[i,i+1])
       
    #9
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(-1, c[i,j])
        expr.addTerms(1, c[i+1,j])
        mdl.addConstr(expr >= T[i,i+1] + S[i+1])
    
    #10
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(1, b[i,j])
        expr.addTerms(-1, c[i,j])
        mdl.addConstr(expr >= T[i,i+1])
        
    for j in range(1, pc+1):
        expr = LinExpr(0)
        expr.addTerms(1, c[1,j])
        expr.addTerms(-1, c[1,j-1])
        mdl.addConstr(expr >= S[1])

    for i,j in b1:
        if j > 1:
            mdl.addConstr(b[i,j]==c[i+1,j-1])
    # mdl.setParam(GRB.Param.PoolGap, 0)
    # mdl.setParam("PoolSearchMode", 0)
    mdl.setParam(GRB.Param.OutputFlag, 0)  
    # mdl.Params.TimeLimit = t_limited
    mdl.optimize()
    # if mdl.Status == 2:
    solution = {}
    for key in x_d:
        solution[key] = x[key].x
    return mdl.objVal, solution

def repair_time_percent(times, percent):
    t1 = time.time()
    _, sol = IS.ini_sol()
    sol = seqs2x(sol)
    for _ in range(times):
        obj, sol = destory_and_repair_once(sol, percent)
    t2 = time.time()
    return obj, sol, t2-t1
if __name__ == '__main__':
    v=3
    p=13
    w=10
    s= [7,9,6,10,5,8,7,7,8,10,]
    d= [2,2,5,2,5,3,4,4,3,]
    # s = [random.randint(3, 10) for _ in range(w)]
    # d = [random.randint(2, 5) for _ in range(w-1)]
    h= 1
    # cbs = CBS.CBS(w, p, v, s, d, h)
    # cbs_res = cbs.CBS_NL(3, 3)
    
    setGlobalParam(w, p, v, s, d, h)
    _, initial = IS.ini_sol()
    res1 = evaluation(initial)
    res_repair = repair_time_percent(20, 0.25)
# res = destory_and_repair_once(x, 0.25)