# -*- coding: utf-8 -*-
"""
Created on Thu Feb 26 14:39:20 2026

@author: Administrator
"""

import relax_and_repair as RR
import greedy_insert_v3 as GI
import newCBSwithLNSdr as CB
import GurobiWithoutStatus as GB
import numpy as np
from tqdm import tqdm
import randomGenerator as RG
from datetime import datetime
import csv
import s2str
import random
import destry_and_repair as DR

WP = [(6,7),(7,8),(8,9),(9,10)]#(6,7),(7,8),
V = [3,4,5]
D = [(2,5)]
S = [(5,10),(10,15),(15,20),(20,25)]
h = 1
# l_d,u_d = 2, 5
count = 20

current_date = datetime.now().date()
date_str = current_date.strftime('%Y-%m-%d')
# date_str= '2025-08-16'
fileName = '小规模数据重算'+date_str+'.csv'
f = open(fileName,'a',newline='')
writer = csv.writer(f)
writer.writerow([ 'v',
                  'p',
                  'w',
                  'taskcount',
                  'low_s', 'up_s',
                  'S',
                  'low_d','up_d',
                  'D',
                  'h',
                  'obj_gurobi', 'best_bound', 'optimal_gap', 't_grobi',
                  'obj_cbs', 't_cbs',
                  'obj_rr','t_rr',
                  'obj_gi','t_gi',
                  'obj_dr','t_dr'
                  ])
f.close()

for w,p in tqdm(WP, ncols=100):
    for v in tqdm(V, ncols=100):
        for l_s,u_s in tqdm(S, ncols=100):
            for l_d,u_d in tqdm(D, ncols=100):
                for _ in tqdm(range(count), ncols=100):
                    s = RG.random_nums(w, l_s, u_s)
                    d = RG.random_nums(w-1, l_d,u_d)
                    RR.setGlobalParam(w, p, v, s, d, h)
                    GI.setGlobalParam(w, p, v, s, d, h)
                    try:
                        m = CB.CBS(w, p, v, s, d, h)
                        obj_cbs,t_cbs= m.CBS_NL(3,3)
                        obj_rr,t_rr = RR.relax_and_repair()
                        obj_gi,_,_,_,t_gi = GI.greedy_insert_anywhere()
                        obj_gb,best_bound,opt_gap,t_gb = GB.newAGVSchedul(v, p, w, s, d, h,t_limited=3600)
                        DR.setGlobalParam(w, p, v, s, d, h)
                        obj_dr = None
                        while not obj_dr:
                            try:
                                obj_dr,_,t_dr = DR.repair_time_percent(50, 0.25)
                            except:
                                obj_dr = None
                    except:
                        s = RG.random_nums(w, l_s, u_s)
                        d = RG.random_nums(w-1, l_d,u_d)
                        RR.setGlobalParam(w, p, v, s, d, h)
                        GI.setGlobalParam(w, p, v, s, d, h)
                        m = CB.CBS(w, p, v, s, d, h)
                        obj_cbs,t_cbs= m.CBS_NL(3,3)
                        obj_rr,t_rr = RR.relax_and_repair()
                        obj_gi,_,_,_,t_gi = GI.greedy_insert_anywhere()
                        obj_gb,best_bound,opt_gap,t_gb = GB.newAGVSchedul(v, p, w, s, d, h,t_limited=3600)
                        DR.setGlobalParam(w, p, v, s, d, h)
                        obj_dr = None
                        while not obj_dr:
                            try:
                                obj_dr,_,t_dr = DR.repair_time_percent(50, 0.25)
                            except:
                                obj_dr = None
                    f = open(fileName,'a',newline='')
                    writer = csv.writer(f)
                    writer.writerow([ v,
                                      p,
                                      w,
                                      p*w,
                                      l_s, u_s,
                                      s2str.list2str(s),
                                      l_d, u_d,
                                      s2str.list2str(d),
                                      h,
                                      obj_gb,best_bound,opt_gap,t_gb,
                                      obj_cbs,t_cbs,
                                      obj_rr,t_rr,obj_gi,t_gi,
                                      obj_dr,t_dr
                                      ])
                    f.close()