# -*- coding: utf-8 -*-
"""
Created on Wed Feb 26 14:55:08 2025

@author: 74110
"""

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
# 读取 Excel 文件
df = pd.read_csv("figure_alpha&beta_data56_2025-03-07.csv")  # 请替换为你的文件路径

# 计算 gap_opt 和 timeConsume 的均值
gap_opt_mean = df.groupby(["n", "l"])['gap_opt'].mean().unstack()
time_consume_mean = df.groupby(["n", "l"])['cbs_makespan_t'].mean().unstack()

# 反转 n 轴顺序
gap_opt_mean = gap_opt_mean[::-1]
time_consume_mean = time_consume_mean[::-1]

plt.rcParams.update({
    'font.size': 18,  # 字体大小
    'font.family': 'times new roman',  # 字体家族
    'mathtext.fontset': 'stix',  # 让数学公式字体与主字体匹配
})
# 创建图形和子图
fig, axes = plt.subplots(1, 2, figsize=(14, 6))

# 绘制子图1：gap_opt 均值热力图
ax = sns.heatmap(gap_opt_mean * 100, annot=False, fmt=".1f", cmap="YlGnBu", ax=axes[0])#linewidths=0.1
cbar = ax.collections[0].colorbar
cbar.set_ticklabels([f"{round(tick, 1)}" for tick in cbar.get_ticks()])  # Convert to %
axes[0].set_xlabel(r"$\alpha$")
axes[0].set_ylabel(r"$\beta$")
axes[0].tick_params(top=False)

# 绘制子图2：timeConsume 均值热力图
sns.heatmap(time_consume_mean, annot=False, fmt=".1f", cmap="YlGnBu", ax=axes[1])
# axes[1].set_title("Heatmap of timeConsume Mean")
axes[1].set_xlabel(r"$\alpha$")
axes[1].set_ylabel(r"$\beta$")
axes[1].tick_params(top=False)

# 调整图例格式
cbar = axes[0].collections[0].colorbar
cbar.set_label("Gap (%)")
cbar = axes[1].collections[0].colorbar
cbar.set_label("$t$ (s)")

# 显示图像
plt.tight_layout()
plt.show()
