# -*- coding: utf-8 -*-
"""
Created on Wed Feb 25 21:34:41 2026

@author: DELL
"""

import newSectionAllocate0906 as SA
# import copy
import math
import time
import myRound
# import showRoute as sr
import QnCalculate as QC
import bisect
import pickle
import random

def distribute_resources(l, vNum):
    """
    随机分配资源给多个人，受个人容量上限限制。

    :param l: List[int], l[i] 表示第i个人最多被分配的资源数量
    :param vNum: int, 需要分配的资源总量
    :return: List[int], 返回每个人实际被分配的资源数量
    """
    # 异常处理：确保总资源数不会超过所有人的容量总和
    if vNum > sum(l):
        raise ValueError("资源总量 vNum 大于所有人容量上限的总和，无法完全分配！")

    n = len(l)
    result = [0] * n

    # 随机打乱分配顺序，保证分配的公平性（避免排在前面的人总是分得更多或更少）
    indices = list(range(n))
    random.shuffle(indices)

    remaining_cap = sum(l)  # 剩余未处理的人的总容量
    remaining_vNum = vNum  # 剩余需要分配的资源量

    for idx in indices:
        # 在处理当前的人之前，先从剩余总容量中扣除他的容量
        remaining_cap -= l[idx]

        # 计算当前人分配的【最小值】：
        # 如果剩下的资源（remaining_vNum）大于其他人能吸收的最大总容量（remaining_cap），
        # 那么当前这个人必须"兜底"接收多出来的这部分资源，否则资源就分不完了。
        min_assign = max(0, remaining_vNum - remaining_cap)

        # 计算当前人分配的【最大值】：
        # 既不能超过他自己的容量上限，也不能超过当前剩余待分配的资源量。
        max_assign = min(l[idx], remaining_vNum)

        # 在安全区间内随机分配一个数值
        assigned = random.randint(min_assign, max_assign)

        # 记录分配结果，并更新剩余资源量
        result[idx] = assigned
        remaining_vNum -= assigned

    return result
def copy(originObj): 
    """
    对象深拷贝
    
    参数:
    originObj:被拷贝对象
    返回:
    l: 拷贝对象
    """
    l = pickle.loads(pickle.dumps(originObj))
    assert type(l)== type(originObj)
    return l

def random_pair(a, b):
    # 创建索引列表并打乱
    indices = list(range(len(a)))
    random.shuffle(a)
    random.shuffle(b)
    random.shuffle(indices)
    
    # 根据打乱后的索引进行配对
    pairs = [(a[i], b[i]) for i in indices]
    return pairs


def random_pair_new(a, b):
    # 创建索引列表并打乱
    a = copy(a)
    b = copy(b)
    pairs = [(a[-1],b[-1])]
    a.pop()
    b.pop()
    for _v in a:
        _w = b.pop(0)
        pairs.append((_v, _w))
        # b.remove(_w)
    return pairs

def find_index(nums, k):
    prefix_sum = [0]  # 前缀和数组
    for num in nums:
        prefix_sum.append(prefix_sum[-1] + num)
    
    # 使用 bisect_right 找到第一个大于 k 的前缀和索引
    i = bisect.bisect_right(prefix_sum, k) - 1  
    return i  # i 是满足条件的索引

class WS:
    def __init__(self, _id, _s, _d, _h):
        self.id = _id
        self.s = _s
        self.d = _d
        self.prod = None
        self.state = "idle"
        self.rpt = 0
        self.isLastWs = False
        self.type = "ws"
        self.h = _h
        self.flag = 0
    
    def setIsLastWs(self, tf):
        self.isLastWs = tf
    
    def setState(self, _prod, _rpt, _state):#设置工位状态
        self.prod = _prod
        self.rpt = _rpt
        self.state = _state
        
    def getRestTimeToBeIdle(self, WSs):
        if self.isLastWs == True:
            self.RTI = self.rpt
        else:
            if self.state == "idle":
                self.RTI = 0
            elif self.state == "busyAgv":
                self.RTI = max(self.rpt, self.prod.agv.rst_dht, WSs[self.id].RTI - self.d)
            elif self.state == "busyNoAgv":
                self.RTI = 9999999
    
class AGV:
    def __init__(self, _id):
        self.id = _id
        self.state = "unenable"
        self.rst_dht = 0
        self.rst_lt = 0
        self.preLoc = None
        self.destLoc = None
        self.route = []
        self.bt = 0
        self.prod = None#新增
        self.direction = None
        self.anchor_x = None
        self.anchor_y = None
        
    def offLine(self):
        self.state = "unenable"
        self.rst_dht = 0
        self.rst_lt = 0
        self.bt = 0
        self.preLoc = None
        self.destLoc = None
        self.prod = None
        self.direction = None
        self.anchor_x = None
        self.anchor_y = None
    
    def setState(self, state, rst_dht, rst_lt, bt, preLoc, destLoc, prod):
        self.state = state
        self.rst_dht = rst_dht
        self.rst_lt = rst_lt
        self.bt = bt
        self.preLoc = preLoc
        self.destLoc = destLoc
        self.prod = prod

        self.reassigned = False
        
    def getRestTimeToStart(self):
        if self.state == "assigned":
            self.RTS = self.destLoc.RTI
        elif self.state == "waitLoad":
            self.RTS = self.preLoc.RTI
        elif self.state == "loaded":
            self.RTS = 0
        else:
            self.RTS = 9999999
            
    def getDistToWS(self, ws, ds):
        if self.state in ["free", "waitLoad"]:
            if ws.id >= self.preLoc.id:
                # dist = abs(self.preLoc.id - ws.id) * ws.d
                dist = sum(ds[self.preLoc.id-1: ws.id-1])
            else:
                # dist = abs(self.preLoc.id - ws.id) * ws.d + 2*ws.h
                dist = sum(ds[ws.id-1: self.preLoc.id-1]) + 2*ws.h
        elif self.state == "halfFree":
            if ws.id >= self.preLoc.id:
                # dist = abs(self.preLoc.id - ws.id) * ws.d + self.bt
                dist = sum(ds[self.preLoc.id-1: ws.id-1]) + self.bt
            else:
                # dist = abs(self.preLoc.id - ws.id) * ws.d + 2*ws.h + self.bt
                dist = sum(ds[ws.id-1: self.preLoc.id-1]) + 2*ws.h + self.bt
        elif self.state =="unenable":
            # dist = ws.id * ws.d
            dist = sum(ds[ws.id-1])#有问题
        elif self.state == "assigned":
            dist = 0
            h = self.destLoc.h
            if self.anchor_x == None:
                # self.anchor_x = (self.preLoc.id - 1) * d
                self.anchor_x = sum(ds[:self.preLoc.id - 1])
                self.anchor_y = 0
            
            # dest_x = (ws.id - 1) * d
            dest_x = sum(ds[:ws.id - 1])
            
            if self.anchor_y == 0:#车在工位道路
                if dest_x >= self.anchor_x:
                    dist = dest_x - self.anchor_x
                else:
                    # temp_id = self.anchor_x//d + 1
                    temp_id = find_index(ds, self.anchor_x) + 1
                    # if self.anchor_x/d > self.anchor_x//d:
                    if self.anchor_x != sum(ds[:temp_id-1]) and self.anchor_x != sum(ds[:temp_id]):
                        # dist = temp_id  * d - self.anchor_x + temp_id * d - dest_x + 2*h
                        dist = sum(ds[:temp_id]) - self.anchor_x + sum(ds[:temp_id]) - dest_x + 2*h
                    else:
                        dist = self.anchor_x - dest_x + 2 * h
                        # dist  = 
            if 0 < self.anchor_y < h:#车在竖向道路
                if self.rst_dht > h:#上行
                    dist = abs(dest_x - self.anchor_x) + 2*h - self.anchor_y
                elif self.rst_dht < h:#下行
                    if dest_x >= self.anchor_x:
                        dist = dest_x - self.anchor_x + self.anchor_y
                    else:
                        dist = self.anchor_x - dest_x + 2*h + self.anchor_y
            if self.anchor_y == h:#车在上方横向道路            
                if dest_x >= self.anchor_x:
                    # temp_id = self.anchor_x//d + 1
                    temp_id = find_index(ds, self.anchor_x) + 1
                    # if self.anchor_x/d > self.anchor_x//d:
                    if self.anchor_x != sum(ds[:temp_id-1]) and self.anchor_x != sum(ds[:temp_id]):
                        # dist = self.anchor_x - (temp_id - 1) * d + dest_x - (temp_id - 1) * d + h
                        dist = self.anchor_x - sum(ds[:temp_id - 1]) + dest_x - sum(ds[:temp_id - 1]) + h
                    else:
                        # dist = dest_x - (temp_id - 1) * d + h
                        dist = dest_x - sum(ds[:temp_id - 1]) + h
                else:
                    dist = self.anchor_x - dest_x + h
        return dist
        
    
    def setAnchor(self, ds):
        # d, h = self.destLoc.d, self.destLoc.h
        h = self.destLoc.h
        pre_x, pre_y = -1,-1
        if self.anchor_x == None:
            # self.anchor_x = (self.preLoc.id - 1) * d
            self.anchor_x =  sum(ds[:self.preLoc.id - 1])
            self.anchor_y = 0
            if self.lastDestLoc.id == self.destLoc.id:
                self.anchor_x =  sum(ds[:self.preLoc.id - 1])-self.rst_dht
        if self.state == "assigned":
            # dest_x = (self.destLoc.id - 1) * d
            dest_x = sum(ds[:self.destLoc.id - 1])
            if self.anchor_y == h and self.rst_dht >= h:#初始位置在向左道路
                pre_x = dest_x + self.rst_dht - h
                pre_y = h
            if self.anchor_y == h and self.rst_dht < h and self.rst_dht > 0:
                pre_x = dest_x
                pre_y = self.rst_dht
            if self.anchor_y == h and self.rst_dht == 0:
                self.state = "waitLoad"
                pre_x = None
                pre_y = None
                self.preLoc = self.destLoc
            if self.anchor_y > 0 and self.anchor_y < h:#初始位置在纵向道路
                if dest_x >= self.anchor_x:
                    if self.rst_dht <= dest_x - self.anchor_x:
                        pre_x = dest_x - self.rst_dht
                        pre_y = 0
                    else:
                        pre_x = self.anchor_x
                        if self.rst_dht - (dest_x - self.anchor_x) <= h:
                            pre_y = self.rst_dht - (dest_x - self.anchor_x)
                        else:
                            pre_y = 2 * h - (self.rst_dht - (dest_x - self.anchor_x))
                if dest_x < self.anchor_x:
                    if self.rst_dht >= self.anchor_x - dest_x + 2 * h:
                        pre_x = self.anchor_x
                        pre_y = self.rst_dht - (self.anchor_x - dest_x + 2 * h)
                    elif self.rst_dht >= self.anchor_x - dest_x + h:
                        pre_x = self.anchor_x
                        pre_y = h - (self.rst_dht - (self.anchor_x - dest_x + h))
                    elif self.rst_dht >= h:
                        pre_x = self.rst_dht - h + dest_x
                        pre_y = h
                    else:
                        pre_x = dest_x
                        pre_y = self.rst_dht
            if self.anchor_y == 0:
                if dest_x > self.anchor_x:
                    pre_x = dest_x - self.rst_dht
                    pre_y = 0
                if dest_x < self.anchor_x:
                    
                    tempid = find_index(ds, self.anchor_x)+1#新加
                    # if self.anchor_x//d == self.anchor_x/d:
                    if self.anchor_x == sum(ds[:tempid-1]):
                        # tem_turn_x = (self.anchor_x//d) * d#找到离anchor最近的节点
                        tem_turn_x = sum(ds[:tempid-1])
                    else:
                        # tem_turn_x = (self.anchor_x//d + 1) * d
                        tem_turn_x = sum(ds[:tempid])
                    if self.rst_dht >= tem_turn_x - dest_x + 2*h:
                        pre_x = tem_turn_x - self.anchor_x + tem_turn_x - dest_x + 2*h - self.rst_dht + self.anchor_x
                        pre_y = 0
                    elif self.rst_dht > tem_turn_x - dest_x + h:
                        pre_x = tem_turn_x
                        pre_y = tem_turn_x - dest_x + 2*h - self.rst_dht
                    elif self.rst_dht > h:
                        pre_x = self.rst_dht - h + dest_x
                        pre_y = h
                    else:
                        pre_x = dest_x
                        pre_y = self.rst_dht
        self.anchor_x,self.anchor_y = pre_x,pre_y
                    
class PRODUCT:
    def __init__(self, _id):
        self.id = _id
        self.state = "waitEnter"
        self.loc = None
        self.timeStartProcessed = 0
        self.timeEndProcessed = 0
        self.agv = None
    
    def setState(self, state, loc, agv):
        self.loc = loc
        self.agv = agv
        self.state = state

class ROAD:
    def __init__(self, _id, dist):
        self.id = _id
        self.d = dist
        self.state = "free"
        self.type = "road"
        
class Task:
    def __init__(self, w, p):
        self.w = w
        self.p = p
        self.sTime = 0
        self.eTime = 0
        
class STAGE:
    def __init__(self, v, w, p, srv, d, h):
        self.time = 0
        self.vc = v
        self.wc = w
        self.pc = p
        self.h = h
        self.d = d
        self.rawProdNum = p
        self.unenableAgvNum = v
        self.level = 1
        self.AGVs = []
        self.WSs = []
        self.PRODs = []
        self.ROADs = []
        self.TASKs = []#记录时间
        
        for i in range(v):
            self.AGVs.append(AGV(i+1))
            
        for i in range(w-1):
            self.WSs.append(WS(i+1,srv[i], d[i], h))
        
        self.WSs.append(WS(w, srv[w-1], 0, h))
        self.WSs[w-1].setIsLastWs(True)
        
        for i in range(p):
            self.PRODs.append(PRODUCT(i+1))
        
        for i in range(w-1):
            self.ROADs.append(ROAD(i+1, d[i]))
        
        for i in range(w-1):
            TASKs = []
            for j in range(p):
                TASKs.append(Task(i,j))
            self.TASKs.append(TASKs)

    def beginProcess(self):
        self.AGVs[0].setState("waitLoad", 0, 0, 0, self.WSs[0], self.WSs[1], self.PRODs[0])
        self.PRODs[0].setState("atWS", self.WSs[0], self.AGVs[0])
        self.WSs[0].setState(self.PRODs[0], self.WSs[0].s, "busyAgv")
        self.unenableAgvNum -= 1
        self.rawProdNum -= 1
    
    def updateAGVsRTS(self):
        for agv in self.AGVs:
            agv.getRestTimeToStart()
    
    def updateWSsRTI(self):
        for i in range(self.wc-1,-1,-1):
            self.WSs[i].getRestTimeToBeIdle(self.WSs)
    
    def getInterval(self):
        for agv in self.AGVs:
            if agv.state != "unenable":
                candidate = []
                for i in range(self.vc):
                    if self.AGVs[i].preLoc!=None:
                        if self.AGVs[i].state in ['waitLoad','loadMove']:
                            candidate.append(self.AGVs[i].RTS + self.AGVs[i].preLoc.d)
                        elif self.AGVs[i].state == 'assigned':
                            candidate.append(self.AGVs[i].RTS + self.AGVs[i].destLoc.d)
                        else:
                            pass
                            # print('fsdsdgffddfghgfh')
                return min(candidate)
                # return min([self.AGVs[i].RTS for i in range(self.vc)]) + self.d #本步需要推进的时间
        return self.WSs[-1].RTI
        
    def update(self):#状态转移
        interval = self.getInterval()
        accupyTime = 0
        for p in self.PRODs:
            if p.state == "finish":
                pass
            elif p.state == "atWS":
                if p.loc.state == "busyAgv":
                    if p.loc.RTI > interval:
                        p.loc.rpt = max(p.loc.rpt - interval, 0)
                        p.agv.rst_dht = max(p.agv.rst_dht - interval, 0)
                        # p.agv.bt = max(0, p.agv.bt-interval)
                        if p.agv.rst_dht == 0:
                            p.agv.state = "waitLoad"
                            p.agv.anchor_x = None
                            p.agv.anchor_y = None
                            p.agv.preLoc = p.loc
                            p.agv.destLoc = self.WSs[p.loc.id]
                            p.agv.destLoc.flag = 0
                        elif p.agv.rst_dht != 0:
                            p.agv.destLoc.flag = 0
                            p.agv.setAnchor(self.d)#更新锚定点
                            p.agv.state = "assigned"
                        
                    elif p.loc.RTI <= interval and p.loc.RTI > interval - p.loc.d:#产品在路上
                        temp_id = p.loc.id
                        # temp_RTI = self.PRODs[p].loc.RTI
                        #修改上一个位置的状态
                        if p.loc.id == 1:
                            accupyTime = p.loc.RTI
                        # p.agv.route.append((temp_id, p.id))#记录任务
                        # self.TASKs[temp_id - 1 ][p.id - 1].sTime =  self.time + p.loc.RTI
                        p.loc.state = "idle"
                        p.loc.flag = 0
                        p.loc.rpt = 0
                        p.loc.prod = None
                        #修改当前位置的状态
                        p.loc = self.ROADs[temp_id - 1]
                        p.loc.state = "busy"
                        #修改当前AGV的状态
                        p.agv.state = "loaded"
                        p.agv.destLoc = self.WSs[temp_id]
                        p.agv.preLoc = self.ROADs[temp_id - 1]
                        p.agv.rst_lt = p.agv.preLoc.d - (interval - p.agv.RTS)#修改
                    else:#产品到达下一个位置
                        temp_id = p.loc.id
                        if p.loc.id == 1:
                            accupyTime = p.loc.RTI
                        # p.agv.route.append((temp_id, p.id))#记录任务
                        # self.TASKs[temp_id - 1][p.id - 1].sTime =  self.time + interval - self.d#修改
                        #修改上一个位置的状态
                        p.loc.state = "idle"
                        p.loc.flag = 0
                        p.loc.rpt = 0
                        p.loc.prod = None
                        #修改当前位置的状态
                        p.loc = self.WSs[temp_id]
                        p.loc.prod = p
                        p.loc.rpt = p.loc.s
                        p.loc.state = "busyNoAgv"
                        #修改AGV的状态
                        p.agv.state = "free"
                        p.agv.prod = None
                        p.agv.rst_lt = 0
                        p.agv.rst_dht = 0
                        p.agv.preLoc = self.WSs[temp_id]
                        p.agv.destLoc = None
                        p.agv.anchor_x = None
                        p.agv.anchor_y = None                        
                        p.agv = None

                elif p.loc.state == "busyNoAgv":
                    if p.loc.id == self.wc:#如果是最后一个工位，特殊处理
                        if p.loc.RTI > interval:
                            p.loc.rpt = max(p.loc.rpt - interval, 0)
                            p.loc.flag = 0
                        else:
                            #修改当前工位状态
                            p.loc.rpt = 0
                            p.loc.state = "idle"
                            p.loc.flag = 0
                            p.loc.prod = None
                            #产品下线
                            p.state = "finish"
                            p.loc = None
                            if p.agv != None:
                                p.agv = None
                    else:#如果不是最后一个工位，则只修改工位的剩余加工时间
                        p.loc.rpt = max(p.loc.rpt - interval, 0)
            
            elif p.state == "waitEnter":
                if self.WSs[0].state =="idle":
                    #新产品进入生产线
                    self.WSs[0].state = "busyNoAgv"
                    self.WSs[0].flag = 0
                    self.WSs[0].rpt = self.WSs[0].s - (interval - accupyTime)
                    self.WSs[0].prod = p
                    self.rawProdNum -= 1
                    p.state = "atWS"
                    p.loc = self.WSs[0]
                else:
                    pass
                break
        self.time += interval
        return
    
    
    def lookforIdleWS(self, ws):
        for w in range(ws, self.wc):
            if self.WSs[w].state == "idle":
                return self.WSs[w].id - 1
        return self.wc - 1
    
    def transform(self):#状态等价转换
        loadedAgvs = []
        for agv in self.AGVs:
            if agv.state == "loaded":
                loadedAgvs.append(agv)
        if len(loadedAgvs) > 0:
            for agv in loadedAgvs:
                if agv.destLoc.state == "idle":
                    #修改产品状态
                    agv.prod.state = "atWS"
                    agv.prod.loc = agv.destLoc
                    
                    #修改道路状态    
                    agv.preLoc.state = "free"
                    #修改AGV状态
                    agv.preLoc = agv.destLoc
                    agv.destLoc = None
                    agv.state = "halfFree"
                    agv.bt = agv.rst_lt
                    agv.rst_lt = 0
                    #修改当前工位状态
                    agv.preLoc.state = "busyNoAgv"#工位有被释放的AGV，但未分配新的AGV
                    agv.preLoc.rpt = agv.preLoc.s + agv.bt
                    agv.preLoc.prod = agv.prod
                    
                    agv.prod = None
                else:
                    wf = self.lookforIdleWS(agv.preLoc.id)
                    while self.WSs[wf].id > agv.destLoc.id:
                        if self.WSs[wf].isLastWs == True and self.WSs[wf].state == "busyNoAgv":
                            self.WSs[wf].prod.state = "finish"
                            self.WSs[wf].prod.loc = None
                            if self.WSs[wf].prod.agv != None:
                                self.WSs[wf].prod.agv = None
                        #记录任务
                        # if ((self.WSs[wf-1].id, self.WSs[wf-1].prod.id)) not in self.WSs[wf-1].prod.agv.route:
                        #     self.WSs[wf-1].prod.agv.route.append((self.WSs[wf-1].id, self.WSs[wf-1].prod.id))
                        #     self.TASKs[self.WSs[wf-1].id - 1][self.WSs[wf-1].prod.id - 1].sTime = self.time + self.WSs[wf-1].RTI                         
                        self.WSs[wf].state = "busyNoAgv"
                        self.WSs[wf].prod = self.WSs[wf-1].prod
                        self.WSs[wf].prod.state = "atWS"
                        self.WSs[wf].prod.loc = self.WSs[wf]                            
                        self.WSs[wf].prod.agv.state = "halfFree"
                        self.WSs[wf].prod.agv.anchor_x = None
                        self.WSs[wf].prod.agv.anchor_y = None
                        self.WSs[wf].prod.agv.preLoc = self.WSs[wf]
                        self.WSs[wf].prod.agv.destLoc = None
                        self.WSs[wf].prod.agv.bt = self.WSs[wf].prod.agv.RTS + self.WSs[wf-1].d#修改
                        self.WSs[wf].prod.agv.prod = None
                        self.WSs[wf].rpt = self.WSs[wf].prod.agv.RTS + self.WSs[wf-1].d + self.WSs[wf].s#修改
                        self.WSs[wf].prod.agv = None
                        wf -= 1
                    if self.WSs[wf].isLastWs == True and self.WSs[wf].state == "busyNoAgv":
                        self.WSs[wf].prod.state = "finish"
                        self.WSs[wf].prod.loc = None
                        if self.WSs[wf].prod.agv != None:
                            self.WSs[wf].prod.agv = None
                    self.WSs[wf].state = "busyNoAgv"
                    self.WSs[wf].prod = agv.prod
                    self.WSs[wf].rpt = self.WSs[wf].s + agv.rst_lt
                    self.WSs[wf].prod.state = "atWS"
                    self.WSs[wf].prod.loc = self.WSs[wf]
                    agv.preLoc = self.WSs[wf]
                    agv.destLoc = None
                    agv.bt = agv.rst_lt
                    agv.rst_lt = 0
                    agv.state = "halfFree"
                    agv.prod = None
                    self.ROADs[wf-1].state = "free"
        return
    
    def findAllSolutions(self):
        count = 0
        vNum = 0
        l = []#每段内工位数量
        q = []#每段内分配AGV数量
        ws_in_section = [] #每段内需要分配AGV的工位
        idleWs = [] #空闲工位的ID
        agvsAssigable = []#所有参与分配的AGV的id
        agv_in_section = []#每段内的agv的id
        results = []#
        for w in range(self.wc - 1):
            if self.WSs[w].state != "idle":
                count += 1
            else:
                if count > 0:
                    idleWs.append(w)
                    l.append(count)
                    count = 0
                    continue
        if count > 0:
            l.append(count)
        if self.WSs[self.wc - 2].state != "idle":
            idleWs.append(self.wc - 1)

        for agv in self.AGVs:
            if agv.state != "unenable":
                vNum += 1
                agvsAssigable.append(agv.id)
                
        if sum(l) > vNum and self.unenableAgvNum > 0:
            vNum += 1
            self.AGVs[self.vc - self.unenableAgvNum].state = "free"
            self.AGVs[self.vc - self.unenableAgvNum].preLoc = self.WSs[0]
            agvsAssigable.append(self.AGVs[self.vc - self.unenableAgvNum].id)
            self.unenableAgvNum -= 1

        for i in range(1, vNum):
            for j in range(0, vNum - i):
                if self.AGVs[agvsAssigable[j] - 1].getDistToWS(self.WSs[0], self.d) > self.AGVs[agvsAssigable[j + 1] - 1].getDistToWS(self.WSs[0], self.d):
                    agvsAssigable[j], agvsAssigable[j + 1] = agvsAssigable[j + 1], agvsAssigable[j]

        if vNum > sum(l):
            self.AGVs[agvsAssigable[-1]-1].offLine()
            vNum -= 1
            
        for n in range(len(l)):
            if n == 0:
                q.append(math.ceil(l[n]*vNum/sum(l)))
            else:
                qn = min(math.ceil(l[n]*vNum/sum(l)), vNum - sum(q))
                q.append(qn)

        n = 0
        for w_id in idleWs:
            ws_in_section.append(list(range(self.WSs[w_id - q[n]].id, w_id + 1)))
            n += 1

        # tem_agvAssigable = copy.deepcopy(agvsAssigable)
        for n in range(len(l)):
            # agv_in_section.append(tem_agvAssigable[:q[n]])
            # del tem_agvAssigable[:q[n]]
            agv_in_section.append(agvsAssigable[sum(q[:n]):sum(q[:n])+q[n]])
            
            
        for i in range(len(q)):
            RPT = {}
            DIST = {}
            Fixed = []

            for temp_ws_id in ws_in_section[i]:
                RPT[temp_ws_id] = self.WSs[temp_ws_id - 1].rpt
            for temp_agv_id in agv_in_section[i]:
                for temp_ws_id in ws_in_section[i]:
                    DIST[temp_agv_id, temp_ws_id] = self.AGVs[temp_agv_id - 1].getDistToWS(self.WSs[temp_ws_id - 1], self.d)
            if q[i] > 0:
                solution = SA.sectionAllocate(agv_in_section[i], ws_in_section[i], Fixed, DIST, RPT, self.d)
                results.append(solution)
        
        branches = [[]]
        for pool in results:
            tmp = []
            for x in branches:
                for y in pool:
                    tmp.append(x+[y])
            branches = tmp
        return branches
    
    def findAllSolutions_init(self):
        count = 0
        vNum = 0
        l = []#每段内工位数量
        q = []#每段内分配AGV数量
        ws_in_section = [] #每段内需要分配AGV的工位
        idleWs = [] #空闲工位的ID
        agvsAssigable = []#所有参与分配的AGV的id
        agv_in_section = []#每段内的agv的id
        results = []#
        for w in range(self.wc - 1):
            if self.WSs[w].state != "idle":
                count += 1
            else:
                if count > 0:
                    idleWs.append(w)
                    l.append(count)
                    count = 0
                    continue
        if count > 0:
            l.append(count)
        if self.WSs[self.wc - 2].state != "idle":
            idleWs.append(self.wc - 1)

        for agv in self.AGVs:
            if agv.state != "unenable":
                vNum += 1
                agvsAssigable.append(agv.id)
                
        if sum(l) > vNum and self.unenableAgvNum > 0:
            vNum += 1
            self.AGVs[self.vc - self.unenableAgvNum].state = "free"
            self.AGVs[self.vc - self.unenableAgvNum].preLoc = self.WSs[0]
            agvsAssigable.append(self.AGVs[self.vc - self.unenableAgvNum].id)
            self.unenableAgvNum -= 1

        for i in range(1, vNum):
            for j in range(0, vNum - i):
                if self.AGVs[agvsAssigable[j] - 1].getDistToWS(self.WSs[0], self.d) > self.AGVs[agvsAssigable[j + 1] - 1].getDistToWS(self.WSs[0], self.d):
                    agvsAssigable[j], agvsAssigable[j + 1] = agvsAssigable[j + 1], agvsAssigable[j]

        if vNum > sum(l):
            self.AGVs[agvsAssigable[-1]-1].offLine()
            vNum -= 1
            
        # for n in range(len(l)):
        #     if n == 0:
        #         q.append(math.ceil(l[n]*vNum/sum(l)))
        #     else:
        #         qn = min(math.ceil(l[n]*vNum/sum(l)), vNum - sum(q))
        #         q.append(qn)
        q = distribute_resources(l,vNum)
        n = 0
        for w_id in idleWs:
            # ws_in_section.append(list(range(self.WSs[w_id - q[n]].id, w_id + 1)))
            ws_in_section.append(list(range(self.WSs[w_id - l[n]].id, w_id + 1)))
            n += 1

        # tem_agvAssigable = copy.deepcopy(agvsAssigable)
        for n in range(len(l)):
            # agv_in_section.append(tem_agvAssigable[:q[n]])
            # del tem_agvAssigable[:q[n]]
            agv_in_section.append(agvsAssigable[sum(q[:n]):sum(q[:n])+q[n]])
            
            
        for i in range(len(q)):
            # RPT = {}
            # DIST = {}
            # Fixed = []

            # for temp_ws_id in ws_in_section[i]:
            #     RPT[temp_ws_id] = self.WSs[temp_ws_id - 1].rpt
            # for temp_agv_id in agv_in_section[i]:
            #     for temp_ws_id in ws_in_section[i]:
            #         DIST[temp_agv_id, temp_ws_id] = self.AGVs[temp_agv_id - 1].getDistToWS(self.WSs[temp_ws_id - 1], self.d)
            if q[i] > 0:
                # solution = SA.sectionAllocate(agv_in_section[i], ws_in_section[i], Fixed, DIST, RPT, self.d)
                solution = [random_pair_new(agv_in_section[i], ws_in_section[i])]
                results.append(solution)
        
        branches = [[]]
        for pool in results:
            tmp = []
            for x in branches:
                for y in pool:
                    tmp.append(x+[y])
            branches = tmp
        return branches
    
    def findAllSolutions_repair(self):
        count = 0
        vNum = 0
        l = []#每段内工位数量
        q = []#每段内分配AGV数量
        ws_in_section = [] #每段内需要分配AGV的工位
        idleWs = [] #空闲工位的ID
        agvsAssigable = []#所有参与分配的AGV的id
        agv_in_section = []#每段内的agv的id
        results = []#
        for w in range(self.wc - 1):
            if self.WSs[w].state != "idle":
                count += 1
            else:
                if count > 0:
                    idleWs.append(w)
                    l.append(count)
                    count = 0
                    continue
        if count > 0:
            l.append(count)
        if self.WSs[self.wc - 2].state != "idle":
            idleWs.append(self.wc - 1)

        for agv in self.AGVs:
            if agv.state != "unenable":
                vNum += 1
                agvsAssigable.append(agv.id)
                
        if sum(l) > vNum and self.unenableAgvNum > 0:
            vNum += 1
            self.AGVs[self.vc - self.unenableAgvNum].state = "free"
            self.AGVs[self.vc - self.unenableAgvNum].preLoc = self.WSs[0]
            agvsAssigable.append(self.AGVs[self.vc - self.unenableAgvNum].id)
            self.unenableAgvNum -= 1

        for i in range(1, vNum):
            for j in range(0, vNum - i):
                if self.AGVs[agvsAssigable[j] - 1].getDistToWS(self.WSs[0], self.d) > self.AGVs[agvsAssigable[j + 1] - 1].getDistToWS(self.WSs[0], self.d):
                    agvsAssigable[j], agvsAssigable[j + 1] = agvsAssigable[j + 1], agvsAssigable[j]

        if vNum > sum(l):
            self.AGVs[agvsAssigable[-1]-1].offLine()
            vNum -= 1
            
        # for n in range(len(l)):
        #     if n == 0:
        #         q.append(math.ceil(l[n]*vNum/sum(l)))
        #     else:
        #         qn = min(math.ceil(l[n]*vNum/sum(l)), vNum - sum(q))
        #         q.append(qn)
        q = distribute_resources(l,vNum)
        n = 0
        for w_id in idleWs:
            ws_in_section.append(list(range(self.WSs[w_id - q[n]].id, w_id + 1)))
            n += 1

        # tem_agvAssigable = copy.deepcopy(agvsAssigable)
        # random.shuffle(agvsAssigable)
        for n in range(len(l)):
            # agv_in_section.append(tem_agvAssigable[:q[n]])
            # del tem_agvAssigable[:q[n]]
            agv_in_section.append(agvsAssigable[sum(q[:n]):sum(q[:n])+q[n]])
            
            
        for i in range(len(q)):
            RPT = {}
            DIST = {}
            Fixed = []

            for temp_ws_id in ws_in_section[i]:
                RPT[temp_ws_id] = self.WSs[temp_ws_id - 1].rpt
            for temp_agv_id in agv_in_section[i]:
                for temp_ws_id in ws_in_section[i]:
                    DIST[temp_agv_id, temp_ws_id] = self.AGVs[temp_agv_id - 1].getDistToWS(self.WSs[temp_ws_id - 1], self.d)
            if q[i] > 0:
                solution = SA.sectionAllocate_repair(agv_in_section[i], ws_in_section[i], Fixed, DIST, RPT, self.d)
                # solution = [random_pair(agv_in_section[i], ws_in_section[i])]
                results.append(solution)
        
        branches = [[]]
        for pool in results:
            tmp = []
            for x in branches:
                for y in pool:
                    tmp.append(x+[y])
            branches = tmp
        return branches
    
    def newFindAllSolutions(self):
        count = 0
        vNum = 0
        l = []#每段内工位数量
        q = []#每段内分配AGV数量
        qs = []
        # ws_in_section = [] #每段内需要分配AGV的工位
        idleWs = [] #空闲工位的ID
        agvsAssigable = []#所有参与分配的AGV的id
        # agv_in_section = []#每段内的agv的id
        
        for w in range(self.wc - 1):
            if self.WSs[w].state != "idle":
                count += 1
            else:
                if count > 0:
                    idleWs.append(w)
                    l.append(count)
                    count = 0
                    continue
        if count > 0:
            l.append(count)
        if self.WSs[self.wc - 2].state != "idle":
            idleWs.append(self.wc - 1)

        for agv in self.AGVs:
            if agv.state != "unenable":
                vNum += 1
                agvsAssigable.append(agv.id)
                
        if sum(l) > vNum and self.unenableAgvNum > 0:
            vNum += 1
            self.AGVs[self.vc - self.unenableAgvNum].state = "free"
            self.AGVs[self.vc - self.unenableAgvNum].preLoc = self.WSs[0]
            agvsAssigable.append(self.AGVs[self.vc - self.unenableAgvNum].id)
            self.unenableAgvNum -= 1

        for i in range(1, vNum):
            for j in range(0, vNum - i):
                if self.AGVs[agvsAssigable[j] - 1].getDistToWS(self.WSs[0], self.d) > self.AGVs[agvsAssigable[j + 1] - 1].getDistToWS(self.WSs[0], self.d):
                    agvsAssigable[j], agvsAssigable[j + 1] = agvsAssigable[j + 1], agvsAssigable[j]

        if vNum > sum(l):
            self.AGVs[agvsAssigable[-1]-1].offLine()
            vNum -= 1
        
        qs = QC.QnCalculate(vNum, l)
        
        allBranches = []
        for q in qs:
            results = []
            ws_in_section = [] #每段内需要分配AGV的工位
            agv_in_section = []#每段内的agv的id
            n = 0
            for w_id in idleWs:
                ws_in_section.append(range(self.WSs[w_id - q[n]].id, w_id + 1))
                n += 1
    
            # tem_agvAssigable = copy.deepcopy(agvsAssigable)
            for n in range(len(l)):
                # agv_in_section.append(tem_agvAssigable[:q[n]])
                # del tem_agvAssigable[:q[n]]
                agv_in_section.append(agvsAssigable[sum(q[:n]):sum(q[:n])+q[n]])
                
            for i in range(len(q)):
                RPT = {}
                DIST = {}
                Fixed = []
    
                for temp_ws_id in ws_in_section[i]:
                    RPT[temp_ws_id] = self.WSs[temp_ws_id - 1].rpt
                for temp_agv_id in agv_in_section[i]:
                    for temp_ws_id in ws_in_section[i]:
                        DIST[temp_agv_id, temp_ws_id] = self.AGVs[temp_agv_id - 1].getDistToWS(self.WSs[temp_ws_id - 1], self.d)
                if q[i] > 0:
                    solution = SA.sectionAllocate(agv_in_section[i], ws_in_section[i], Fixed, DIST, RPT, self.d)
                    results.append(solution)
            
            branches = [[]]
            for pool in results:
                tmp = []
                for x in branches:
                    for y in pool:
                        tmp.append(x+[y])
                branches = tmp
            allBranches = allBranches + branches
        return allBranches

    def newFindAllSolutions1(self):
        """
        考虑两种取整方式，向上取整和四舍五入。
        Returns
        -------
        allBranches : list
            一个决策阶段的所有分配方案.
        """
        count = 0
        vNum = 0
        l = []#每段内工位数量
        # q = []#每段内分配AGV数量
        qs = []
        # ws_in_section = [] #每段内需要分配AGV的工位
        idleWs = [] #空闲工位的ID
        agvsAssigable = []#所有参与分配的AGV的id
        # agv_in_section = []#每段内的agv的id
        
        for w in range(self.wc - 1):
            if self.WSs[w].state != "idle":
                count += 1
            else:
                if count > 0:
                    idleWs.append(w)
                    l.append(count)
                    count = 0
                    continue
        if count > 0:
            l.append(count)
        if self.WSs[self.wc - 2].state != "idle":
            idleWs.append(self.wc - 1)

        for agv in self.AGVs:
            if agv.state != "unenable":
                vNum += 1
                agvsAssigable.append(agv.id)
                
        if sum(l) > vNum and self.unenableAgvNum > 0:
            vNum += 1
            self.AGVs[self.vc - self.unenableAgvNum].state = "free"
            self.AGVs[self.vc - self.unenableAgvNum].preLoc = self.WSs[0]
            agvsAssigable.append(self.AGVs[self.vc - self.unenableAgvNum].id)
            self.unenableAgvNum -= 1

        for i in range(1, vNum):
            for j in range(0, vNum - i):
                if self.AGVs[agvsAssigable[j] - 1].getDistToWS(self.WSs[0], self.d) > self.AGVs[agvsAssigable[j + 1] - 1].getDistToWS(self.WSs[0], self.d):
                    agvsAssigable[j], agvsAssigable[j + 1] = agvsAssigable[j + 1], agvsAssigable[j]

        if vNum > sum(l):
            self.AGVs[agvsAssigable[-1]-1].offLine()
            vNum -= 1
        
        
        # print(qs)
        q1 = []
        for n in range(len(l)):
            if n == 0:
                q1.append(math.ceil(l[n]*vNum/sum(l)))
            else:
                qn = min(math.ceil(l[n]*vNum/sum(l)), vNum - sum(q1))
                q1.append(qn)
        qs.append(q1)
        
        q2 = []
        for n in range(len(l)):
            if n == 0:
                q2.append(myRound.myRound(l[n]*vNum/sum(l)))
            else:
                qn = min(myRound.myRound(l[n]*vNum/sum(l)), vNum - sum(q2))
                q2.append(qn)
                
        while sum(q2) < vNum:
            for n in range(len(l)):
                if q2[n] < l[n]:
                    q2[n] += 1
                    break
        if q1 != q2:
            qs.append(q2)  
        qs = QC.QAll(vNum, l)
        
        allBranches = []
        for q in qs:
            results = []
            ws_in_section = [] #每段内需要分配AGV的工位
            agv_in_section = []#每段内的agv的id
            n = 0
            for w_id in idleWs:
                ws_in_section.append(range(self.WSs[w_id - q[n]].id, w_id + 1))
                n += 1
    
            # tem_agvAssigable = copy.deepcopy(agvsAssigable)
            for n in range(len(l)):
                # agv_in_section.append(tem_agvAssigable[:q[n]])
                # del tem_agvAssigable[:q[n]]
                agv_in_section.append(agvsAssigable[sum(q[:n]):sum(q[:n])+q[n]])
                
            for i in range(len(q)):
                RPT = {}
                DIST = {}
                Fixed = []
    
                for temp_ws_id in ws_in_section[i]:
                    RPT[temp_ws_id] = self.WSs[temp_ws_id - 1].rpt
                for temp_agv_id in agv_in_section[i]:
                    for temp_ws_id in ws_in_section[i]:
                        DIST[temp_agv_id, temp_ws_id] = self.AGVs[temp_agv_id - 1].getDistToWS(self.WSs[temp_ws_id - 1], self.d)
                if q[i] > 0:
                    solution = SA.sectionAllocate(agv_in_section[i], ws_in_section[i], Fixed, DIST, RPT, self.d)
                    results.append(solution)
            
            branches = [[]]
            for pool in results:
                tmp = []
                for x in branches:
                    for y in pool:
                        tmp.append(x+[y])
                branches = tmp
            allBranches = allBranches + branches
        return allBranches    

    def createBranches(self, branches):
        allBranches = []
        for solution in branches:
            temp_stage = copy(self)
            temp_stage.level = self.level + 1
            for section in solution:
                for agv_id, ws_id in section:
                    agvId, wsId = agv_id - 1, ws_id - 1
                    if temp_stage.AGVs[agvId].state in ["assigned"] and temp_stage.AGVs[agvId].destLoc.flag == 0:
                        # if temp_stage.AGVs[agvId].prod.agv.id == agv_id:
                        temp_stage.AGVs[agvId].prod.agv = None
                        temp_stage.AGVs[agvId].destLoc.state = "busyNoAgv"
                    if temp_stage.AGVs[agvId].state in ["waitLoad"] :#and temp_stage.AGVs[agvId].preLoc.flag == 0
                        temp_stage.AGVs[agvId].prod.agv = None
                        temp_stage.AGVs[agvId].preLoc.state = "busyNoAgv"
                    if temp_stage.AGVs[agvId].state in ["halfFree"] and temp_stage.AGVs[agvId].preLoc.flag == 0:
                        # temp_stage.AGVs[agvId].prod.agv = None
                        temp_stage.AGVs[agvId].preLoc.state = "busyNoAgv"
                    temp_stage.WSs[wsId].flag = 1
                    temp_stage.WSs[wsId].state = "busyAgv"
                    # if temp_stage.AGVs[agvId].state == "halfFree":
                    #     temp_stage.AGVs[agvId].preLoc.prod.agv = None
                    temp_stage.WSs[wsId].prod.agv = temp_stage.AGVs[agvId]#绑定AGV和产品
                    temp_stage.AGVs[agvId].prod = temp_stage.WSs[wsId].prod#绑定AGV和产品
                    temp_stage.AGVs[agvId].lastDestLoc = copy(temp_stage.AGVs[agvId].preLoc)
                    temp_stage.AGVs[agvId].destLoc = temp_stage.WSs[wsId]
                    if temp_stage.AGVs[agvId].state in ["free"]:
                        if temp_stage.AGVs[agvId].destLoc.id < temp_stage.AGVs[agvId].preLoc.id:
                            temp_stage.AGVs[agvId].direction = "R"
                        elif temp_stage.AGVs[agvId].destLoc.id > temp_stage.AGVs[agvId].preLoc.id:
                            temp_stage.AGVs[agvId].direction = "L"
                        else:
                            temp_stage.AGVs[agvId].direction = None
                        if temp_stage.AGVs[agvId].direction == "R":
                            temp_stage.AGVs[agvId].rst_dht = temp_stage.AGVs[agvId].getDistToWS(temp_stage.AGVs[agvId].destLoc,temp_stage.d)
                            temp_stage.AGVs[agvId].state = "assigned"
                            temp_stage.AGVs[agvId].bt = 0
                        elif temp_stage.AGVs[agvId].direction == "L":
                            temp_stage.AGVs[agvId].rst_dht = temp_stage.AGVs[agvId].getDistToWS(temp_stage.AGVs[agvId].destLoc,temp_stage.d)
                            temp_stage.AGVs[agvId].state = "assigned"
                            temp_stage.AGVs[agvId].bt = 0
                        else:
                            temp_stage.AGVs[agvId].bt = 0
                            temp_stage.AGVs[agvId].state = "waitLoad"
                            temp_stage.AGVs[agvId].destLoc = temp_stage.WSs[ws_id]
                            temp_stage.AGVs[agvId].rst_dht = 0     
                            temp_stage.AGVs[agvId].direction = None
                    elif temp_stage.AGVs[agvId].state == "halfFree":
                        temp_stage.AGVs[agvId].direction = "L"
                        if temp_stage.AGVs[agvId].lastDestLoc.id <= temp_stage.AGVs[agvId].destLoc.id:
                            temp_stage.AGVs[agvId].rst_dht = sum(temp_stage.d[temp_stage.AGVs[agvId].lastDestLoc.id-1:temp_stage.AGVs[agvId].destLoc.id-1])+temp_stage.AGVs[agvId].bt
                        else:
                            temp_stage.AGVs[agvId].rst_dht = sum(temp_stage.d[temp_stage.AGVs[agvId].destLoc.id-1:temp_stage.AGVs[agvId].lastDestLoc.id-1]) + 2*temp_stage.h +temp_stage.AGVs[agvId].bt
                        temp_stage.AGVs[agvId].state = "assigned"
                        temp_stage.AGVs[agvId].haveReach = 0
                        temp_stage.AGVs[agvId].bt = 0
                        
                    elif temp_stage.AGVs[agvId].state == "waitLoad":
                        if temp_stage.AGVs[agvId].destLoc.id < temp_stage.AGVs[agvId].preLoc.id:
                            temp_stage.AGVs[agvId].direction = "R"
                            temp_stage.AGVs[agvId].state = "assigned"
                            temp_stage.AGVs[agvId].rst_dht = temp_stage.AGVs[agvId].getDistToWS(temp_stage.AGVs[agvId].destLoc,temp_stage.d)
                            if temp_stage.WSs[wsId].flag==0:
                                temp_stage.AGVs[agvId].preLoc.state = "busyNoAgv"
                        elif temp_stage.AGVs[agvId].destLoc.id > temp_stage.AGVs[agvId].preLoc.id:
                            temp_stage.AGVs[agvId].direction = "L"
                            temp_stage.AGVs[agvId].state = "assigned"
                            temp_stage.AGVs[agvId].rst_dht = temp_stage.AGVs[agvId].getDistToWS(temp_stage.AGVs[agvId].destLoc,temp_stage.d)
                            if temp_stage.WSs[wsId].flag ==0:
                                temp_stage.AGVs[agvId].preLoc.state = "busyNoAgv"
                        else:
                            temp_stage.AGVs[agvId].state = "waitLoad"
                            temp_stage.AGVs[agvId].destLoc = temp_stage.WSs[ws_id]
                            temp_stage.AGVs[agvId].rst_dht = 0     
                            temp_stage.AGVs[agvId].direction = None
                            temp_stage.AGVs[agvId].preLoc.state = "busyAgv"
                        temp_stage.AGVs[agvId].bt = 0
                    else:                          
                        if sum(temp_stage.d[:temp_stage.AGVs[agvId].destLoc.id - 1]) < temp_stage.AGVs[agvId].anchor_x:
                            temp_stage.AGVs[agvId].direction = "R"
                        elif sum(temp_stage.d[:temp_stage.AGVs[agvId].destLoc.id - 1]) > temp_stage.AGVs[agvId].anchor_x:
                            temp_stage.AGVs[agvId].direction = "L"
                        else:
                            temp_stage.AGVs[agvId].direction = None
                        temp_stage.AGVs[agvId].rst_dht = temp_stage.AGVs[agvId].getDistToWS(temp_stage.AGVs[agvId].destLoc,temp_stage.d)
                        temp_stage.AGVs[agvId].bt = 0
                        temp_stage.AGVs[agvId].state = "assigned"
            allBranches.append(temp_stage)
        return allBranches

class CBS:
    def __init__(self, w, p, v, s, d, h):
        self.w = w
        self.p = p
        self.v = v
        self.s = s
        self.d = d
        self.h = h
    
    def CBS_A(self):
        """
        计算所有分支情况

        Returns
        -------
        makespan
            最小的完工时间.
        timeConsume
            程序花费时间.

        """
        makespans = []
        t1 = time.perf_counter()
        stage = STAGE(self.v,self.w,self.p,self.s,self.d,self.h)
        stage.beginProcess()
        branchStages = []
        branchStages.append(stage)
        # branchesCount = [1]
        while len(branchStages) > 0:
            stage = branchStages.pop(0)
            while stage.PRODs[-1].state != "finish":
                stage.updateWSsRTI()
                stage.updateAGVsRTS()
                stage.update()#状态转移
                if stage.PRODs[-1].state == "finish":
                    makespans.append(stage.time)
                    # print(stage.time)
                    break
                stage.updateWSsRTI()
                stage.updateAGVsRTS()
                stage.transform()#状态转换
                brancheSolution = stage.findAllSolutions()
                if brancheSolution[0] != []:
                    branchStages.extend(stage.createBranches(brancheSolution))
                    stage = branchStages.pop()
                # branchesCount.append(len(branchStages))
                # plt.plot(branchesCount)
                # plt.show()
        t2 = time.perf_counter()
        # plt.plot(branchesCount)
        # plt.show()
        return min(makespans), t2-t1
    
    def CBS_O(self):
        """
        只计算一个结果，不做分支搜索。

        Returns
        -------
        makespan
            最小的完工时间.
        timeConsume
            程序花费时间.
        """
        t1 = time.perf_counter()
        stage = STAGE(self.v, self.w, self.p, self.s, self.d, self.h)
        stage.beginProcess()
        while True:
            stage.updateWSsRTI()
            stage.updateAGVsRTS()
            stage.update()#状态转移
            # print(stage.time)
            if stage.PRODs[-1].state == "finish":
                t2 = time.perf_counter()
                return stage.time, t2-t1
            stage.updateWSsRTI()
            stage.updateAGVsRTS()
            stage.transform()#状态转换
            brancheSolution = stage.findAllSolutions()
            if brancheSolution[0] != []:
                stage = stage.createBranches([brancheSolution[0]])[0]
    
    def CBS_N(self, n):
        """
        计算n个分支，n是池子大小，当池中分支数量少于n时，可以加入新的分支。

        Parameters
        ----------
        n : int
            池子大小.

        Returns
        -------
        makespan
            最小的完工时间.
        timeConsume
            程序花费时间.

        """
        makespans = []
        t1 = time.perf_counter()
        stage = STAGE(self.v, self.w, self.p, self.s, self.d, self.h)
        stage.beginProcess()
        branchStages = []
        branchStages.append(stage)
        while len(branchStages) > 0:
            stage = branchStages.pop(0)
            while stage.PRODs[-1].state != "finish":
                stage.updateWSsRTI()
                stage.updateAGVsRTS()
                stage.update()#状态转移
                if stage.PRODs[-1].state == "finish":
                    makespans.append(stage.time)
                    break
                stage.updateWSsRTI()
                stage.updateAGVsRTS()
                stage.transform()#状态转换
                brancheSolution = stage.findAllSolutions()
                if brancheSolution[0] != [] and len(branchStages) <= n:
                    branchStages.extend(stage.createBranches(brancheSolution[:n - len(branchStages)]))
                    stage = branchStages.pop()
        t2 = time.perf_counter()
        # print(len(makespans))
        return min(makespans), t2-t1
    
    def CBS_L(self, n, l):
        """
        前l层的分支全部加入池中，后面的分支，只有当池中分支数量小于n才能加入。

        Parameters
        ----------
        n : int
            分支池大小.
        l : int
            前l层分支全部保存.

        Returns
        -------
        makespan
            最小的完工时间.
        timeConsume
            程序花费时间.

        """
        makespans = []
        t1 = time.perf_counter()
        stage = STAGE(self.v, self.w, self.p, self.s, self.d, self.h)
        stage.beginProcess()
        branchStages = []
        branchStages.append(stage)
        while len(branchStages) > 0:
            stage = branchStages.pop(0)
            while stage.PRODs[-1].state != "finish":
                stage.updateWSsRTI()
                stage.updateAGVsRTS()
                stage.update()#状态转移
                if stage.PRODs[-1].state == "finish":
                    makespans.append(stage.time)
                    break
                stage.updateWSsRTI()
                stage.updateAGVsRTS()
                stage.transform()#状态转换
                brancheSolution = stage.findAllSolutions()
                if brancheSolution[0] != []:
                    if stage.level <= l-1:
                        branchStages.extend(stage.createBranches(brancheSolution))
                    elif len(branchStages) <= n:
                        branchStages.extend(stage.createBranches(brancheSolution[:n - len(branchStages)]))
                    stage = branchStages.pop(0)
        t2 = time.perf_counter()
        print(len(makespans))
        return min(makespans), t2-t1

    def CBS_NL(self, n, l):
        """
        将前l层分支作为种子，当分支池中没有分支时，从种子池中取一个进行计算。分支池大小为n。

        Parameters
        ----------
        n : int
            分支池大小.
        l : int
            种子分支的最大层数.

        Returns
        -------
        makespan
            最小的完工时间.
        timeConsume
            程序花费时间.

        """
        makespans = []
        t1 = time.perf_counter()
        stage = STAGE(self.v, self.w, self.p, self.s, self.d, self.h)
        stage.beginProcess()
        seed = []
        branchStages = []
        seed.append(stage)
        while len(seed) > 0:
            branchStages.append(seed.pop())
            while len(branchStages) > 0:
                stage = branchStages.pop()
                while stage.PRODs[-1].state != "finish":
                    stage.updateWSsRTI()
                    stage.updateAGVsRTS()
                    stage.update()#状态转移
                    if stage.PRODs[-1].state == "finish":
                        makespans.append(stage.time)
                        break
                    stage.updateWSsRTI()
                    stage.updateAGVsRTS()
                    stage.transform()#状态转换
                    brancheSolution = stage.findAllSolutions()
                    if brancheSolution[0] != []:
                        if stage.level <= l-1:
                            seed.extend(stage.createBranches(brancheSolution))
                            stage = seed.pop()
                        elif len(branchStages) <= n:
                            branchStages.extend(stage.createBranches(brancheSolution[:n - len(branchStages)]))
                            stage = branchStages.pop()
        t2 = time.perf_counter()
        return min(makespans), t2-t1
    

# 你原文件里已经有 copy(originObj) 的深拷贝函数
# 以及 STAGE 类
# 这里假设同文件可直接访问：STAGE, copy


class SegmentLNSMILP:
    def __init__(self, w, p, v, s, d, h,
                 Imax=200,              # LNS 迭代次数
                 Ld=5,                  # destroy窗口长度（删除连续决策点数）
                 K=1,                   # repair时每个决策点最多试K个候选
                 rollout_depth=0,        # 评分时短rollout深度（0=只用cheap score）
                 accept_worse=True,     # baseline默认False（只接受改进解）；True可开SA/阈值
                 seed=0,
                 use_new_find=False):     # True: newFindAllSolutions1, False: findAllSolutions
        self.w = w
        self.p = p
        self.v = v
        self.s = s
        self.d = d
        self.h = h

        self.Imax = Imax
        self.Ld = Ld
        self.K = K
        self.rollout_depth = rollout_depth
        self.accept_worse = accept_worse
        self.seed = seed
        self.use_new_find = use_new_find

        random.seed(seed)

    # ---------- 基础：推进到下一个“需要决策”的时刻 ----------
    def _simulate_to_decision(self, stage):
        """
        推进 stage 直到：
        - finish -> 返回 "finish"
        - 到达一个需要AGV分配的决策点 -> 返回 branches (list of solutions)
        """
        while stage.PRODs[-1].state != "finish":
            stage.updateWSsRTI()
            stage.updateAGVsRTS()
            stage.update()
            if stage.PRODs[-1].state == "finish":
                return "finish"

            stage.updateWSsRTI()
            stage.updateAGVsRTS()
            stage.transform()
            branches = stage.findAllSolutions()

            if branches and branches[0] != []:
                return branches

        return "finish"
    
    def _simulate_to_decision_repair(self, stage):
        """
        推进 stage 直到：
        - finish -> 返回 "finish"
        - 到达一个需要AGV分配的决策点 -> 返回 branches (list of solutions)
        """
        while stage.PRODs[-1].state != "finish":
            stage.updateWSsRTI()
            stage.updateAGVsRTS()
            stage.update()
            if stage.PRODs[-1].state == "finish":
                return "finish"

            stage.updateWSsRTI()
            stage.updateAGVsRTS()
            stage.transform()
            branches = stage.findAllSolutions_repair()

            if branches and branches[0] != []:
                return branches

        return "finish"
    
    def _simulate_to_decision_init(self, stage):
        """
        推进 stage 直到：
        - finish -> 返回 "finish"
        - 到达一个需要AGV分配的决策点 -> 返回 branches (list of solutions)
        """
        while stage.PRODs[-1].state != "finish":
            stage.updateWSsRTI()
            stage.updateAGVsRTS()
            stage.update()
            if stage.PRODs[-1].state == "finish":
                return "finish"

            stage.updateWSsRTI()
            stage.updateAGVsRTS()
            stage.transform()
            branches = stage.findAllSolutions_init()

            if branches and branches[0] != []:
                return branches

        return "finish"

    # ---------- 基础：应用一个“分段分配方案”（solution）生成下一stage ----------
    def _apply_solution(self, stage, solution):
        """
        solution: 形如 stage.findAllSolutions()/newFindAllSolutions1() 返回的一个元素
                  即：solution = [section1_pairs, section2_pairs, ...]
                  每个 section_pairs = [(agv_id, ws_id), ...]
        """
        return stage.createBranches([solution])[0]

    # ---------- 构造：生成一个初始可行 trace（完全贴合CBS_O逻辑） ----------
    def build_initial_trace(self):
        """
        贪婪构造：每个决策点取 branches[0]（你的代码里它通常是一个“最优/最靠前”候选）
        返回：trace(list), makespan(float)
        """
        stage = STAGE(self.v, self.w, self.p, self.s, self.d, self.h)
        stage.beginProcess()
        trace = []

        while True:
            res = self._simulate_to_decision_init(stage)
            if res == "finish":
                return trace, stage.time

            # res 是 branches
            sol = res[0]
            trace.append(sol)
            stage = self._apply_solution(stage, sol)
            
    def new_build_initial_trace(self):
        """
        随机策略构造初始解（不再用 branches[0] 的贪婪逻辑）
    
        思路：
        - 每到一个决策点，newFindAllSolutions1()/findAllSolutions 会返回 branches（很多候选分配方案）
        - 我们随机从 branches 里挑一个可用方案 sol，然后 apply，记录进 trace
        - 若你担心“纯随机太差”，可以用 random_topK：先随机打乱再只在前K里选，兼顾随机性与质量
    
        返回：
        trace(list of solutions), makespan(float)
        """
        stage = STAGE(self.v, self.w, self.p, self.s, self.d, self.h)
        stage.beginProcess()
        trace = []
    
        # 你可以把这两个参数做成 self 的超参数
        random_topK = getattr(self, "init_random_topK", None)  # 例如设为 10
        max_retry = getattr(self, "init_max_retry", 20)        # 防止极端情况反复失败
    
        while True:
            res = self._simulate_to_decision_init(stage)
            if res == "finish":
                return trace, stage.time
    
            branches = list(res)
            if not branches or branches[0] == []:
                # 理论上 _simulate_to_decision 不会返回空，但做个防御
                return trace, stage.time
    
            # 随机挑选：可选只在前 random_topK 个里抽（先打乱）
            random.shuffle(branches)
            if isinstance(random_topK, int) and random_topK > 0:
                pool = branches[:min(random_topK, len(branches))]
            else:
                pool = branches
    
            # 纯随机选一个候选 sol
            sol = random.choice(pool)
    
            # 应用 sol（若你担心某些 sol 会触发异常，可做重试）
            tried = 0
            applied = False
            while tried < max_retry and not applied:
                try:
                    stage = self._apply_solution(stage, sol)
                    trace.append(sol)
                    applied = True
                except Exception:
                    tried += 1
                    if len(pool) == 0:
                        break
                    sol = random.choice(pool)
    
            if not applied:
                # 如果极端情况下应用失败，就退回到一个稳妥选择（例如 pool[0]）
                sol = pool[0]
                stage = self._apply_solution(stage, sol)
                trace.append(sol)
        # ---------- 评估：重放trace得到makespan ----------
        def evaluate_trace(self, trace):
            stage = STAGE(self.v, self.w, self.p, self.s, self.d, self.h)
            stage.beginProcess()
            t = 0
            while True:
                res = self._simulate_to_decision(stage)
                if res == "finish":
                    return stage.time
    
                if t < len(trace):
                    sol = trace[t]
                else:
                    # trace不够长就贪婪补全
                    sol = res[0]
    
                stage = self._apply_solution(stage, sol)
                t += 1

    # ---------- 修复：从prefix重放到t1，再开始rollout构造到finish ----------
    def _repair_from_prefix(self, prefix):
        """
        返回：trace_new, makespan_new
        """
        stage = STAGE(self.v, self.w, self.p, self.s, self.d, self.h)
        stage.beginProcess()
        trace_new = []

        # 1) replay prefix
        for sol in prefix:
            res = self._simulate_to_decision_repair(stage)
            if res == "finish":
                return trace_new, stage.time
            stage = self._apply_solution(stage, sol)
            trace_new.append(sol)

        # 2) rollout 后续决策直到finish
        while True:
            res = self._simulate_to_decision_repair(stage)
            if res == "finish":
                return trace_new, stage.time

            branches = res
            # 取候选池：打乱后截断K个（保持多样性）
            cand = list(branches)
            # random.shuffle(cand)
            # cand = cand[:min(self.K, len(cand))]

            best_sol = cand[0]
            # best_score = None

            # for sol in cand:
            # #     # 用短rollout评分：更贴近最终makespan；比完整评估便宜很多
            #     score = self._score_solution_by_short_rollout(stage, sol, depth=self.rollout_depth)
            #     if best_score is None or score < best_score:
            #         best_score = score
            #         best_sol = sol

            stage = self._apply_solution(stage, best_sol)
            trace_new.append(best_sol)

    def _score_solution_by_short_rollout(self, stage, sol, depth=2):
        """
        对候选 sol 做一个“短rollout评分”：
        - depth=0：只用 cheap 指标（末端工位RTI）
        - depth>0：应用 sol 后，继续贪婪执行 depth 个决策点，再用 (time + tail_RTI) 近似
        """
        st = copy(stage)
        st = self._apply_solution(st, sol)

        if depth <= 0:
            st.updateWSsRTI()
            return st.time + st.WSs[-1].RTI

        steps = 0
        while steps < depth:
            res = self._simulate_to_decision(st)
            if res == "finish":
                return st.time
            greedy_sol = res[0]
            st = self._apply_solution(st, greedy_sol)
            steps += 1

        st.updateWSsRTI()
        return st.time + st.WSs[-1].RTI

    # ---------- Destroy：删除连续决策窗口 ----------
    def _destroy(self, trace):
        if len(trace) == 0:
            return [], 0, 0
    
        destroy_len = random.randint(1, min(self.Ld, len(trace)))
        t1 = len(trace) - destroy_len
    
        prefix = trace[:t1]
    
        return prefix, t1, len(trace)

    # ---------- 主程序 ----------
    def run(self):
        t0 = time.perf_counter()

        # init
        trace, ms = self.build_initial_trace()
        trace_best, ms_best = list(trace), ms

        # LNS
        for it in range(self.Imax):
            if len(trace) == 0:
                break

            prefix, t1, t2 = self._destroy(trace)

            # repair
            trace_new, ms_new = self._repair_from_prefix(prefix)

        #     # accept
            if ms_new < ms:
                trace, ms = trace_new, ms_new
                if ms_new < ms_best:
                    trace_best, ms_best = list(trace_new), ms_new
            else:
                # baseline默认不接受劣解；若想开SA等，可在这里加
                if self.accept_worse:
                    # 简单阈值接受（可替换为SA）
                    if ms_new <= ms * 1.5:
                        trace, ms = trace_new, ms_new

        t1 = time.perf_counter()
        return ms_best, trace_best, (t1 - t0)
    
# 你原工程里应已存在：
# - STAGE
# - copy  (你自己写的pickle深拷贝函数)

class SegmentLNSMILP_New:
    def __init__(self, w, p, v, s, d, h,
                 Imax=200,              # LNS 迭代次数
                 Ld=5,                  # destroy窗口最大长度（连续决策点数）
                 K=1,                   # repair时每个决策点最多试K个候选（若K=1就是选1个）
                 rollout_depth=0,        # 评分时短rollout深度（0=只用cheap score）
                 accept_worse=True,      # True时允许接受一定程度的劣解
                 seed=0,
                 use_new_find=False):    # 这里你目前没用到，我保留
        self.w = w
        self.p = p
        self.v = v
        self.s = s
        self.d = d
        self.h = h

        self.Imax = Imax
        self.Ld = Ld
        self.K = K
        self.rollout_depth = rollout_depth
        self.accept_worse = accept_worse
        self.seed = seed
        self.use_new_find = use_new_find

        random.seed(seed)

    # ---------- 基础：推进到下一个“需要决策”的时刻（用于评估/短rollout） ----------
    def _simulate_to_decision(self, stage):
        while stage.PRODs[-1].state != "finish":
            stage.updateWSsRTI()
            stage.updateAGVsRTS()
            stage.update()
            if stage.PRODs[-1].state == "finish":
                return "finish"

            stage.updateWSsRTI()
            stage.updateAGVsRTS()
            stage.transform()
            branches = stage.findAllSolutions()
            if branches and branches[0] != []:
                return branches
        return "finish"

    # ---------- 修复专用决策推进（你有 repair 版本） ----------
    def _simulate_to_decision_repair(self, stage):
        while stage.PRODs[-1].state != "finish":
            stage.updateWSsRTI()
            stage.updateAGVsRTS()
            stage.update()
            if stage.PRODs[-1].state == "finish":
                return "finish"

            stage.updateWSsRTI()
            stage.updateAGVsRTS()
            stage.transform()
            branches = stage.findAllSolutions_repair()
            if branches and branches[0] != []:
                return branches
        return "finish"

    # ---------- 初始解构造专用决策推进（你有 init 版本） ----------
    def _simulate_to_decision_init(self, stage):
        while stage.PRODs[-1].state != "finish":
            stage.updateWSsRTI()
            stage.updateAGVsRTS()
            stage.update()
            if stage.PRODs[-1].state == "finish":
                return "finish"

            stage.updateWSsRTI()
            stage.updateAGVsRTS()
            stage.transform()
            branches = stage.findAllSolutions_init()
            if branches and branches[0] != []:
                return branches
        return "finish"

    # ---------- 应用一个“分段分配方案”（solution）生成下一stage ----------
    def _apply_solution(self, stage, solution):
        return stage.createBranches([solution])[0]

    # ---------- 初始解：贪婪或随机（二选一你自己用） ----------
    def build_initial_trace(self):
        stage = STAGE(self.v, self.w, self.p, self.s, self.d, self.h)
        stage.beginProcess()
        trace = []
        while True:
            res = self._simulate_to_decision_init(stage)
            if res == "finish":
                return trace, stage.time
            sol = res[0]
            trace.append(sol)
            stage = self._apply_solution(stage, sol)

    def new_build_initial_trace(self):
        stage = STAGE(self.v, self.w, self.p, self.s, self.d, self.h)
        stage.beginProcess()
        trace = []

        random_topK = getattr(self, "init_random_topK", None)  # 例如 10
        max_retry = getattr(self, "init_max_retry", 20)

        while True:
            res = self._simulate_to_decision_init(stage)
            if res == "finish":
                return trace, stage.time

            branches = list(res)
            if not branches or branches[0] == []:
                return trace, stage.time

            random.shuffle(branches)
            if isinstance(random_topK, int) and random_topK > 0:
                pool = branches[:min(random_topK, len(branches))]
            else:
                pool = branches

            sol = random.choice(pool)

            tried = 0
            applied = False
            while tried < max_retry and not applied:
                try:
                    stage = self._apply_solution(stage, sol)
                    trace.append(sol)
                    applied = True
                except Exception:
                    tried += 1
                    sol = random.choice(pool)

            if not applied:
                sol = pool[0]
                stage = self._apply_solution(stage, sol)
                trace.append(sol)

    # ---------- 评估：重放trace得到makespan ----------
    def evaluate_trace(self, trace):
        stage = STAGE(self.v, self.w, self.p, self.s, self.d, self.h)
        stage.beginProcess()
        t = 0
        while True:
            res = self._simulate_to_decision(stage)
            if res == "finish":
                return stage.time

            if t < len(trace):
                sol = trace[t]
            else:
                sol = res[0]  # 补全

            stage = self._apply_solution(stage, sol)
            t += 1

    # ---------- 短rollout评分 ----------
    def _score_solution_by_short_rollout(self, stage, sol, depth=0):
        st = copy(stage)
        st = self._apply_solution(st, sol)

        if depth <= 0:
            st.updateWSsRTI()
            return st.time + st.WSs[-1].RTI

        steps = 0
        while steps < depth:
            res = self._simulate_to_decision(st)
            if res == "finish":
                return st.time
            greedy_sol = res[0]
            st = self._apply_solution(st, greedy_sol)
            steps += 1

        st.updateWSsRTI()
        return st.time + st.WSs[-1].RTI

    # ---------- 工具：把 sol 转成可比较的 key（用于判断 suffix 某步是否还能沿用） ----------
    def _sol_key(self, sol):
        """
        你的 sol 通常是 list[section]，section 是 list[(agv_id, ws_id)]。
        list 不可hash，所以转成 tuple 的规范形式。
        """
        try:
            return tuple(tuple((int(a), int(w)) for (a, w) in section) for section in sol)
        except Exception:
            # 如果 sol 结构更复杂，退化为字符串比较（慢一点但稳）
            return str(sol)

    # ---------- 工具：从 branches 中选一个（可用K、rollout_depth控制强度） ----------
    def _pick_one_from_branches(self, stage, branches):
        cand = list(branches)
        if not cand:
            return None

        # 你现在 K=1、depth=0 就会非常弱（效果差），K大/depth大就更强
        random.shuffle(cand)
        cand = cand[:min(self.K, len(cand))] if self.K is not None and self.K > 0 else cand

        best_sol = cand[0]
        if self.rollout_depth <= 0 and (self.K == 1):
            # 最弱版本：直接拿第一个（随机打乱后的第一个）
            return best_sol

        best_score = None
        for sol in cand:
            score = self._score_solution_by_short_rollout(stage, sol, depth=self.rollout_depth)
            if best_score is None or score < best_score:
                best_score = score
                best_sol = sol
        return best_sol

    # ---------- 真正的 Destroy：返回 prefix, window_len, suffix ----------
    def _destroy_window(self, trace):
        """
        真正局部窗口破坏：
        - 随机选起点 t1
        - 窗口长度 L ~ U{1,...,Ld}
        - t2 = min(len(trace), t1+L)
        返回：
          prefix = trace[:t1]
          window_len = t2 - t1
          suffix = trace[t2:]
          t1, t2
        """
        if len(trace) == 0:
            return [], 0, [], 0, 0

        t1 = random.randint(0, len(trace) - 1)
        L = random.randint(1, max(1, self.Ld))
        t2 = min(len(trace), t1 + L)

        prefix = trace[:t1]
        suffix = trace[t2:]
        window_len = t2 - t1
        return prefix, window_len, suffix, t1, t2

    # ---------- 真正的中段修复：只修 window，suffix 尽量沿用，不行就地修 ----------
    def _repair_middle_window(self, prefix, window_len, suffix):
        """
        返回：trace_new, makespan_new
        逻辑：
        1) replay prefix（固定不动）
        2) 修复 window_len 步（局部重建）
        3) 尽量 replay suffix：能沿用就沿用；不能沿用则从当前 branches 选替代（就地修复）
        4) suffix 用完仍未 finish -> 继续 rollout 到 finish
        """
        stage = STAGE(self.v, self.w, self.p, self.s, self.d, self.h)
        stage.beginProcess()
        trace_new = []

        # 1) replay prefix
        for sol in prefix:
            res = self._simulate_to_decision_repair(stage)
            if res == "finish":
                return trace_new, stage.time
            stage = self._apply_solution(stage, sol)
            trace_new.append(sol)

        # 2) repair window (exactly window_len decisions)
        for _ in range(window_len):
            res = self._simulate_to_decision_repair(stage)
            if res == "finish":
                return trace_new, stage.time
            branches = res
            chosen = self._pick_one_from_branches(stage, branches)
            if chosen is None:
                return None, None
            stage = self._apply_solution(stage, chosen)
            trace_new.append(chosen)

        # 3) try replay suffix; if infeasible at some step, repair locally
        for sol_old in suffix:
            res = self._simulate_to_decision_repair(stage)
            if res == "finish":
                return trace_new, stage.time

            branches = res
            if not branches:
                return None, None

            old_key = self._sol_key(sol_old)
            chosen = None

            # 尝试沿用原决策：看 branches 里有没有同一个 sol
            for cand in branches:
                if self._sol_key(cand) == old_key:
                    chosen = cand
                    break

            # 沿用失败 -> 就地修复：从当前可行 branches 里选一个替代
            if chosen is None:
                chosen = self._pick_one_from_branches(stage, branches)

            if chosen is None:
                return None, None

            stage = self._apply_solution(stage, chosen)
            trace_new.append(chosen)

        # 4) finish rollout if still not done
        while True:
            res = self._simulate_to_decision_repair(stage)
            if res == "finish":
                return trace_new, stage.time
            branches = res
            chosen = self._pick_one_from_branches(stage, branches)
            if chosen is None:
                return None, None
            stage = self._apply_solution(stage, chosen)
            trace_new.append(chosen)

    # ---------- 主程序 ----------
    def run(self):
        t0 = time.perf_counter()

        # init（你可以换成 new_build_initial_trace()）
        trace, ms = self.build_initial_trace()
        trace_best, ms_best = list(trace), ms

        # LNS iterations
        for _ in range(self.Imax):
            if len(trace) == 0:
                break

            prefix, window_len, suffix, t1, t2 = self._destroy_window(trace)

            trace_new, ms_new = self._repair_middle_window(prefix, window_len, suffix)

            # repair 失败就跳过
            if trace_new is None or ms_new is None:
                continue

            # accept
            if ms_new < ms:
                trace, ms = trace_new, ms_new
                if ms_new < ms_best:
                    trace_best, ms_best = list(trace_new), ms_new
            else:
                if self.accept_worse:
                    # 你原来是 1.5 阈值，这里保留
                    if ms_new <= ms * 1.5:
                        trace, ms = trace_new, ms_new

        t1 = time.perf_counter()
        return ms_best, trace_best, (t1 - t0)
# ------------------------ Demo ------------------------
if __name__ == "__main__":
    v = 3
    p = 15
    w = 12
    seed = random.randint(0, 100)
    random.seed(seed)

    s = [random.randint(5, 10) for _ in range(w)]
    d = [random.randint(6, 15) for _ in range(w - 1)]
    # s = [7,6,9,7,8,9,5,7,10,9,5,7,]
    # d = [12,11,13,6,11,14,6,8,8,11,6,]
    h = 1

    # 运行 Segment-LNS-MILP
    solver = SegmentLNSMILP_New(
        w=w, p=p, v=v, s=s, d=d, h=h,
        Imax=50,#执行多少次破坏和修复
        Ld=1,#破坏长度，破坏多少个节点
        K=1,#每步从备选的最优分配方案中挑选多少个进行测试
        rollout_depth=0,
        accept_worse=True,
        seed=seed,
        use_new_find=False
    )
    ms_best, trace_best, tcost = solver.run()
    # print("seed =", seed)
    print("best makespan =", ms_best, "time =", tcost)

    m = CBS(w, p, v, s, d, h)
    makespan_nl,t= m.CBS_NL(3,3)
    print(makespan_nl,t)