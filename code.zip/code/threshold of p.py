# -*- coding: utf-8 -*-
"""
Created on Wed Feb 25 22:33:49 2026

@author: DELL
"""

import Numerical as N
import CBSWithoutStatus as CBS
import benchmarkWithoutStatus as BM
import csv
import s2str
import randomGenerator as rg
from datetime import datetime
import time
t1 = time.time()
def Numerical_optimalVehicle(wcc, pc, low_d,up_d, h, low_s, up_s, count, fileName):    
    for i in range(count):
        s = rg.random_nums(wcc, low_s, up_s)
        d = rg.random_nums(wcc-1, low_d,up_d)
        for vc in range(1, wcc):
            print('VC = ' + str(vc))
            
            cbs = CBS.CBS(wcc, pc, vc, s, d, h)
            cbs_makespan, cbs_makespan_t = cbs.CBS_NL(3, 3)
            # print(wcc, pc, vc, s, d, h)
            # benchmark = BM.Benchmarks(wcc, pc, vc, s, d, h)
            # STT_makespan, STT_makespan_t = benchmark.STT_Rule()
            
            # benchmark = BM.Benchmarks(wcc, pc, vc, s, d, h)
            # EDD_makespan, EDD_makespan_t = benchmark.EDD_Rule()
            
            # benchmark = BM.Benchmarks(wcc, pc, vc, s, d, h)
            # rSI_makespan, rSI_makespan_t = benchmark.rSI_Rule()
            
            f = open(fileName,'a',newline='')
            writer = csv.writer(f)
            writer.writerow([ vc,
                              pc,
                              wcc,
                              pc*wcc,
                              low_s, up_s,
                              s2str.list2str(s),
                              low_d,up_d,
                              s2str.list2str(d),
                              h,
                              cbs_makespan,
                              # STT_makespan,
                              # EDD_makespan,
                              # rSI_makespan
                              ])
            f.close()
    return

W = 7
# P = 18
H = 1
D = [(2,5)]
# low_s, up_s = 10,20
S = [(5,10)]
count = 10
total = count*len(D)*len(S)*5
actual = total
current_date = datetime.now().date()
date_str = current_date.strftime('%Y-%m-%d')
fileName = 'figure_agvNum_data'+date_str+'.csv'
f = open(fileName,'a',newline='')
writer = csv.writer(f)
writer.writerow([ 'vc',
                  'pc',
                  'wcc',
                  'taskcount',
                  'low_s', 'up_s',
                  'S',
                  'low_d','up_d',
                  'D',
                  'h',
                  'cbs_makespan',
                  # 'STT_makespan',
                  # 'EDD_makespan',
                  # 'rSI_makespan',
                  'group'
                  ])
f.close()
for P in [10,12,14,16,18,20]:
    for low_d,up_d in D:
        for low_s, up_s in S:
            Numerical_optimalVehicle(W, P, low_d,up_d, H, low_s, up_s, count, fileName)
            actual -= count
            print('Progress: {:.2%}'.format(1-actual/total))

t2 = time.time()