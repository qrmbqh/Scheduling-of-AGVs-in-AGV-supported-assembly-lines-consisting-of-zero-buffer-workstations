# -*- coding: utf-8 -*-
"""
Created on Tue Jun 24 15:56:04 2025

@author: DELL
"""
import functions as F
from gurobipy import *
import time
WG = None
PG = None
VG = None
SG = None
DG = None
HG = None

def setGlobalParam(w,p,v,s,d,h):
    global WG,PG,VG,DG,SG,HG
    WG,PG,VG,DG,SG,HG = w,p,v,d,s,h
    
def timeScheduling(xp):
    global WG,PG,VG,DG,SG,HG
    wcc, pc, vc, d, s, h = WG,PG,VG,DG,SG,HG
    #计算距离矩阵
    S = [0] + s
    T_d = [(i,j) for i in range(1,wcc+1) for j in range(1,wcc+1)]
    
    T = {}
    for i,j in T_d:
        if i <= j:
            T[i,j] = sum(d[i-1:j-1])
        else:
            T[i,j] = sum(d[j-1:i-1])+2*h
            
    #生成AGV集合
    V = list(range(1, vc+1))
            
    #定义开始的虚拟任务区域
    A = [(0,v) for v in V]
    E = [(0,0)]
    #任务区域zh
    D = [(i,j) for i in range(1,wcc) for j in range(1,pc+1)]
    M = len(D)*max(S)*100
    
    #BD定义
    b1 = [(0,j) for j in range(pc+1)]
    b2 = [(i,0) for i in range(1,wcc)]
    
    #CD定义
    c1 = [(wcc, j) for j in range(pc + 1)]
    c2 = [(i,0) for i in range(1,wcc)]
    #定义结束的虚拟任务区域
    c_d = D + c1 + c2
    b_d = D + b1 + b2
    x_d = [(i,j,m,n) for (i,j) in D + A for (m,n) in D + E]
    #线性化用到的辅助变量区间定义
    # define model
    mdl = Model("Model")
    #define variables
    # x = mdl.addVars(x_d, vtype = GRB.BINARY, name = 'x')
    x = {}
    for key in x_d:
        var = mdl.addVar(lb=xp[key],ub=xp[key],vtype=GRB.BINARY,name=f'x{key}')
        x[key]=var
    b = mdl.addVars(b_d, lb = 0, name = 'b')
    c = mdl.addVars(c_d, lb = 0, name = 'c')
    #objective function #最小化完工时间
    obj1 = LinExpr(0)
    obj1.addTerms(1, c[wcc,pc])
    mdl.setObjective(obj1, GRB.MINIMIZE)
        
    for (i,j) in D + A:
        expr = LinExpr(0)
        for m,n in D + E:
            expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 1)
    
    #c2
    for m,n in D:
        expr = LinExpr(0)
        for i,j in D + A:
            expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 1)
    
    for i,j in D:
        expr = LinExpr(0)
        for m, n in D:
            if m > i and m+n <= i+j:
                expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 0)
        
    #c5
    for i,j in D:
        for m,n in D:
            expr = LinExpr(0)
            expr.addTerms(M, x[i,j,m,n])
            expr.addTerms(1, b[m-1,n])
            expr.addTerms(-1, b[i,j])
            mdl.addConstr(expr <= M + T[i+1,m])
    
    #7
    for i,j in D:
        for m,n in D:
            expr = LinExpr(0)
            expr.addTerms(M, x[i,j,m,n])
            expr.addTerms(-1,c[m,n])
            expr.addTerms(1, b[i,j])
            mdl.addConstr(expr <= M - T[i+1,m])
            
    #8
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(-1, c[i,j])
        expr.addTerms(1, c[i+1,j-1])
        mdl.addConstr(expr <= T[i,i+1])
       
    #9
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(-1, c[i,j])
        expr.addTerms(1, c[i+1,j])
        mdl.addConstr(expr >= T[i,i+1] + S[i+1])
    
    #10
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(1, b[i,j])
        expr.addTerms(-1, c[i,j])
        mdl.addConstr(expr >= T[i,i+1])
        
    for j in range(1, pc+1):
        expr = LinExpr(0)
        expr.addTerms(1, c[1,j])
        expr.addTerms(-1, c[1,j-1])
        mdl.addConstr(expr >= S[1])

    for i,j in b1:
        if j > 1:
            mdl.addConstr(b[i,j]==c[i+1,j-1])
    # mdl.setParam(GRB.Param.PoolGap, 0)
    # mdl.setParam("PoolSearchMode", 0)
    mdl.setParam(GRB.Param.OutputFlag, 0)  
    # mdl.Params.TimeLimit = t_limited
    mdl.optimize()
    if mdl.Status == 2:
        b_repaired = {}
        c_repaired = {}
        for key in b_d:
            b_repaired[key] = b[key].x
        for key in c_d:
            c_repaired[key] = c[key].x
        return True, mdl.ObjVal, mdl.Runtime, b_repaired, c_repaired
    if mdl.Status == 3:
        mdl.computeIIS() 
        mdl.write("abc.ilp")
        return False, None, mdl.Runtime, None, None

def timeScheduling_relaxed(xp):
    global WG,PG,VG,DG,SG,HG
    wcc, pc, vc, d, s, h = WG,PG,VG,DG,SG,HG
    #计算距离矩阵
    S = [0] + s
    T_d = [(i,j) for i in range(1,wcc+1) for j in range(1,wcc+1)]
    
    T = {}
    for i,j in T_d:
        if i <= j:
            T[i,j] = sum(d[i-1:j-1])
        else:
            T[i,j] = sum(d[j-1:i-1])+2*h
            
    #生成AGV集合
    V = list(range(1, vc+1))
            
    #定义开始的虚拟任务区域
    A = [(0,v) for v in V]
    E = [(0,0)]
    #任务区域zh
    D = [(i,j) for i in range(1,wcc) for j in range(1,pc+1)]
    M = len(D)*max(S)*100
    
    #BD定义
    b1 = [(0,j) for j in range(pc+1)]
    b2 = [(i,0) for i in range(1,wcc)]
    
    #CD定义
    c1 = [(wcc, j) for j in range(pc + 1)]
    c2 = [(i,0) for i in range(1,wcc)]
    #定义结束的虚拟任务区域
    c_d = D + c1 + c2
    b_d = D + b1 + b2
    x_d = [(i,j,m,n) for (i,j) in D + A for (m,n) in D + E]
    #线性化用到的辅助变量区间定义
    # define model
    mdl = Model("Model")
    #define variables
    # x = mdl.addVars(x_d, vtype = GRB.BINARY, name = 'x')
    x = {}
    for key in x_d:
        var = mdl.addVar(lb=xp[key],ub=xp[key],vtype=GRB.BINARY,name='x')
        x[key]=var
    b = mdl.addVars(b_d, lb = 0, name = 'b')
    c = mdl.addVars(c_d, lb = 0, name = 'c')
    #objective function #最小化完工时间
    obj1 = LinExpr(0)
    obj1.addTerms(1, c[wcc,pc])
    mdl.setObjective(obj1, GRB.MINIMIZE)
        
    for (i,j) in D + A:
        expr = LinExpr(0)
        for m,n in D + E:
            expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 1)
    
    #c2
    for m,n in D:
        expr = LinExpr(0)
        for i,j in D + A:
            expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 1)
    
    # for i,j in D:
    #     expr = LinExpr(0)
    #     for m, n in D:
    #         if m > i and m+n <= i+j:
    #             expr.addTerms(1, x[i,j,m,n])
    #     mdl.addConstr(expr == 0)
        
    #c5
    # for i,j in D:
    #     for m,n in D:
    #         expr = LinExpr(0)
    #         expr.addTerms(M, x[i,j,m,n])
    #         expr.addTerms(1, b[m-1,n])
    #         expr.addTerms(-1, b[i,j])
    #         mdl.addConstr(expr <= M + T[i+1,m])
    
    #7
    for i,j in D:
        for m,n in D:
            expr = LinExpr(0)
            expr.addTerms(M, x[i,j,m,n])
            expr.addTerms(-1,c[m,n])
            expr.addTerms(1, b[i,j])
            mdl.addConstr(expr <= M - T[i+1,m])
            
    #8
    # for i,j in D:
    #     expr = LinExpr(0)
    #     expr.addTerms(-1, c[i,j])
    #     expr.addTerms(1, c[i+1,j-1])
    #     mdl.addConstr(expr <= T[i,i+1])
       
    #9
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(-1, c[i,j])
        expr.addTerms(1, c[i+1,j])
        mdl.addConstr(expr >= T[i,i+1] + S[i+1])
    
    for j in range(1, pc+1):
        expr = LinExpr(0)
        expr.addTerms(1, c[1,j])
        expr.addTerms(-1, c[1,j-1])
        mdl.addConstr(expr >= S[1])
    
    #10
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(1, b[i,j])
        expr.addTerms(-1, c[i,j])
        mdl.addConstr(expr == T[i,i+1])
        
    for i,j in b1:
        if j > 1:
            mdl.addConstr(b[i,j]==c[i+1,j-1])
    # mdl.setParam(GRB.Param.PoolGap, 0)
    # mdl.setParam("PoolSearchMode", 0)
    mdl.setParam(GRB.Param.OutputFlag, 0)  
    # mdl.Params.TimeLimit = t_limited
    mdl.optimize()
    if mdl.Status == 2:
        b_repaired = {}
        c_repaired = {}
        for key in b_d:
            b_repaired[key] = b[key].x
        for key in c_d:
            c_repaired[key] = c[key].x
        return True, mdl.ObjVal, mdl.Runtime, b_repaired, c_repaired
    if mdl.Status == 3:
        return False, None, mdl.Runtime, None, None
    
def timeScheduling_params(xp, wcc, pc, vc, s, d, h, new_routes):
    #计算距离矩阵
    obj_tasks = [new_routes[k][-1] for k in new_routes if new_routes[k]]
    S = [0] + s
    T_d = [(i,j) for i in range(1,wcc+1) for j in range(1,wcc+1)]
    
    T = {}
    for i,j in T_d:
        if i <= j:
            T[i,j] = sum(d[i-1:j-1])
        else:
            T[i,j] = sum(d[j-1:i-1])+2*h
            
    #生成AGV集合
    V = list(range(1, vc+1))
            
    #定义开始的虚拟任务区域
    A = [(0,v) for v in V]
    E = [(0,0)]
    #任务区域zh
    D = [(i,j) for i in range(1,wcc) for j in range(1,pc+1)]
    M = len(D)*max(S)*100
    
    #BD定义
    b1 = [(0,j) for j in range(pc+1)]
    b2 = [(i,0) for i in range(1,wcc)]
    
    #CD定义
    c1 = [(wcc, j) for j in range(pc + 1)]
    c2 = [(i,0) for i in range(1,wcc)]
    #定义结束的虚拟任务区域
    c_d = D + c1 + c2
    b_d = D + b1 + b2
    x_d = [(i,j,m,n) for (i,j) in D + A for (m,n) in D + E]
    # x_dd = [(i,j,m,n) for (i,j) in D for (m,n) in D]
    #线性化用到的辅助变量区间定义
    # define model
    mdl = Model("Model")
    #define variables
    # x = mdl.addVars(x_d, vtype = GRB.BINARY, name = 'x')
    x = {}
    for key in x_d:
        if key in xp.keys() and xp[key]:
            var = mdl.addVar(lb=1,ub=1,vtype=GRB.BINARY,name='x')
        # if key in xp:
        #     var = mdl.addVar(lb=xp[key],ub=xp[key],vtype=GRB.BINARY,name='x')
        else:
            var = mdl.addVar(vtype=GRB.BINARY,name='x')
        x[key]=var
    b = mdl.addVars(b_d, lb = 0, name = 'b')
    c = mdl.addVars(c_d, lb = 0, name = 'c')
    cmax = mdl.addVar(lb = 0, name='cmax')
    #objective function #最小化完工时间
    # obj1 = LinExpr(0)
    # obj1.addTerms(1, c[wcc,pc])
    mdl.setObjective(cmax, GRB.MINIMIZE)
    
    for task in obj_tasks:
        mdl.addConstr(cmax >= c[task])
    #c5
    for (i,j) in D + A:
        expr = LinExpr(0)
        for m,n in D + E:
            expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 1)
    
    #c2
    for m,n in D:
        expr = LinExpr(0)
        for i,j in D + A:
            expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 1)
    
    for i,j in D:
        expr = LinExpr(0)
        for m, n in D:
            if m > i and m+n <= i+j:
                expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 0)
        
    #c5
    for i,j in D:
        for m,n in D:
            expr = LinExpr(0)
            expr.addTerms(M, x[i,j,m,n])
            expr.addTerms(1, b[m-1,n])
            expr.addTerms(-1, b[i,j])
            mdl.addConstr(expr <= M + T[i+1,m])
            
    for i,j in D:
        for m,n in D:
            expr = LinExpr(0)
            # expr.addTerms(M, x[i,j,m,n])
            expr.addTerms(1, b[m-1,n])
            expr.addTerms(-1, b[i,j])
            mdl.addConstr(expr <= M*(1-x[i,j,m,n]) + T[i+1,m])
    
    for i,j in b1:
        if j > 1:
            mdl.addConstr(b[i,j]==c[i+1,j-1])
    
    #7
    for i,j in D:
        for m,n in D:
            expr = LinExpr(0)
            # expr.addTerms(M, x[i,j,m,n])
            expr.addTerms(-1,c[m,n])
            expr.addTerms(1, b[i,j])
            mdl.addConstr(expr <= M*(1-x[i,j,m,n]) - T[i+1,m])
            
    #8
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(-1, c[i,j])
        expr.addTerms(1, c[i+1,j-1])
        mdl.addConstr(expr <= T[i,i+1])
       
    #9
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(-1, c[i,j])
        expr.addTerms(1, c[i+1,j])
        mdl.addConstr(expr >= T[i,i+1] + S[i+1])
    
    for j in range(1, pc+1):
        expr = LinExpr(0)
        expr.addTerms(1, c[1,j])
        expr.addTerms(-1, c[1,j-1])
        mdl.addConstr(expr >= S[1])
    
    #10
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(1, b[i,j])
        expr.addTerms(-1, c[i,j])
        mdl.addConstr(expr == T[i,i+1])
    
    # mdl.setParam(GRB.Param.PoolGap, 0)
    # mdl.setParam("PoolSearchMode", 0)
    mdl.setParam(GRB.Param.OutputFlag, 0)  
    # mdl.Params.TimeLimit = t_limited
    mdl.optimize()
    if mdl.Status == 2:
        return True, mdl.ObjVal, mdl.Runtime
    if mdl.Status == 3:
        return False, None, mdl.Runtime

# import random
import matplotlib.pyplot as plt
def original_problem_params(wcc, pc, vc, d, s, h, t_limited=float('inf'), vision=False):
    #计算距离矩阵
    S = [0] + s
    T_d = [(i,j) for i in range(1,wcc+1) for j in range(1,wcc+1)]
    
    T = {}
    for i,j in T_d:
        if i <= j:
            T[i,j] = sum(d[i-1:j-1])
        else:
            T[i,j] = sum(d[j-1:i-1])+2*h
            
    #生成AGV集合
    V = list(range(1, vc+1))
            
    #定义开始的虚拟任务区域
    A = [(0,v) for v in V]
    E = [(0,0)]
    #任务区域zh
    D = [(i,j) for i in range(1,wcc) for j in range(1,pc+1)]
    M = len(D)*max(S)*100
    
    #BD定义
    b1 = [(0,j) for j in range(pc+1)]
    b2 = [(i,0) for i in range(1,wcc)]
    
    #CD定义
    c1 = [(wcc, j) for j in range(pc + 1)]
    c2 = [(i,0) for i in range(1,wcc)]
    #定义结束的虚拟任务区域
    c_d = D + c1 + c2
    b_d = D + b1 + b2
    x_d = [(i,j,m,n) for (i,j) in D + A for (m,n) in D + E]
    #线性化用到的辅助变量区间定义
    # define model
    mdl = Model("Model")
    #define variables
    x = mdl.addVars(x_d, vtype = GRB.BINARY, name = 'x')
    b = mdl.addVars(b_d, lb = 0, name = 'b')
    c = mdl.addVars(c_d, lb = 0, name = 'c')
    #objective function #最小化完工时间
    obj1 = LinExpr(0)
    obj1.addTerms(1, c[wcc,pc])
    mdl.setObjective(obj1, GRB.MINIMIZE)
        
    for (i,j) in D + A:
        expr = LinExpr(0)
        for m,n in D + E:
            expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 1)
    
    #c2
    for m,n in D:
        expr = LinExpr(0)
        for i,j in D + A:
            expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 1)
    
    for i,j in D:
        expr = LinExpr(0)
        for m, n in D:
            if m > i and m+n <= i+j:
                expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 0)
        
    #c5
    for i,j in D:
        for m,n in D:
            expr = LinExpr(0)
            expr.addTerms(M, x[i,j,m,n])
            expr.addTerms(1, b[m-1,n])
            expr.addTerms(-1, b[i,j])
            mdl.addConstr(expr <= M + T[i+1,m])
    
    for i,j in b1:
        if j > 1:
            mdl.addConstr(b[i,j]==c[i+1,j-1])
    
    #7
    for i,j in D:
        for m,n in D:
            expr = LinExpr(0)
            expr.addTerms(M, x[i,j,m,n])
            expr.addTerms(-1,c[m,n])
            expr.addTerms(1, b[i,j])
            mdl.addConstr(expr <= M - T[i+1,m])
            
    #8
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(-1, c[i,j])
        expr.addTerms(1, c[i+1,j-1])
        mdl.addConstr(expr <= T[i,i+1])
       
    #9
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(-1, c[i,j])
        expr.addTerms(1, c[i+1,j])
        mdl.addConstr(expr >= T[i,i+1] + S[i+1])
    
    for j in range(1, pc+1):
        expr = LinExpr(0)
        expr.addTerms(1, c[1,j])
        expr.addTerms(-1, c[1,j-1])
        mdl.addConstr(expr >= S[1])
    
    #10
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(1, b[i,j])
        expr.addTerms(-1, c[i,j])
        mdl.addConstr(expr == T[i,i+1])
    
    # mdl.setParam(GRB.Param.PoolGap, 0)
    # mdl.setParam("PoolSearchMode", 0)
    mdl.setParam(GRB.Param.OutputFlag, 0)
    # mdl.Params.TimeLimit = t_limited
    mdl.optimize()
    if vision:
        plt.figure(figsize = (6.4*2,4.8*2), dpi = 600)
        for i,j in A:
            color = F.random_color()
            while True:
                tag = 0
                for (m,n) in D + E:
                    if x[i,j,m,n].x > 0.5:
                        if (m,n) in E:
                            pass
                            # plt.plot(m,n,"o", color = "#000000"){}
                        else:
                            plt.plot(m,n,"o", color = color)
                        if (i,j) not in A and (m,n) not in E:
                            plt.plot([i,m],[j,n], color = color)
                        # else:
                            # plt.plot([i,m],[0,n], color = color)
                        if (m,n)!=(0,0):
                            plt.text(m, n-0.2, round(c[m,n].x), color = "#000000")
                            plt.text(m, n+0.1, round(b[m,n].x), color = "#000FFF")
                            i,j = m,n
                        else:
                            break
                        # D.remove((m,n))
                        tag = 1
                        break
                if tag == 0:
                    break
        for (i,j) in c1:
            plt.text(i, j-0.2, round(c[i,j].x), color = "#000000")
        plt.xlabel("Workstations")
        plt.ylabel("Products")
    if mdl.Status == 2:
        return mdl.ObjVal, mdl.Runtime
    if mdl.Status == 3:
        return None, mdl.Runtime
    
def seqs2x(seqs):
    global WG,PG,VG,DG,SG,HG
    w,p,v = WG,PG,VG
    seqs = F.copy(seqs)
    x = {}
    A = [(0,k) for k in range(1, v+1)]
    E = [(0,0)]
    D = [(i,j) for i in range(1,w) for j in range(1,p+1)]
    x_d = [(i,j,m,n) for (i,j) in D + A for (m,n) in D + E]
    for idx, seq in enumerate(seqs):
        if seq[0][0]!=0:
            seq.insert(0,(0,idx+1))
        if seq[-1]!=(0,0):
            seq.append((0,0))
        for i in range(1, len(seq)):
            node = seq[i]
            last_node = seq[i-1]
            key = (*last_node, *node)          # 先拼接成一个 tuple
            x[key] = 1
            # x[*last_node, *node] = 1
    for key in x_d:
        if key not in x:
            x[key] = 0
    return x

def evaluation(seqs):
    seqs = F.copy(seqs)
    x = seqs2x(seqs)
    tag, obj, runtime,b,c = timeScheduling(x)
    return tag, obj, runtime,b,c

def evaluation_repairMILP(seqs, times = 4, percent=0.25):
    t1 = time.time()
    seqs = F.copy(seqs)
    x = seqs2x(seqs)
    tag,obj,b,c = False, None,None,None
    for _ in range(times):
        tag,obj,runtime,b,c = timeScheduling_repair_random_opt(x,percent)
        if tag:
            break
    t2 = time.time()
    return tag, obj, t2-t1, b, c
    
def evaluation_relaxed(seqs):
    seqs = F.copy(seqs)
    x = seqs2x(seqs)
    tag, obj, runtime,b,c = timeScheduling_relaxed(x)
    return tag, obj, runtime,b,c

def relaxed_problem_lp_params(wcc, pc, vc, d, s, h):
    #计算距离矩阵
    S = [0] + s
    T_d = [(i,j) for i in range(1,wcc+1) for j in range(1,wcc+1)]
    
    T = {}
    for i,j in T_d:
        if i <= j:
            T[i,j] = sum(d[i-1:j-1])
        else:
            T[i,j] = sum(d[j-1:i-1])+2*h
            
    #生成AGV集合
    V = list(range(1, vc+1))
            
    #定义开始的虚拟任务区域
    A = [(0,v) for v in V]
    E = [(0,0)]
    #任务区域zh
    D = [(i,j) for i in range(1,wcc) for j in range(1,pc+1)]
    M = len(D)*max(S)*100
    
    #BD定义
    b1 = [(0,j) for j in range(pc+1)]
    b2 = [(i,0) for i in range(1,wcc)]
    
    #CD定义
    c1 = [(wcc, j) for j in range(pc + 1)]
    c2 = [(i,0) for i in range(1,wcc)]
    #定义结束的虚拟任务区域
    c_d = D + c1 + c2
    b_d = D + b1 + b2
    x_d = [(i,j,m,n) for (i,j) in D + A for (m,n) in D + E]
    #线性化用到的辅助变量区间定义
    # define model
    mdl = Model("Model")
    #define variables
    x = mdl.addVars(x_d, lb = 0, ub = 1, vtype = GRB.CONTINUOUS, name = 'x')
    b = mdl.addVars(b_d, lb = 0, name = 'b')
    c = mdl.addVars(c_d, lb = 0, name = 'c')
    #objective function #最小化完工时间
    obj1 = LinExpr(0)
    obj1.addTerms(1, c[wcc,pc])
    mdl.setObjective(obj1, GRB.MINIMIZE)
        
    for (i,j) in D + A:
        expr = LinExpr(0)
        for m,n in D + E:
            if (i,j)!=(m,n):
                expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 1)
    
    #c2
    for m,n in D:
        expr = LinExpr(0)
        for i,j in D + A:
            if (i,j)!=(m,n):
                expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 1)
    
    for i,j in D:
        expr = LinExpr(0)
        for m, n in D:
            if m > i and m+n <= i+j:
                expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 0)
        
    #c5
    for i,j in D:
        for m,n in D:
            expr = LinExpr(0)
            expr.addTerms(M, x[i,j,m,n])
            expr.addTerms(1, b[m-1,n])
            expr.addTerms(-1, b[i,j])
            mdl.addConstr(expr <= M + T[i+1,m])
    
    for i,j in b1:
        if j > 1:
            mdl.addConstr(b[i,j]==c[i+1,j-1])
    
    #7
    for i,j in D:
        for m,n in D:
            expr = LinExpr(0)
            expr.addTerms(M, x[i,j,m,n])
            expr.addTerms(-1,c[m,n])
            expr.addTerms(1, b[i,j])
            mdl.addConstr(expr <= M - T[i+1,m])
            
    #8
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(-1, c[i,j])
        expr.addTerms(1, c[i+1,j-1])
        mdl.addConstr(expr <= T[i,i+1])
       
    #9
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(-1, c[i,j])
        expr.addTerms(1, c[i+1,j])
        mdl.addConstr(expr >= T[i,i+1] + S[i+1])
    
    for j in range(1, pc+1):
        expr = LinExpr(0)
        expr.addTerms(1, c[1,j])
        expr.addTerms(-1, c[1,j-1])
        mdl.addConstr(expr >= S[1])
    
    #10
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(1, b[i,j])
        expr.addTerms(-1, c[i,j])
        mdl.addConstr(expr == T[i,i+1])
    
    # mdl.setParam(GRB.Param.PoolGap, 0)
    # mdl.setParam("PoolSearchMode", 0)
    mdl.setParam(GRB.Param.OutputFlag, 0)
    # mdl.Params.TimeLimit = t_limited
    mdl.optimize()
    if mdl.Status == 2:
        solution = {}
        for key in x_d:
            solution[key] = x[key].x
        return mdl.ObjVal, solution, mdl.Runtime
    if mdl.Status == 3:
        return None, None, mdl.Runtime

def originalProblem():
    global WG,PG,VG,DG,SG,HG
    wcc, pc, vc, d, s, h = WG,PG,VG,DG,SG,HG
    #计算距离矩阵
    S = [0] + s
    T_d = [(i,j) for i in range(1,wcc+1) for j in range(1,wcc+1)]
    
    T = {}
    for i,j in T_d:
        if i <= j:
            T[i,j] = sum(d[i-1:j-1])
        else:
            T[i,j] = sum(d[j-1:i-1])+2*h
            
    #生成AGV集合
    V = list(range(1, vc+1))
            
    #定义开始的虚拟任务区域
    A = [(0,v) for v in V]
    E = [(0,0)]
    #任务区域zh
    D = [(i,j) for i in range(1,wcc) for j in range(1,pc+1)]
    M = len(D)*max(S)*100
    
    #BD定义
    b1 = [(0,j) for j in range(pc+1)]
    b2 = [(i,0) for i in range(1,wcc)]
    
    #CD定义
    c1 = [(wcc, j) for j in range(pc + 1)]
    c2 = [(i,0) for i in range(1,wcc)]
    #定义结束的虚拟任务区域
    c_d = D + c1 + c2
    b_d = D + b1 + b2
    x_d = [(i,j,m,n) for (i,j) in D + A for (m,n) in D + E]
    #线性化用到的辅助变量区间定义
    # define model
    mdl = Model("Model")
    #define variables
    # x = mdl.addVars(x_d, vtype = GRB.BINARY, name = 'x')
    x = {}
    for key in x_d:
        var = mdl.addVar(vtype=GRB.BINARY,name=f'x{key}')
        x[key]=var
    b = mdl.addVars(b_d, lb = 0, name = 'b')
    c = mdl.addVars(c_d, lb = 0, name = 'c')
    #objective function #最小化完工时间
    obj1 = LinExpr(0)
    obj1.addTerms(1, c[wcc,pc])
    mdl.setObjective(obj1, GRB.MINIMIZE)
        
    for (i,j) in D + A:
        expr = LinExpr(0)
        for m,n in D + E:
            expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 1)
    
    #c2
    for m,n in D:
        expr = LinExpr(0)
        for i,j in D + A:
            expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 1)
    
    for i,j in D:
        expr = LinExpr(0)
        for m, n in D:
            if m > i and m+n <= i+j:
                expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 0)
        
    #c5
    for i,j in D:
        for m,n in D:
            expr = LinExpr(0)
            expr.addTerms(M, x[i,j,m,n])
            expr.addTerms(1, b[m-1,n])
            expr.addTerms(-1, b[i,j])
            mdl.addConstr(expr <= M + T[i+1,m])
    
    #7
    for i,j in D:
        for m,n in D:
            expr = LinExpr(0)
            expr.addTerms(M, x[i,j,m,n])
            expr.addTerms(-1,c[m,n])
            expr.addTerms(1, b[i,j])
            mdl.addConstr(expr <= M - T[i+1,m])
            
    #8
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(-1, c[i,j])
        expr.addTerms(1, c[i+1,j-1])
        mdl.addConstr(expr <= T[i,i+1])
       
    #9
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(-1, c[i,j])
        expr.addTerms(1, c[i+1,j])
        mdl.addConstr(expr >= T[i,i+1] + S[i+1])
    
    #10
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(1, b[i,j])
        expr.addTerms(-1, c[i,j])
        mdl.addConstr(expr >= T[i,i+1])
        
    for j in range(1, pc+1):
        expr = LinExpr(0)
        expr.addTerms(1, c[1,j])
        expr.addTerms(-1, c[1,j-1])
        mdl.addConstr(expr >= S[1])

    for i,j in b1:
        if j > 1:
            mdl.addConstr(b[i,j]==c[i+1,j-1])
    # mdl.setParam(GRB.Param.PoolGap, 0)
    # mdl.setParam("PoolSearchMode", 0)
    mdl.setParam(GRB.Param.OutputFlag, 0)  
    # mdl.Params.TimeLimit = t_limited
    mdl.optimize()
    if mdl.Status == 2:
        b_repaired = {}
        c_repaired = {}
        for key in b_d:
            b_repaired[key] = b[key].x
        for key in c_d:
            c_repaired[key] = c[key].x
        return True, mdl.ObjVal
    if mdl.Status == 3:
        mdl.computeIIS() 
        mdl.write("abc.ilp")
        return False, None

def relaxedProblem():
    global WG,PG,VG,DG,SG,HG
    wcc, pc, vc, d, s, h = WG,PG,VG,DG,SG,HG
    #计算距离矩阵
    S = [0] + s
    T_d = [(i,j) for i in range(1,wcc+1) for j in range(1,wcc+1)]
    
    T = {}
    for i,j in T_d:
        if i <= j:
            T[i,j] = sum(d[i-1:j-1])
        else:
            T[i,j] = sum(d[j-1:i-1])+2*h
            
    #生成AGV集合
    V = list(range(1, vc+1))
            
    #定义开始的虚拟任务区域
    A = [(0,v) for v in V]
    E = [(0,0)]
    #任务区域zh
    D = [(i,j) for i in range(1,wcc) for j in range(1,pc+1)]
    M = len(D)*max(S)*100
    
    #BD定义
    b1 = [(0,j) for j in range(pc+1)]
    b2 = [(i,0) for i in range(1,wcc)]
    
    #CD定义
    c1 = [(wcc, j) for j in range(pc + 1)]
    c2 = [(i,0) for i in range(1,wcc)]
    #定义结束的虚拟任务区域
    c_d = D + c1 + c2
    b_d = D + b1 + b2
    x_d = [(i,j,m,n) for (i,j) in D + A for (m,n) in D + E]
    #线性化用到的辅助变量区间定义
    # define model
    mdl = Model("Model")
    #define variables
    # x = mdl.addVars(x_d, vtype = GRB.BINARY, name = 'x')
    x = {}
    for key in x_d:
        var = mdl.addVar(vtype=GRB.BINARY,name='x')
        x[key]=var
    b = mdl.addVars(b_d, lb = 0, name = 'b')
    c = mdl.addVars(c_d, lb = 0, name = 'c')
    #objective function #最小化完工时间
    obj1 = LinExpr(0)
    obj1.addTerms(1, c[wcc,pc])
    mdl.setObjective(obj1, GRB.MINIMIZE)
        
    for (i,j) in D + A:
        expr = LinExpr(0)
        for m,n in D + E:
            expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 1)
    
    #c2
    for m,n in D:
        expr = LinExpr(0)
        for i,j in D + A:
            expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 1)
    
    # for i,j in D:
    #     expr = LinExpr(0)
    #     for m, n in D:
    #         if m > i and m+n <= i+j:
    #             expr.addTerms(1, x[i,j,m,n])
    #     mdl.addConstr(expr == 0)
        
    #c5
    # for i,j in D:
    #     for m,n in D:
    #         expr = LinExpr(0)
    #         expr.addTerms(M, x[i,j,m,n])
    #         expr.addTerms(1, b[m-1,n])
    #         expr.addTerms(-1, b[i,j])
    #         mdl.addConstr(expr <= M + T[i+1,m])
    
    #7
    for i,j in D:
        for m,n in D:
            expr = LinExpr(0)
            expr.addTerms(M, x[i,j,m,n])
            expr.addTerms(-1,c[m,n])
            expr.addTerms(1, b[i,j])
            mdl.addConstr(expr <= M - T[i+1,m])
            
    #8
    # for i,j in D:
    #     expr = LinExpr(0)
    #     expr.addTerms(-1, c[i,j])
    #     expr.addTerms(1, c[i+1,j-1])
    #     mdl.addConstr(expr <= T[i,i+1])
       
    #9
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(-1, c[i,j])
        expr.addTerms(1, c[i+1,j])
        mdl.addConstr(expr >= T[i,i+1] + S[i+1])
    
    for j in range(1, pc+1):
        expr = LinExpr(0)
        expr.addTerms(1, c[1,j])
        expr.addTerms(-1, c[1,j-1])
        mdl.addConstr(expr >= S[1])
    
    #10
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(1, b[i,j])
        expr.addTerms(-1, c[i,j])
        mdl.addConstr(expr == T[i,i+1])
        
    for i,j in b1:
        if j > 1:
            mdl.addConstr(b[i,j]==c[i+1,j-1])
    # mdl.setParam(GRB.Param.PoolGap, 0)
    # mdl.setParam("PoolSearchMode", 0)
    mdl.setParam(GRB.Param.OutputFlag, 0)  
    # mdl.Params.TimeLimit = t_limited
    mdl.optimize()
    if mdl.Status == 2:
        b_repaired = {}
        c_repaired = {}
        for key in b_d:
            b_repaired[key] = b[key].x
        for key in c_d:
            c_repaired[key] = c[key].x
        return True, mdl.ObjVal
    if mdl.Status == 3:
        return False, None
import random

def timeScheduling_repair_random_opt(xp, percent=0.25, seed=None, timelimit=None, only_feasible=False):
    global WG, PG, VG, DG, SG, HG
    wcc, pc, vc, d, s, h = WG, PG, VG, DG, SG, HG

    # -------- percent 归一化 --------
    if percent is None:
        percent = 0.0
    if percent > 1.0:
        percent = percent / 100.0
    percent = max(0.0, min(1.0, float(percent)))

    if seed is not None:
        random.seed(seed)

    # -------- 距离矩阵/集合定义（保持你原逻辑）--------
    S = [0] + s
    T_d = [(i, j) for i in range(1, wcc + 1) for j in range(1, wcc + 1)]
    T = {}
    for i, j in T_d:
        if i <= j:
            T[i, j] = sum(d[i - 1:j - 1])
        else:
            T[i, j] = sum(d[j - 1:i - 1]) + 2 * h

    V = list(range(1, vc + 1))
    A = [(0, v) for v in V]
    E = [(0, 0)]
    D = [(i, j) for i in range(1, wcc) for j in range(1, pc + 1)]
    M = len(D) * max(S) * 100

    b1 = [(0, j) for j in range(pc + 1)]
    b2 = [(i, 0) for i in range(1, wcc)]
    c1 = [(wcc, j) for j in range(pc + 1)]
    c2 = [(i, 0) for i in range(1, wcc)]

    c_d = D + c1 + c2
    b_d = D + b1 + b2
    x_d = [(i, j, m, n) for (i, j) in (D + A) for (m, n) in (D + E)]

    # -------- 随机选取 percent 的 x 变量“放开”--------
    # 注意：放开表示 lb=0, ub=1；固定表示 lb=ub=xp[key]
    free_cnt = int(round(len(x_d) * percent))
    free_keys = set(random.sample(x_d, free_cnt)) if free_cnt > 0 else set()

    # -------- 建模 --------
    mdl = Model("RepairRandOpt")

    # x 变量：部分固定、部分放开
    x = {}
    for key in x_d:
        # xp 必须提供该 key，否则报错更早暴露问题
        if key not in xp:
            raise KeyError(f"xp 缺少 key={key} 的取值，无法固定/放开该变量。")

        if key in free_keys:
            # 放开：自由二进制
            var = mdl.addVar(lb=0, ub=1, vtype=GRB.BINARY, name=f"x{key}")
        else:
            # 固定：lb=ub=xp[key]
            val = int(round(xp[key]))
            var = mdl.addVar(lb=val, ub=val, vtype=GRB.BINARY, name=f"x{key}")
        x[key] = var

    b = mdl.addVars(b_d, lb=0, name="b")
    c = mdl.addVars(c_d, lb=0, name="c")

    # 目标：默认最小 makespan；如果只想判断可行性，把 only_feasible=True
    if only_feasible:
        mdl.setObjective(0.0, GRB.MINIMIZE)
    else:
        obj = LinExpr(0)
        obj.addTerms(1, c[wcc, pc])
        mdl.setObjective(obj, GRB.MINIMIZE)

    # -------- 约束（完全复用你原来的）--------
    # (1) 每个 (i,j) 选择一个后继 (m,n)
    for (i, j) in D + A:
        expr = LinExpr(0)
        for (m, n) in D + E:
            expr.addTerms(1, x[i, j, m, n])
        mdl.addConstr(expr == 1)

    # (2) 每个 (m,n) 恰好一个前驱 (i,j)
    for (m, n) in D:
        expr = LinExpr(0)
        for (i, j) in D + A:
            expr.addTerms(1, x[i, j, m, n])
        mdl.addConstr(expr == 1)

    # 你原来的禁止弧约束
    for (i, j) in D:
        expr = LinExpr(0)
        for (m, n) in D:
            if m > i and m + n <= i + j:
                expr.addTerms(1, x[i, j, m, n])
        mdl.addConstr(expr == 0)

    # Big-M 相关
    for (i, j) in D:
        for (m, n) in D:
            expr = LinExpr(0)
            expr.addTerms(M, x[i, j, m, n])
            expr.addTerms(1, b[m - 1, n])
            expr.addTerms(-1, b[i, j])
            mdl.addConstr(expr <= M + T[i + 1, m])

    for (i, j) in D:
        for (m, n) in D:
            expr = LinExpr(0)
            expr.addTerms(M, x[i, j, m, n])
            expr.addTerms(-1, c[m, n])
            expr.addTerms(1, b[i, j])
            mdl.addConstr(expr <= M - T[i + 1, m])

    for (i, j) in D:
        expr = LinExpr(0)
        expr.addTerms(-1, c[i, j])
        expr.addTerms(1, c[i + 1, j - 1])
        mdl.addConstr(expr <= T[i, i + 1])

    for (i, j) in D:
        expr = LinExpr(0)
        expr.addTerms(-1, c[i, j])
        expr.addTerms(1, c[i + 1, j])
        mdl.addConstr(expr >= T[i, i + 1] + S[i + 1])

    for (i, j) in D:
        expr = LinExpr(0)
        expr.addTerms(1, b[i, j])
        expr.addTerms(-1, c[i, j])
        mdl.addConstr(expr >= T[i, i + 1])

    for j in range(1, pc + 1):
        expr = LinExpr(0)
        expr.addTerms(1, c[1, j])
        expr.addTerms(-1, c[1, j - 1])
        mdl.addConstr(expr >= S[1])

    for (i, j) in b1:
        if j > 1:
            mdl.addConstr(b[i, j] == c[i + 1, j - 1])

    # -------- 参数 --------
    mdl.setParam(GRB.Param.OutputFlag, 0)
    if timelimit is not None:
        mdl.setParam(GRB.Param.TimeLimit, float(timelimit))

    # -------- 求解 --------
    mdl.optimize()

    # 可行/最优
    if mdl.Status in (GRB.OPTIMAL, GRB.TIME_LIMIT, GRB.SUBOPTIMAL):
        # 只要有可行解（TimeLimit 时可能有 Incumbent）
        if mdl.SolCount > 0:
            # 导出修复后的 x（即新的 xp'）
            xp_repaired = {}
            for key in x_d:
                xp_repaired[key] = int(round(x[key].X))

            b_repaired = {key: b[key].X for key in b_d}
            c_repaired = {key: c[key].X for key in c_d}

            obj_val = None
            if not only_feasible:
                obj_val = mdl.ObjVal if mdl.Status == GRB.OPTIMAL else (mdl.ObjVal if mdl.SolCount > 0 else None)

            return True, obj_val, mdl.Runtime, b_repaired, c_repaired

        return False, None, mdl.Runtime, None, None

    # 不可行
    if mdl.Status == GRB.INFEASIBLE:
        # 需要的话可以输出 IIS
        # mdl.computeIIS()
        # mdl.write("repair_randopt.ilp")
        return False, None, mdl.Runtime, None, None

    # 其他状态：当作失败
    return False, None, mdl.Runtime, None, None
    
if __name__ == "__main__":
    v = 10
    p = 20
    w = 15
    # s = [4, 5, 3, 4, 4]  # 举例
    # d = [2, 2, 2, 2, 2, 2]     # len == wcc-1
    s = [random.randint(3, 10) for _ in range(w)]
    d = [random.randint(3, 5) for _ in range(w-1)]
    h = 1
    setGlobalParam(w,p,v,s,d,h)
    relax_and_repair()