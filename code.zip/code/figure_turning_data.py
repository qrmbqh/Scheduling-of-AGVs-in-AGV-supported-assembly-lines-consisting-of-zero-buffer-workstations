# -*- coding: utf-8 -*-
"""
Created on Fri Jan 24 01:15:38 2025
runtime = 10742
@author: 74110
"""

from datetime import datetime
import modelGenerate as mg
# import GurobiWithStatus as GSLS
import CBSWithoutStatusSame_d as CBS
# import CBSWithStatus as CBSWS
# import benchmarkWithStatus as BMWS
import csv
# import randomGenerator as rg

import time
t1 = time.time()
def fixedAllParameters(wcc, vc, pc, d, h, s, fileName):
    cbs = CBS.CBS(wcc, pc, vc, s, d, h)
    cbs_makespan, cbs_makespan_t = cbs.CBS_NL(3, 3)
    # print(mcbs_makespan, mcbs_makespan_t)
    f = open(fileName,'a',newline='')
    writer = csv.writer(f)
    writer.writerow([ vc,
                      pc,
                      wcc,
                      pc*wcc,
                      s[1]-s[0],
                      d,
                      h,
                      cbs_makespan, cbs_makespan_t,
                      ])
    f.close()
    return

wcc = 10
pc = 15
s = 300
V = [2,3,4,5,6]
D = [2,5,8,11,14]
Ss = []
parameters1, Ss1 = mg.up_down(wcc, s)
Ss+=Ss1
parameters1, Ss2 = mg.down_up(wcc, s)
Ss+=Ss2
# parameters, Ss = mg.serviceTimeGenerator(wcc, s)
h = 1
total = len(D)*len(Ss)*len(V)
actual = total
current_date = datetime.now().date()
date_str = current_date.strftime('%Y-%m-%d')
file_name = 'figure_turning_data' + date_str + '.csv'

f = open(file_name,'a',newline='')
writer = csv.writer(f)
writer.writerow(['v', 'p', 'w', 'task_count', 'k', 'd', 'h', 'cbs_makespan', 'cbs_makespan_t'])
f.close()

for vc in V:
    for d in D:
        for s in Ss:
            # print('111')
            fixedAllParameters(wcc, vc, pc, d, h, s, file_name)
            actual -= 1
            print('Progress: {:.2%}'.format(1-actual/total))
t2 = time.time()