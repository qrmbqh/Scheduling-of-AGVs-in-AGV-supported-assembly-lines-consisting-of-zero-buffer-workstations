# -*- coding: utf-8 -*-
"""
Created on Wed Jul 27 11:18:51 2022

@author: qrmbqh
"""

from gurobipy import *


def sectionAllocate(AGVs, W, Fixed, Dist, RPT, d):
    # 初始化参数
    if type(d) == int:
        d = [d]*10
    M = -1000
    wl = W[-1]
    x_d = [(v, w) for v in AGVs for w in W]

    # 定义模型
    m = Model("Model")
    m.setParam('OutputFlag', 0)#是否输出log信息

    # 设置变量
    x = m.addVars(x_d, vtype=GRB.BINARY, name='x')
    f = m.addVars(W, lb=M, vtype=GRB.CONTINUOUS, name='f')
    z = m.addVars(x_d, lb=M, vtype=GRB.CONTINUOUS, name='z')
    y = m.addVars(W[:-1], lb=M, vtype=GRB.CONTINUOUS, name='y')
    y.PoolIgnore = 1
    f.PoolIgnore = 1
    z.PoolIgnore = 1

    # 设置目标
    obj1 = LinExpr(0)
    obj1 = quicksum(f[w] for w in W)
    obj2 = LinExpr(0)
    obj2 = quicksum(Dist[v, w] * x[v, w] for v in AGVs for w in W)
    m.setObjective(obj1, GRB.MINIMIZE)

    # 设置约束条件
    m.addConstrs(quicksum(x[v, w] for v in AGVs) == 1 for w in W)

    m.addConstrs(quicksum(x[v, w] for w in W) == 1 for v in AGVs)

    # for (vf, wf) in Fixed:
    #     m.addConstr(x[vf, wf] == 1)
    for v in AGVs:
        expr = LinExpr(0)
        expr.addTerms(Dist[v, wl], x[v, wl])
        m.addConstr(expr == z[v, wl])
    m.addGenConstrMax(f[wl], [z[v, wl] for v in AGVs], RPT[wl], "hj1")

    for w in W[:-1]:
        for v in AGVs:
            expr = LinExpr(0)
            expr.addTerms(Dist[v, w], x[v, w])
            m.addConstr(expr == z[v, w])
        expr = LinExpr(0)
        expr.addTerms(1, f[w + 1])
        expr.addTerms(-1, y[w])
        m.addConstr(expr == d[w])
        m.addGenConstrMax(f[w], [z[v, w] for v in AGVs] + [y[w]], RPT[w], "hj2")
    # m.setParam("PoolSearchMode", 0)
    m.update()
    originalModel = m.copy()
    # originalModel.write("model2.lp")
    originalModel.optimize()
    obj1Val = round(originalModel.ObjVal)
    m.addConstr(obj1 == obj1Val)  # 固定目标1的值，优化目标2
    m.setObjective(obj2, GRB.MINIMIZE)
    m.write("model2.lp")
    # 求解最小化travel time的目标
    m.setParam(GRB.Param.PoolSolutions, 1024)
    m.setParam(GRB.Param.PoolGap, 0)
    m.setParam(GRB.Param.PoolSearchMode, 2)
    m.setParam(GRB.Param.MIPGap, 0)
    m.optimize()
    if m.Status == 3:
        m.computeIIS() 
        m.write("abc.ilp")
    # 输出解
    solutions = []
    nSolution = m.SolCount
    for i in range(nSolution):
        solution = []
        m.setParam(GRB.Param.SolutionNumber, i)

        for key in x_d:
            # print(x[key].VarName,"=",x[key].x)
            if x[key].xn > 0.5:
                solution.append(key)
        solutions.append(solution)

    # 删除重复解
    for slu in range(len(solutions) - 1, -1, -1):
        if solutions.count(solutions[slu]) > 1:
            solutions.pop(slu)
            # 返回多个分配方案的（AGV，工位）元组。
    return solutions

def sectionAllocate_repair(AGVs, W, Fixed, Dist, RPT, d):
    # 初始化参数
    if type(d) == int:
        d = [d]*10
    M = -1000
    wl = W[-1]
    x_d = [(v, w) for v in AGVs for w in W]

    # 定义模型
    m = Model("Model")
    m.setParam('OutputFlag', 0)#是否输出log信息

    # 设置变量
    x = m.addVars(x_d, vtype=GRB.BINARY, name='x')
    f = m.addVars(W, lb=M, vtype=GRB.CONTINUOUS, name='f')
    z = m.addVars(x_d, lb=M, vtype=GRB.CONTINUOUS, name='z')
    y = m.addVars(W[:-1], lb=M, vtype=GRB.CONTINUOUS, name='y')
    y.PoolIgnore = 1
    f.PoolIgnore = 1
    z.PoolIgnore = 1

    # 设置目标
    obj1 = LinExpr(0)
    obj1 = quicksum(f[w] for w in W)
    obj2 = LinExpr(0)
    obj2 = quicksum(Dist[v, w] * x[v, w] for v in AGVs for w in W)
    m.setObjective(obj2, GRB.MINIMIZE)

    # 设置约束条件
    m.addConstrs(quicksum(x[v, w] for v in AGVs) == 1 for w in W)

    m.addConstrs(quicksum(x[v, w] for w in W) == 1 for v in AGVs)

    # for (vf, wf) in Fixed:
    #     m.addConstr(x[vf, wf] == 1)
    # for v in AGVs:
    #     expr = LinExpr(0)
    #     expr.addTerms(Dist[v, wl], x[v, wl])
    #     m.addConstr(expr == z[v, wl])
    # m.addGenConstrMax(f[wl], [z[v, wl] for v in AGVs], RPT[wl], "hj1")

    # for w in W[:-1]:
    #     for v in AGVs:
    #         expr = LinExpr(0)
    #         expr.addTerms(Dist[v, w], x[v, w])
    #         m.addConstr(expr == z[v, w])
    #     expr = LinExpr(0)
    #     expr.addTerms(1, f[w + 1])
    #     expr.addTerms(-1, y[w])
    #     m.addConstr(expr == d[w])
    #     m.addGenConstrMax(f[w], [z[v, w] for v in AGVs] + [y[w]], RPT[w], "hj2")
    # m.setParam("PoolSearchMode", 0)
    # m.update()
    # originalModel = m.copy()
    # originalModel.write("model2.lp")
    # originalModel.optimize()
    # obj1Val = originalModel.ObjVal
    # m.addConstr(obj1 == obj1Val)  # 固定目标1的值，优化目标2
    # m.setObjective(obj2, GRB.MINIMIZE)
    m.write("model2.lp")
    # 求解最小化travel time的目标
    m.setParam(GRB.Param.PoolSolutions, 1024)
    m.setParam(GRB.Param.PoolGap, 0)
    m.setParam(GRB.Param.PoolSearchMode, 2)
    m.setParam(GRB.Param.MIPGap, 0)
    m.optimize()

    # 输出解
    solutions = []
    nSolution = m.SolCount
    for i in range(nSolution):
        solution = []
        m.setParam(GRB.Param.SolutionNumber, i)

        for key in x_d:
            # print(x[key].VarName,"=",x[key].x)
            if x[key].xn > 0.5:
                solution.append(key)
        solutions.append(solution)

    # 删除重复解
    for slu in range(len(solutions) - 1, -1, -1):
        if solutions.count(solutions[slu]) > 1:
            solutions.pop(slu)
            # 返回多个分配方案的（AGV，工位）元组。
    return solutions

if __name__ == "__main__":
    AGVs = [1, 2, 3]  # AGV编号集合
    W = [3,4,5]  # 工位编号集合
    # 当前时刻工位的剩余加工时间字典
    RPT = {3: 10, 4: 10, 5: 10}
    # 工位之间的距离
    d = 2
    # 已分配的（AGV，工位）元组
    Fixed = []
    # AGV到工位的距离字典
    # Dist = {(5, 13): 5, (5, 14): 8, (5, 15): 11, (5, 16): 14, (4, 13): 19, (4, 14): 16, (4, 15): 13, (4, 16): 10, (6, 13): 22, (6, 14): 19, (6, 15): 16, (6, 16): 13, (1, 13): 25, (1, 14): 22, (1, 15): 19, (1, 16): 16}
    # AGVs = [1,2,3]
    # W = [4,5,6]
    # RPT = {4:8,5:0,6:0}
    # d = 2
    # Fixed = [(1,6)]
    Dist = {(1,3):0,(1,4):2,(1,5):4,(2,3):4,(2,4):0,(2,5):2,(3,3):6,(3,4):4,(3,5):0}
    solutions = sectionAllocate(AGVs, W, Fixed, Dist, RPT, d)
    print(solutions)
