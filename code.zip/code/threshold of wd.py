# -*- coding: utf-8 -*-
"""
Created on Wed Feb 25 22:34:49 2026

@author: DELL
"""

# import Numerical as N
import CBSWithoutStatus as CBS
import benchmarkWithoutStatus as BM
import csv
import s2str
import randomGenerator as rg
from datetime import datetime
import time
t1 = time.time()
# def Numerical_optimalVehicle(wcc, pc, low_d,up_d, h, low_s, up_s, count, fileName):    
#     for i in range(count):
#         s = rg.random_nums(wcc, low_s, up_s)
#         d = rg.random_nums(wcc-1, low_d,up_d)
#         for vc in range(1, wcc):
#             print('VC = ' + str(vc))
            
#             cbs = CBS.CBS(wcc, pc, vc, s, d, h)
#             cbs_makespan, cbs_makespan_t = cbs.CBS_NL(3, 3)
#             # print(wcc, pc, vc, s, d, h)
#             # benchmark = BM.Benchmarks(wcc, pc, vc, s, d, h)
#             # STT_makespan, STT_makespan_t = benchmark.STT_Rule()
            
#             # benchmark = BM.Benchmarks(wcc, pc, vc, s, d, h)
#             # EDD_makespan, EDD_makespan_t = benchmark.EDD_Rule()
            
#             # benchmark = BM.Benchmarks(wcc, pc, vc, s, d, h)
#             # rSI_makespan, rSI_makespan_t = benchmark.rSI_Rule()
            
#             f = open(fileName,'a',newline='')
#             writer = csv.writer(f)
#             writer.writerow([ vc,
#                               pc,
#                               wcc,
#                               pc*wcc,
#                               low_s, up_s,
#                               s2str.list2str(s),
#                               low_d,up_d,
#                               s2str.list2str(d),
#                               h,
#                               cbs_makespan,
#                               # STT_makespan,
#                               # EDD_makespan,
#                               # rSI_makespan
#                               ])
#             f.close()
#     return
import traceback

def Numerical_optimalVehicle(wcc, pc, low_d, up_d, h, low_s, up_s, count, fileName):
    """
    生成 count 组(s,d)实例。
    对每一组实例：遍历 vc=1..wcc-1 计算 CBS。
    若任一 vc 计算(如 cbs.CBS_NL)报错，则该组所有 vc 结果作废，不写入文件，
    并重新生成 s,d，直到成功写入 count 组为止。
    """
    success = 0
    attempt = 0

    while success < count:
        attempt += 1
        # 每次尝试生成一组新的实例参数
        s = rg.random_nums(wcc, low_s, up_s)
        d = rg.random_nums(wcc - 1, low_d, up_d)

        rows_buffer = []   # 暂存该组所有 vc 的输出行
        ok = True

        for vc in range(1, wcc):
            try:
                print(f'[try {attempt} | ok {success}/{count}] VC = {vc}')

                cbs = CBS.CBS(wcc, pc, vc, s, d, h)
                cbs_makespan, cbs_makespan_t = cbs.CBS_NL(3, 3)

                rows_buffer.append([
                    vc,
                    pc,
                    wcc,
                    pc * wcc,
                    low_s, up_s,
                    s2str.list2str(s),
                    low_d, up_d,
                    s2str.list2str(d),
                    h,
                    cbs_makespan,
                    # 你如果也想记录时间，可把下面这一列加上
                    # cbs_makespan_t,
                ])

            except Exception as e:
                ok = False
                print(f'!! Error at VC={vc}, discard this whole instance (all vc results).')
                print(f'   Exception: {e}')
                # 如果你想看完整堆栈，取消下一行注释
                # traceback.print_exc()
                break

        # 只有该组所有 vc 都成功，才写入并计数
        if ok and len(rows_buffer) == (wcc - 1):
            with open(fileName, 'a', newline='') as f:
                writer = csv.writer(f)
                writer.writerows(rows_buffer)
            success += 1
        else:
            # 本组作废，继续 while 重新生成 s,d
            continue

    return
import multiprocessing as mp

TIMEOUT_SECONDS = 30 * 60  # 30分钟


def _run_cbs_nl_worker(wcc, pc, vc, s, d, h, out_q):
    """
    子进程执行：创建CBS并跑CBS_NL，把结果放到队列。
    注意：CBS对象不要在主进程创建再传过来（可能不可pickle），在子进程里创建最稳。
    """
    try:
        cbs = CBS.CBS(wcc, pc, vc, s, d, h)
        makespan, runtime = cbs.CBS_NL(3, 3)
        out_q.put(("ok", makespan, runtime))
    except Exception as e:
        out_q.put(("err", repr(e), traceback.format_exc()))


def _cbs_nl_with_timeout(wcc, pc, vc, s, d, h, timeout_seconds=TIMEOUT_SECONDS):
    """
    在独立进程中运行CBS_NL，返回 (ok, makespan, runtime, err_msg)。
    超时/异常都会返回 ok=False，并带错误信息。
    """
    out_q = mp.Queue(maxsize=1)
    p = mp.Process(target=_run_cbs_nl_worker, args=(wcc, pc, vc, s, d, h, out_q))
    p.start()
    p.join(timeout_seconds)

    if p.is_alive():
        # 超时：杀掉子进程，清理资源
        p.terminate()
        p.join()
        return False, None, None, f"Timeout > {timeout_seconds}s"

    # 正常结束：取结果
    if out_q.empty():
        return False, None, None, "No result returned (process ended without output)"
    tag, a, b = out_q.get()
    if tag == "ok":
        makespan, runtime = a, b
        return True, makespan, runtime, None
    else:
        err_repr, err_tb = a, b
        return False, None, None, f"{err_repr}\n{err_tb}"


def Numerical_optimalVehicle_new(wcc, pc, low_d, up_d, h, low_s, up_s, count, fileName):
    """
    生成 count 组(s,d)实例。
    对每一组实例：遍历 vc=1..wcc-1 计算 CBS。
    若任一 vc 报错或超时（>30min），则该组所有 vc 结果作废，不写入文件，
    并重新生成 s,d，直到成功写入 count 组为止。
    """
    success = 0
    attempt = 0

    while success < count:
        attempt += 1
        s = rg.random_nums(wcc, low_s, up_s)
        d = rg.random_nums(wcc - 1, low_d, up_d)

        rows_buffer = []
        ok = True

        for vc in range(1, wcc+1):
            print(f'[try {attempt} | ok {success}/{count}] VC = {vc}')

            ok_vc, cbs_makespan, cbs_runtime, err = _cbs_nl_with_timeout(
                wcc, pc, vc, s, d, h, timeout_seconds=TIMEOUT_SECONDS
            )

            if not ok_vc:
                ok = False
                print(f'!! Fail at VC={vc}, discard this whole instance (all vc results).')
                print(f'   Reason: {err}')
                break

            rows_buffer.append([
                vc,
                pc,
                wcc,
                pc * wcc,
                low_s, up_s,
                s2str.list2str(s),
                low_d, up_d,
                s2str.list2str(d),
                h,
                cbs_makespan,
                # 如果要记录CBS_NL运行时间，取消下一行注释：
                # cbs_runtime,
            ])

        if ok and len(rows_buffer) == (wcc):
            with open(fileName, 'a', newline='') as f:
                writer = csv.writer(f)
                writer.writerows(rows_buffer)
            success += 1
        else:
            continue

    return
if __name__ == "__main__":
    W = 7
    P = 14
    H = 1
    D = [(2,2)]#,,(4,4),(6,6),(8,8),(10,10),(12,12),(14,14)
    # low_s, up_s = 10,20
    S = [(5,10)]
    count = 1
    total = count*len(D)*len(S)*8
    actual = total
    current_date = datetime.now().date()
    date_str = current_date.strftime('%Y-%m-%d')
    date_str = "2026-02-25"
    fileName = 'figure_agvNum_wd'+date_str+'.csv'
    f = open(fileName,'a',newline='')
    writer = csv.writer(f)
    writer.writerow([ 'vc',
                      'pc',
                      'wcc',
                      'taskcount',
                      'low_s', 'up_s',
                      'S',
                      'low_d','up_d',
                      'D',
                      'h',
                      'cbs_makespan',
                      # 'STT_makespan',
                      # 'EDD_makespan',
                      # 'rSI_makespan',
                      'group'
                      ])
    f.close()
    for W in [11]:#, 11,12,13,6,7,8,9,10,11,12,13
        for low_d,up_d in D:
            for low_s, up_s in S:
                Numerical_optimalVehicle_new(W, P, low_d,up_d, H, low_s, up_s, count, fileName)
                actual -= count
                print('Progress: {:.2%}'.format(1-actual/total))
    
    t2 = time.time()