# -*- coding: utf-8 -*-
"""
Created on Sat Jan 25 11:23:42 2025

@author: 74110
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import optimize as op
import matplotlib as mpl

plt.figure(figsize = (20,15), dpi = 600)
plt.rcParams.update({
    'font.size': 24,  # 字体大小
    'font.family': 'times new roman',  # 字体家族
    'mathtext.fontset': 'stix',  # 让数学公式字体与主字体匹配
})
plt.subplots_adjust(left=None, bottom=None, right=None, top=None, wspace=0.35, hspace=0.35)
df = pd.read_csv('figure_turning_data2025-03-07.csv')
V = [2,3,4,5,6]
D = [2,5,8,11,14]
i = 1
for v in V:
    for d in D:
        plt.subplot(5,5,i)
        data = df[(df['v'] == v) & (df['d'] == d) & (df['k'] <= 8) & (df['k'] >= -8)].sort_values(by='k',ascending = False)
        ks = data['k']
        objs = data['cbs_makespan']
        plt.plot(ks, objs, '-o', label='v = '+ str(v))
        plt.axvline(0, color = 'red',linestyle='--', label='balanced')
        # plt.legend()
        # plt.xlabel('$k$')
        # plt.ylabel('makespan')
        # plt.title('$v={},d={}$'.format(v,d))
        i += 1
plt.tight_layout()
# plt.suptitle('turning terminal')
plt.show()