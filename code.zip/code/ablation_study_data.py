# -*- coding: utf-8 -*-
"""
Created on Thu Sep 11 10:48:28 2025

@author: DELL
"""

# import Numerical as N
from itertools import product
from datetime import datetime
# performance evaluate
import random
from gurobipy import *
# import GurobiWithStatus as GSLS
import GurobiWithoutStatus as GS
import CBSWithoutStatus as CBS
# import CBSWithStatus as CBSWS
# import benchmarkWithoutStatus as BM
# import benchmarkWithStatus as BMWS
import numpy as np
import csv
import s2str
import randomGenerator as rg
import time
t1 = time.time()

def new_performance(wcc, vc, pc, low_d, up_d, h, low_s, up_s, time, count, fileName):
    for i in range(count):
        s = rg.random_nums(wcc, low_s, up_s)
        d = rg.random_nums(wcc-1, low_d,up_d)
        try:
            # t1 = time.perf_counter()
            print(str(i+1)+"th")
            # best_obj, best_bound, optimal_gap, timeConsume = GS.newAGVSchedul(vc, pc, wcc, s, d, h, t_limited=time)
            # print(best_obj, best_bound, optimal_gap, timeConsume)
            
            cbs_makespan, cbs_makespan_t,cbs_all_makespan,cbs_all_t = None,None,None,None
            cbs = CBS.CBS(wcc, pc, vc, s, d, h)
            cbs_makespan, cbs_makespan_t = cbs.CBS_NL(3, 3)
            cbs_all_makespan,cbs_all_t = cbs.CBS_A()
            # print(cbs_makespan, cbs_makespan_t)
            # mcbs = CBS.MCBS(wcc, pc, vc, s, d, h)
            # mcbs_makespan, mcbs_makespan_t = mcbs.CBS_NL(3, 3, True)
        except Exception as E_results:
            print("捕捉有异常：",E_results)
            print(cbs_makespan, cbs_makespan_t,cbs_all_makespan,cbs_all_t)
            f = open(fileName,'a',newline='')
            writer = csv.writer(f)
            writer.writerow([ vc,
                              pc,
                              wcc,
                              pc*wcc,
                              low_s, up_s,
                              s2str.list2str(s),
                              low_d, up_d,
                              s2str.list2str(d),
                              h
                              ])
            f.close()
        else:
            f = open(fileName,'a',newline='')
            writer = csv.writer(f)
            writer.writerow([ vc,
                              pc,
                              wcc,
                              pc*wcc,
                              low_s, up_s,
                              s2str.list2str(s),
                              low_d, up_d,
                              s2str.list2str(d),
                              h,
                              # best_obj, best_bound, optimal_gap, timeConsume,
                              cbs_makespan, cbs_makespan_t, cbs_all_makespan,cbs_all_t
                              ])
            f.close()
    return
            
WP = [(6,7),(7,8),(8,9),(9,10)]
V = [3,4,5]
D = [(2,5)]
S = [(5,10),(10,15),(15,20),(20,25)]
H = 1
count = 20
total = count*len(D)*len(S)*len(WP)*len(V)
actual = total
current_date = datetime.now()
date_str = current_date.strftime('%Y-%m-%d')
current_date = datetime.now().date()
date_str = current_date.strftime('%Y-%m-%d')
fileName = 'compare cbs and cbsnl'+date_str+'.csv'
f = open(fileName,'a',newline='')
writer = csv.writer(f)
writer.writerow([ 'vc',
                  'pc',
                  'wcc',
                  'taskcount',
                  'low_s', 'up_s',
                  'S',
                  'low_d','up_d',
                  'D',
                  'h',
                  # 'best_obj', 'best_bound', 'optimal_gap', 'timeConsume',
                  'cbs_makespan', 'cbs_makespan_t','cbs_all_makespan', 'cbs_all_t'
                  ])
f.close()
for wcc, pc in WP:
    for vc in V:
        for low_d, up_d in D:
            for low_s, up_s in S:
                new_performance(wcc,vc,pc,low_d,up_d,H,low_s,up_s, 3600, count, fileName)
                actual -= count
                print('Progress: {:.2%}'.format(1-actual/total))
t2 = time.time()