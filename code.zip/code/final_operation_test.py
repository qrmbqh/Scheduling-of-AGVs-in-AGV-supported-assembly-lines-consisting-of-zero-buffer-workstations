# -*- coding: utf-8 -*-
"""
Created on Fri Mar  6 11:54:22 2026

@author: LJC
"""

import random
import ini_solution as IS
import timeSceduling as ts
import new_neighbourhood_feasible_test as NB
import pandas as pd
# import matplotlib.pyplot as plt
from neighbourhood_feasible_test import intra_route_swap,inter_route_swap, two_opt,two_opt_star, relocate,cross_exchange,or_opt
from tqdm import tqdm
times = 10
count=100
data = []
# for f in [intra_route_swap,inter_route_swap, two_opt,two_opt_star, relocate,cross_exchange,or_opt]:
for f in tqdm([intra_route_swap,inter_route_swap, two_opt,two_opt_star, relocate,cross_exchange,or_opt], ncols=100):
    for p in tqdm(range(7, 10),ncols=100):
        for w in tqdm(range(p-3, p+1),ncols=100):
            for _ in tqdm(range(count),ncols=100):
                # print(f'iteration {i}')
                # p= random.randint(6, 10)
                # w= random.randint(p-3, p)
                v= random.randint(2, w-1)
                s = [random.randint(3, 10) for _ in range(w)]
                d = [random.randint(2, 5) for _ in range(w-1)]
                h= 1
                ts.setGlobalParam(w, p, v, s, d, h)
                IS.setGlobalParam(w, p, v, s, d, h)
                # print(f'operation {f.__name__}')
                tag_vrptw, tag_vrptwr,tag_asp,tag_aspr,tag_rasp,operation= NB.random_neighbourhood_feasible_VRPTW_repair(times, move_fn =f, vrptw_scale=p*(w-1))
                for i in range(times):
                    _data = {
                        'scale':p*(w-1),'operation':operation,
                        'tag_asp':1 if tag_asp[i] else 0,
                        'tag_aspr':1 if tag_aspr[i] else 0,
                        'tag_rasp':1 if tag_rasp[i] else 0,
                        'tag_vrptw':1 if tag_vrptw[i] else 0,
                        'tag_vrptwr':1 if tag_vrptwr[i] else 0,
                        } 
                    data.append(_data)
df = pd.DataFrame(data)
df.to_excel('operation_2026_03_06.xlsx')
# df = pd.read_excel('operation_2026_0225.xlsx',sheet_name='Sheet1')
# data = {}
# grouped = df.groupby('scale')
# # data['size'] = grouped['pw']
# data['my']=grouped['tag'].sum()
# data['relaxed']=grouped['tag_relaxed'].sum()
# data['vrptw']=grouped['tag_vrptw'].sum()

# data['size']=grouped.size()

# data['my_rate'] = data['my']/data['size']
# data['relaxed_rate'] = data['relaxed']/data['size']
# data['vrptw_rate'] = data['vrptw']/data['size']

# plt.figure(figsize=(9,5), dpi=600)
# plt.plot(data['my_rate'].index, data['my_rate'].values, label = 'My')
# plt.plot(data['relaxed_rate'].index, data['relaxed_rate'].values, label = 'Relaxed')
# plt.plot(data['vrptw_rate'].index, data['vrptw_rate'].values, label = 'VRPTW')
# plt.legend()
# df = pd.DataFrame(data)