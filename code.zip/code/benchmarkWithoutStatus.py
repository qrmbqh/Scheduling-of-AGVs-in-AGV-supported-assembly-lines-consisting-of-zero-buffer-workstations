# -*- coding: utf-8 -*-
"""
Created on Thu Feb 23 20:31:56 2023

@author: qrmbqh
"""

import random
from gurobipy import *
import matplotlib.pyplot as plt
import STT
import SI
import demo_for_company_plan_without_init_0228 as cp#demo_for_company_plan_without_init_0228
import EDD
import rSI
import pandas as pd
import time
import list2int as l2i

class WorkStation:
    def __init__(self, index, serviceTime, nextDistance):
        self.id = index
        self.serviceTime = serviceTime
        self.d = nextDistance
        self.status = 0#0-空闲，1-货物占用未分配AGV，2-AGV占用等待搬货 3-AGV占用等待指派新任务,4-已分配AGV尚未到达
        self.restTime = 0
        self.type = "w"
        self.presentProd = None
                
    def timeToFree(self, workStations, tasks, Roads):
        M = 9999999
        if self.id == len(workStations)-1:
            if self.status == 0 or self.status == 1:
                self.timeToBeFree = self.restTime
            else:
                self.timeToBeFree = M
        else:
            workStations[self.id + 1].timeToFree(workStations, tasks, Roads)
            if self.status == 1 or self.status == 3:
               self.timeToBeFree = M
            elif self.status == 2:
                if Roads[self.id].status == 1:
                    self.timeToBeFree = M
                else:
                    self.timeToBeFree = max(self.restTime, workStations[self.id + 1].timeToBeFree - self.d)
            elif self.status == 4:
                if tasks[self.id, self.presentProd.id].agv.status == 3 or Roads[self.id].status == 1:
                    self.timeToBeFree = M
                else:
                    self.timeToBeFree = max(tasks[self.id, self.presentProd.id].agv.restTime, self.restTime, workStations[self.id + 1].timeToBeFree - self.d)
            else:
                self.timeToBeFree = 0


class AGV:
    def __init__(self, index):
        self.id = index
        self.status = -1 #-1-库中等待，0-空车前往目的地，1-背货前往目的地，2-等待背货出发，3-等待空车出发
        self.restTime = 0
        self.route = [(0,-1)]
        self.back = 0
        self.presentLoc = None
        self.destination = None
        
    def ArriveWorkStation(self, workStation, tasks):
        self.destination = None
        self.status = 2
        self.route.append((workStation.id, workStation.presentProd.id))
        self.restTime = 0
        self.presentLoc = workStation
        self.presentLoc.status = 2
        tasks[self.presentLoc.id, self.presentLoc.presentProd.id].status = 2
        
    def LeaveWorkStation(self, workStation, tasks, T, systime, w):
        if len(self.route) > 1:
            tasks[self.route[-1]].endTime = systime
        self.status = 0
        self.destination = workStation
        
        if self.presentLoc.id < w-1:
            if self.presentLoc.status == 3:
                self.presentLoc.status = 1
        else:
            if self.presentLoc.presentProd != None:
                self.presentLoc.status = 1
            else:
                self.presentLoc.status = 0

        if len(self.route) == 1:
            self.restTime = T[self.route[-1][0], workStation.id]
        else:
            self.restTime = T[self.route[-1][0] + 1, workStation.id]
        self.presentLoc = "Going to destination!"

class Product:
    def __init__(self, index):
        self.id = index
        self.status = 0
        self.isFinished = 0
        self.presentLoc = None
        self.restTime = 0#记录在路上行走的时间
        self.beginProcessTime = 0
        self.endProcessTime = 0
    
    def MoveToWorkStation(self, workStations, tasks, Roads, systime):
        self.restTime = 0
        tasks[self.presentLoc.id, self.id].status = 4
        tasks[self.presentLoc.id, self.id].agv.status = 3
        tasks[self.presentLoc.id, self.id].agv.presentLoc = workStations[self.presentLoc.id + 1]
        self.presentLoc.status = 0
        self.presentLoc = workStations[self.presentLoc.id + 1]
        self.presentLoc.status = 3
        self.presentLoc.restTime = self.presentLoc.serviceTime
        self.presentLoc.presentProd = self
        self.presentLoc.timeToFree(workStations,tasks,Roads)
        
    def MoveToRoad(self, workStations, roads, tasks, systime):
        tasks[self.presentLoc.id, self.id].startTime = systime
        tasks[self.presentLoc.id, self.id].status = 3
        tasks[self.presentLoc.id, self.id].status = 1
        self.presentLoc.restTime = 0
        self.presentLoc.status = 0
        self.presentLoc.presentProd = None
        
        if self.presentLoc == workStations[-1]:
            if tasks[self.presentLoc.id - 1, self.id].agv.presentLoc == workStations[-1]:
                self.presentLoc.status = 5
            self.isFinished = 1
            self.endProcessTime = systime
            self.restTime = 0
            self.presentLoc = "None"
        else:
            tasks[self.presentLoc.id, self.id].agv.status = 1
            tasks[self.presentLoc.id, self.id].agv.presentLoc = roads[self.presentLoc.id]
            self.presentLoc = roads[self.presentLoc.id]
            self.presentLoc.status = 1
            self.restTime = self.presentLoc.serviceTime
        
            
    def EnterLine(self, workStations, tasks, Roads, systime):
        self.status = 1
        self.startProcessTime = systime
        self.presentLoc = workStations[0]
        self.presentLoc.status = 1
        self.presentLoc.presentProd = self
        self.presentLoc.restTime = self.presentLoc.serviceTime
        self.presentLoc.timeToFree(workStations,tasks, Roads)
        
class Task:
    def __init__(self, ws, p):
        self.presentLoc = None
        self.pid = p
        self.agv = None
        self.startPoint = ws
        self.startTime = 0
        self.endTime = 0
        self.status = 0#0-未开始，1-已指派AGV未到达，2-AGV到达等待开始，3-搬运中，4-到达目的地AGV未离开，5-结束
    def canStart(self, workStations,Roads,agvs, tasks):
        workStations[self.startPoint].timeToFree(workStations, tasks ,Roads)
        if workStations[self.startPoint].timeToBeFree == 0 and self.agv.restTime == 0:
            return True
        else:
            return False
        
class Road:
    def __init__(self, ind, traveTime):
        self.serviceTime = traveTime
        self.status = 0
        self.type = "r"
        self.id = ind

class Benchmarks:
    def __init__(self, w, p, v, s, d, h):
        self.w = w
        self.p = p
        self.v = v
        self.s = s
        self.d = d
        self.h = h
        
    def STT_Rule(self):
        t1 = time.perf_counter()
        T_d = [(i,j) for i in range(self.w) for j in range(self.w)]
    
        T = {}
        for i,j in T_d:
            if i <= j:
                T[i,j] = sum(self.d[i:j])
            else:
                T[i,j] = sum(self.d[j:i]) + 2 * self.h
       
        workStations = [] 
        for i in range(self.w):
            workStations.append(WorkStation(i, self.s[i], (self.d + [0])[i]))
        
        products = []
        for i in range(self.p):
            products.append(Product(i))
            
        AGVs = []
        for i in range(self.v):
            AGVs.append(AGV(i))
        
        Roads = []
        for i in range(self.w-1):
            Roads.append(Road(i, self.d[i]))
        
        tasks = {}
        for i in range(self.w):
            for j in range(self.p):
                tasks[i,j] = Task(i, j)

        systime = 0
        products[0].EnterLine(workStations, tasks, Roads, systime)
        while True:
            STT.Heuristic(workStations, AGVs, tasks, Roads, systime, T)
            systime += 1
            # print(systime)
            for product in products:
                if product.presentLoc != None:
                    if product.isFinished != 1:
                        if product.presentLoc.type == "r":
                            if product.restTime == 1:
                                product.MoveToWorkStation(workStations, tasks, Roads, systime)
                            else:
                                product.restTime -= 1
                        else:
                            if tasks[product.presentLoc.id, product.id].agv == None:
                                if product.presentLoc.restTime == 1 and product.presentLoc.id == self.w - 1:
                                    product.MoveToRoad(workStations, Roads, tasks, systime)
                                else:
                                    product.presentLoc.restTime = max(0, product.presentLoc.restTime - 1)
                            else:
                                if tasks[product.presentLoc.id, product.id].agv.status == 0:
                                    tasks[product.presentLoc.id, product.id].agv.restTime = max(0, tasks[product.presentLoc.id, product.id].agv.restTime - 1)
                                    if tasks[product.presentLoc.id, product.id].agv.restTime == 0:
                                        tasks[product.presentLoc.id, product.id].agv.ArriveWorkStation(product.presentLoc, tasks)
                                product.presentLoc.restTime = max(0, product.presentLoc.restTime - 1)
                                if tasks[product.presentLoc.id, product.id].canStart(workStations, Roads, AGVs, tasks):
                                    product.MoveToRoad(workStations, Roads, tasks, systime)
                elif workStations[0].status == 0:
                        product.EnterLine(workStations, tasks,Roads, systime)
                else:
                    break
            if products[-1].isFinished == 1:
                break
            
        t2 = time.perf_counter()
        return systime, t2-t1        

    def SI_Rule(self):
        t1 = time.perf_counter()
        T_d = [(i,j) for i in range(self.w) for j in range(self.w)]
    
        T = {}
        for i,j in T_d:
            if i <= j:
                T[i,j] = sum(self.d[i:j])
            else:
                T[i,j] = sum(self.d[j:i]) + 2 * self.h
       
        workStations = [] 
        for i in range(self.w):
            workStations.append(WorkStation(i, self.s[i], (self.d + [0])[i]))
        
        products = []
        for i in range(self.p):
            products.append(Product(i))
            
        AGVs = []
        for i in range(self.v):
            AGVs.append(AGV(i))
        
        Roads = []
        for i in range(self.w-1):
            Roads.append(Road(i, self.d[i]))
        
        tasks = {}
        for i in range(self.w):
            for j in range(self.p):
                tasks[i,j] = Task(i, j)

        systime = 0
        products[0].EnterLine(workStations, tasks, Roads, systime)
        while True:
            SI.Heuristic(workStations, AGVs, tasks, Roads, systime, T)
            systime += 1
            # print(systime)
            for product in products:
                if product.presentLoc != None:
                    if product.isFinished != 1:
                        if product.presentLoc.type == "r":
                            if product.restTime == 1:
                                product.MoveToWorkStation(workStations, tasks, Roads, systime)
                            else:
                                product.restTime -= 1
                        else:
                            if tasks[product.presentLoc.id, product.id].agv == None:
                                if product.presentLoc.restTime == 1 and product.presentLoc.id == self.w - 1:
                                    product.MoveToRoad(workStations, Roads, tasks, systime)
                                else:
                                    product.presentLoc.restTime = max(0, product.presentLoc.restTime - 1)
                            else:
                                if tasks[product.presentLoc.id, product.id].agv.status == 0:
                                    tasks[product.presentLoc.id, product.id].agv.restTime = max(0, tasks[product.presentLoc.id, product.id].agv.restTime - 1)
                                    if tasks[product.presentLoc.id, product.id].agv.restTime == 0:
                                        tasks[product.presentLoc.id, product.id].agv.ArriveWorkStation(product.presentLoc, tasks)
                                product.presentLoc.restTime = max(0, product.presentLoc.restTime - 1)
                                if tasks[product.presentLoc.id, product.id].canStart(workStations, Roads, AGVs, tasks):
                                    product.MoveToRoad(workStations, Roads, tasks, systime)
                elif workStations[0].status == 0:
                        product.EnterLine(workStations, tasks,Roads, systime)
                else:
                    break
            if products[-1].isFinished == 1:
                break
            
        t2 = time.perf_counter()
        return systime, t2-t1  
    
    def EDD_Rule(self):
        t1 = time.perf_counter()
        T_d = [(i,j) for i in range(self.w) for j in range(self.w)]
    
        T = {}
        for i,j in T_d:
            if i <= j:
                T[i,j] = sum(self.d[i:j])
            else:
                T[i,j] = sum(self.d[j:i]) + 2 * self.h
       
        workStations = [] 
        for i in range(self.w):
            workStations.append(WorkStation(i, self.s[i], (self.d + [0])[i]))
        
        products = []
        for i in range(self.p):
            products.append(Product(i))
            
        AGVs = []
        for i in range(self.v):
            AGVs.append(AGV(i))
        
        Roads = []
        for i in range(self.w-1):
            Roads.append(Road(i, self.d[i]))
        
        tasks = {}
        for i in range(self.w):
            for j in range(self.p):
                tasks[i,j] = Task(i, j)
        
        C = EDD.conveyorModel(wcc = self.w, pc = self.p, s = self.s, d = self.d, h = self.h)
        systime = 0
        products[0].EnterLine(workStations, tasks, Roads, systime)
        while True:
            EDD.Heuristic(workStations, AGVs, tasks, Roads, systime, T, C)
            systime += 1
            # print(systime)
            for product in products:
                if product.presentLoc != None:
                    if product.isFinished != 1:
                        if product.presentLoc.type == "r":
                            if product.restTime == 1:
                                product.MoveToWorkStation(workStations, tasks, Roads, systime)
                            else:
                                product.restTime -= 1
                        else:
                            if tasks[product.presentLoc.id, product.id].agv == None:
                                if product.presentLoc.restTime == 1 and product.presentLoc.id == self.w - 1:
                                    product.MoveToRoad(workStations, Roads, tasks, systime)
                                else:
                                    product.presentLoc.restTime = max(0, product.presentLoc.restTime - 1)
                            else:
                                if tasks[product.presentLoc.id, product.id].agv.status == 0:
                                    tasks[product.presentLoc.id, product.id].agv.restTime = max(0, tasks[product.presentLoc.id, product.id].agv.restTime - 1)
                                    if tasks[product.presentLoc.id, product.id].agv.restTime == 0:
                                        tasks[product.presentLoc.id, product.id].agv.ArriveWorkStation(product.presentLoc, tasks)
                                product.presentLoc.restTime = max(0, product.presentLoc.restTime - 1)
                                if tasks[product.presentLoc.id, product.id].canStart(workStations, Roads, AGVs, tasks):
                                    product.MoveToRoad(workStations, Roads, tasks, systime)
                elif workStations[0].status == 0:
                        product.EnterLine(workStations, tasks,Roads, systime)
                else:
                    break
            if products[-1].isFinished == 1:
                break
            
        t2 = time.perf_counter()
        return systime, t2-t1

    def rSI_Rule(self):
        t1 = time.perf_counter()
        T_d = [(i,j) for i in range(self.w) for j in range(self.w)]
    
        T = {}
        for i,j in T_d:
            if i <= j:
                T[i,j] = sum(self.d[i:j])
            else:
                T[i,j] = sum(self.d[j:i]) + 2 * self.h
       
        workStations = [] 
        for i in range(self.w):
            workStations.append(WorkStation(i, self.s[i], (self.d + [0])[i]))
        
        products = []
        for i in range(self.p):
            products.append(Product(i))
            
        AGVs = []
        for i in range(self.v):
            AGVs.append(AGV(i))
        
        Roads = []
        for i in range(self.w-1):
            Roads.append(Road(i, self.d[i]))
        
        tasks = {}
        for i in range(self.w):
            for j in range(self.p):
                tasks[i,j] = Task(i, j)
        
        C = rSI.conveyorModel(wcc = self.w, pc = self.p, s = self.s, d = self.d, h = self.h)
        systime = 0
        products[0].EnterLine(workStations, tasks, Roads, systime)
        while True:
            rSI.Heuristic(workStations, AGVs, tasks, Roads, systime, T, C)
            systime += 1
            # print(systime)
            for product in products:
                if product.presentLoc != None:
                    if product.isFinished != 1:
                        if product.presentLoc.type == "r":
                            if product.restTime == 1:
                                product.MoveToWorkStation(workStations, tasks, Roads, systime)
                            else:
                                product.restTime -= 1
                        else:
                            if tasks[product.presentLoc.id, product.id].agv == None:
                                if product.presentLoc.restTime == 1 and product.presentLoc.id == self.w - 1:
                                    product.MoveToRoad(workStations, Roads, tasks, systime)
                                else:
                                    product.presentLoc.restTime = max(0, product.presentLoc.restTime - 1)
                            else:
                                if tasks[product.presentLoc.id, product.id].agv.status == 0:
                                    tasks[product.presentLoc.id, product.id].agv.restTime = max(0, tasks[product.presentLoc.id, product.id].agv.restTime - 1)
                                    if tasks[product.presentLoc.id, product.id].agv.restTime == 0:
                                        tasks[product.presentLoc.id, product.id].agv.ArriveWorkStation(product.presentLoc, tasks)
                                product.presentLoc.restTime = max(0, product.presentLoc.restTime - 1)
                                if tasks[product.presentLoc.id, product.id].canStart(workStations, Roads, AGVs, tasks):
                                    product.MoveToRoad(workStations, Roads, tasks, systime)
                elif workStations[0].status == 0:
                        product.EnterLine(workStations, tasks,Roads, systime)
                else:
                    break
            if products[-1].isFinished == 1:
                break
            
        t2 = time.perf_counter()
        return systime, t2-t1
    
    def Enterprise(self):
        makespan, t = cp.Update(self.v, self.p, self.w, self.d, self.h, self.s).init_data()
        return makespan, t/1000
    
    def greedy_insertion(self):
        t1 = time.perf_counter()
        T_d = [(i,j) for i in range(self.w) for j in range(self.w)]
    
        T = {}
        for i,j in T_d:
            if i <= j:
                T[i,j] = sum(self.d[i:j])
            else:
                T[i,j] = sum(self.d[j:i]) + 2 * self.h
       
        workStations = [] 
        for i in range(self.w):
            workStations.append(WorkStation(i, self.s[i], (self.d + [0])[i]))
        
        products = []
        for i in range(self.p):
            products.append(Product(i))
            
        AGVs = []
        for i in range(self.v):
            AGVs.append(AGV(i))
        
        Roads = []
        for i in range(self.w-1):
            Roads.append(Road(i, self.d[i]))
        
        tasks = {}
        for i in range(self.w):
            for j in range(self.p):
                tasks[i,j] = Task(i, j)
        
        C = EDD.conveyorModel(wcc = self.w, pc = self.p, s = self.s, d = self.d, h = self.h)
        systime = 0
        products[0].EnterLine(workStations, tasks, Roads, systime)
        while True:
            EDD.Heuristic(workStations, AGVs, tasks, Roads, systime, T, C)
            systime += 1
            # print(systime)
            for product in products:
                if product.presentLoc != None:
                    if product.isFinished != 1:
                        if product.presentLoc.type == "r":
                            if product.restTime == 1:
                                product.MoveToWorkStation(workStations, tasks, Roads, systime)
                            else:
                                product.restTime -= 1
                        else:
                            if tasks[product.presentLoc.id, product.id].agv == None:
                                if product.presentLoc.restTime == 1 and product.presentLoc.id == self.w - 1:
                                    product.MoveToRoad(workStations, Roads, tasks, systime)
                                else:
                                    product.presentLoc.restTime = max(0, product.presentLoc.restTime - 1)
                            else:
                                if tasks[product.presentLoc.id, product.id].agv.status == 0:
                                    tasks[product.presentLoc.id, product.id].agv.restTime = max(0, tasks[product.presentLoc.id, product.id].agv.restTime - 1)
                                    if tasks[product.presentLoc.id, product.id].agv.restTime == 0:
                                        tasks[product.presentLoc.id, product.id].agv.ArriveWorkStation(product.presentLoc, tasks)
                                product.presentLoc.restTime = max(0, product.presentLoc.restTime - 1)
                                if tasks[product.presentLoc.id, product.id].canStart(workStations, Roads, AGVs, tasks):
                                    product.MoveToRoad(workStations, Roads, tasks, systime)
                elif workStations[0].status == 0:
                        product.EnterLine(workStations, tasks,Roads, systime)
                else:
                    break
            if products[-1].isFinished == 1:
                break
            
        t2 = time.perf_counter()
        return systime, t2-t1
if __name__ == "__main__":
    # data_frame=pd.read_excel(r"随机算例.xlsx",sheet_name='随机算例')
    # height, width = data_frame.shape
    # makespans = []
    # Times = []
    # for col in range(height):
    #     # print(col)
    #     w = int(data_frame.iloc[[col]]['工位'])
    #     p = int(data_frame.iloc[[col]]['产品'])
    #     v = int(data_frame.iloc[[col]]['AGV'])
    #     s = l2i.list2int(list(data_frame.iloc[[col]]['加工时间'])[0])
    #     d = l2i.list2int(list(data_frame.iloc[[col]]['d'])[0])
    #     h = int(data_frame.iloc[[col]]['h'])
        
    #     benchmarks = Benchmarks(w = w, p = p, v = v, s = s, d = d, h = h)
    #     makespan,t  = benchmarks.Enterprise()
    #     makespans.append(makespan)
    #     Times.append(t)
    #     print(makespan,t)

    w = 7
    p = 20
    v = 4
    # s = [12, 4, 7, 4, 4, 3, 1]
    # s = [random.randint(10,20) for i in range(w)]
    # d = [random.randint(1,5) for i in range(w-1)]
    # d = [2, 3, 2, 1, 5, 2]
    h = 1
    # benchmarks = Benchmarks(w = w, p = p, v = v, s = s, d = d, h = h)
    # makespan,t  = benchmarks.rSI_Rule()
    while True:
        s = [random.randint(1,20) for i in range(w)]
    # #     # s = [3,14,2,6,5]
        d = [random.randint(1,5) for i in range(w-1)]
    # #     # d = [3,5,1,5]
        benchmarks = Benchmarks(w = w, p = p, v = v, s = s, d = d, h = h)
        makespan,t  = benchmarks.Enterprise()
        print(makespan,t)
        # makespans.append(makespan)
        # Times.append(t)