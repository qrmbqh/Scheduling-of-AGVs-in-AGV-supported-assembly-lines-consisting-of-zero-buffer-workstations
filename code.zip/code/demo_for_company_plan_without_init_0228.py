# -*- coding: utf-8 -*-
import copy
import numpy as np
import datetime

global agv_num, tables_num, product_num, row_distance, column_distance, workstations_processing_time
global BOX_SIDE, LINE_LENGTH
global total_product
global finish_interval
global time_start
from scipy.optimize import linear_sum_assignment


class AGV:
    def __init__(self, agv):
        self.agv = agv

    def get_agv_next(self):
        """agv 下一个目的地"""
        plan = self.agv["plan"]

        if loading[plan - 1] == self.agv["y"]:
            # 还在等待区
            if self.agv["x"] != 0:
                self.agv["next"] = "up"
            else:
                if self.agv["have_product"]:
                    for product in products_info[self.agv["y"]]:
                        if product["product_id"] == 0 or self.agv["y"] == loading[0]:
                            if product["time_last"] == 0 and res[0, loading[plan]] == 0:
                                self.agv["next"] = "right"
                        if product["product_id"] == self.agv["product"]:
                            if product["time_last"] == 0 and res[0, loading[plan]] == 0:
                                self.agv["next"] = "right"
        # 去右边运输
        if loading[plan - 1] > self.agv["y"]:
            if self.agv["x"] == 0:
                self.agv["next"] = "right"
            else:
                self.agv["next"] = "up"

        if loading[plan - 1] < self.agv["y"]:
            # 运输途中
            if self.agv["have_product"] is True:
                self.agv["next"] = "right"
            else:
                # 去左边运货
                if self.agv["x"] != 1 + (column_distance - 1):
                    self.agv["next"] = "down"
                else:
                    self.agv["next"] = "left"

    def agv_finished(self):
        """判断agv任务是否完成"""
        plan = self.agv["plan"]

        if plan is None or plan == 0:
            self.agv["finished"] = True
        else:
            if self.agv["y"] == loading[plan] and self.agv["x"] == 0:
                if self.agv["have_product"] is True:
                    self.agv["finished"] = True

    def agv_arrived(self):
        """判断agv当前任务是否完成"""
        plan = self.agv["plan"]
        if loading[plan - 1] == self.agv["y"] and self.agv["x"] == 0:
            self.agv["have_product"] = True

        if loading[plan] == self.agv["y"] and self.agv["x"] == 0:
            if self.agv["finished"] is True:
                self.agv["have_product"] = False
                self.agv["plan"] = None

    def agv_update(self):
        """对agv位置进行更新，同时更新全局画面"""
        global products_info
        global products_map, tmp_products
        agv_id = self.agv["agv_id"]
        if self.agv["next"]:
            if self.agv["next"] == "right":
                res[self.agv["x"], self.agv["y"]] = 0
                if self.agv["have_product"] is True:
                    for p, product in enumerate(products_info[self.agv["y"]]):
                        if product["product_id"] == 0:
                            products_info[self.agv["y"]][p]["product_id"] = self.agv["product"]

                    plan = self.agv["plan"]
                    products_map[self.agv["y"]] = 0
                    for p, product in enumerate(products_info[self.agv["y"]]):
                        if product["time_last"] == 0:
                            tmp = products_info[self.agv["y"]][p]
                            del products_info[self.agv["y"]][p]

                            products_map[self.agv["y"] + 1] = 2
                            if (self.agv["y"] + 1) not in products_info:
                                products_info[self.agv["y"] + 1] = []
                            products_info[self.agv["y"] + 1].append(copy.deepcopy(tmp))
                            products_info[self.agv["y"] + 1][-1]["x"] = self.agv["x"]
                            products_info[self.agv["y"] + 1][-1]["y"] = self.agv["y"] + 1

                    if loading[plan] == self.agv["y"] + 1 and self.agv["x"] == 0:
                        for p, product in enumerate(products_info[loading[plan]]):
                            if product["time_last"] == 0 and product["product_id"] == self.agv["product"]:
                                products_info[loading[plan]][p]["time_last"] = workstations_processing_time[plan] + 1
                self.agv["y"] = self.agv["y"] + 1
                self.agv["next"] = None

                res[self.agv["x"], self.agv["y"]] = agv_id + 10

            if self.agv["next"] == "left":
                res[self.agv["x"], self.agv["y"]] = 0
                self.agv["y"] = self.agv["y"] - 1
                self.agv["next"] = None

                res[self.agv["x"], self.agv["y"]] = agv_id + 10

            if self.agv["next"] == "up":
                res[self.agv["x"], self.agv["y"]] = 0
                self.agv["x"] = self.agv["x"] - 1
                self.agv["next"] = None

                res[self.agv["x"], self.agv["y"]] = agv_id + 10

            if self.agv["next"] == "down":
                res[self.agv["x"], self.agv["y"]] = 0
                self.agv["x"] = self.agv["x"] + 1
                self.agv["next"] = None

                res[self.agv["x"], self.agv["y"]] = agv_id + 10
        else:
            res[self.agv["x"], self.agv["y"]] = agv_id + 10


def update_agv_plan():
    """
    获取agv分配方案
    :return:
    """
    need_arrange_agv = []
    need_arrange_workstations = []
    for key, values in products_info.items():
        if key in loading and key != loading[-1]:
            for value in values:
                # 下一个位置没有加工的产品
                if value["time_last"] == 0:
                    index_next = loading.index(key) + 1
                    if loading[index_next] not in products_info or not products_info[loading[index_next]]:
                        need_arrange = True
                        for i, item in agv_data_series.items():
                            if item.agv["plan"] == index_next and item.agv["finished"] is not True:
                                need_arrange = False
                        if need_arrange:
                            station = index_next - 1
                            need_arrange_workstations.append(station)
    for i, item in agv_data_series.items():
        if item.agv["finished"] is True and not item.agv["plan"]:
            need_arrange_agv.append(i)

    # print(need_arrange_agv, need_arrange_workstations)

    if need_arrange_agv and need_arrange_workstations:
        times_arr = np.zeros((len(need_arrange_agv), len(need_arrange_workstations)), dtype=int)
        for i, _agv in enumerate(need_arrange_agv):
            for j, _station in enumerate(need_arrange_workstations):
                if agv_data_series[_agv].agv["y"] == loading[_station]:
                    need_times = agv_data_series[_agv].agv["x"]
                elif agv_data_series[_agv].agv["y"] < loading[_station]:
                    need_times = agv_data_series[_agv].agv["x"] + abs(
                        loading[_station] - agv_data_series[_agv].agv["y"])
                else:
                    need_times = abs(column_distance - agv_data_series[_agv].agv["x"]) + column_distance + abs(
                        agv_data_series[_agv].agv["y"] - loading[_station])
                times_arr[i, j] = need_times
        row_ind, col_ind = linear_sum_assignment(times_arr)

        arrange_dict = dict()
        for i, _agv_id in enumerate(row_ind):
            need_arrange = True
            station = need_arrange_workstations[col_ind[i]]
            for j, item in agv_data_series.items():
                if item.agv["y"] == loading[station + 1] and (item.agv["agv_id"] - 1) not in row_ind:
                    need_arrange = False
            if need_arrange is True:
                arrange_dict[need_arrange_agv[_agv_id]] = need_arrange_workstations[col_ind[i]]

        # print(arrange_dict)
        for key, value in arrange_dict.items():
            agv_data_series[key].agv["plan"] = value + 1
            agv_data_series[key].agv["finished"] = False
            agv_data_series[key].agv["product"] = 1


class Products:

    def init_first_workstations(self):
        """
        生产第一个工位的产品
        :return:
        """
        global products_info, total_product
        if loading[0] not in products_info:
            products_info[loading[0]] = []
        if not products_info[loading[0]] and total_product > 0:
            sub_product_info = dict()
            if interval == 0:
                sub_product_info["time_last"] = workstations_processing_time[0]
            else:
                sub_product_info["time_last"] = workstations_processing_time[0] - 1
            sub_product_info["x"] = 0
            sub_product_info["y"] = 0
            sub_product_info["product_id"] = 0
            products_info[loading[0]].append(sub_product_info)
            total_product = total_product - 1
        for key, values in products_info.items():
            for k, value in enumerate(values):
                if value["time_last"] == 0:
                    products_map[key] = 2
                else:
                    if products_map[key] == 0:
                        products_map[key] = 1

    def update_products(self):
        global products_info
        for key, values in products_info.items():
            for k, value in enumerate(values):
                if value["time_last"] > 0:
                    products_info[key][k]["time_last"] -= 1

    def get_finish_products(self):
        """获取已完成加工的产品,更新还需要加工的产品列表"""
        global products_info, finish_products
        for values in products_info.values():
            for value in values:
                if value["x"] == 0 and value["y"] == loading[-1]:
                    if value["time_last"] == 0:
                        finish_products.append(value)
        tmp_list = dict()
        for key, items in products_info.items():
            for k, item in enumerate(items):
                if item not in finish_products:
                    if key not in tmp_list:
                        tmp_list[key] = []
                    tmp_list[key].append(copy.deepcopy(item))

        products_info = tmp_list


def init_all_agv_data():
    """
    初始化agv
    :param agv_start_status:
    :return:
    """
    global finish_products, agv_data_series, res, tmp_products
    finish_products = []
    tmp_products = []
    all_agv_data = []

    for num in range(agv_num):
        single_agv_data = dict()
        single_agv_data["agv_id"] = num + 1
        single_agv_data["next"] = None
        single_agv_data["finished"] = True
        single_agv_data["have_product"] = False
        single_agv_data["plan"] = None
        single_agv_data["product"] = 0
        single_agv_data["continue_times"] = 0
        single_agv_data["x"] = 0
        single_agv_data["y"] = 0
        all_agv_data.append(copy.deepcopy(single_agv_data))
    for q, agv_data in enumerate(all_agv_data):
        agv_data_series["agv_%s" % agv_data["agv_id"]] = AGV(agv_data)


class Update:

    def __init__(self, v_num, b_num, p_num, row_dis, column_dis, workstations_pro_time):
        global agv_num, tables_num, product_num, row_distance, column_distance, workstations_processing_time
        global total_product, time_start
        agv_num = int(v_num)
        product_num = int(b_num)
        tables_num = int(p_num)
        row_distance = row_dis
        column_distance = int(column_dis)
        workstations_processing_time = workstations_pro_time
        total_product = product_num
        time_start = datetime.datetime.now()

    def init_data(self):
        global ROW_COUNT, COLUMN_COUNT
        global agv_data_series
        global loading, res, products_map, products_info, finish_products
        global interval, total_product, res_before

        interval = 0
        agv_data_series = dict()
        COLUMN_COUNT = sum(row_distance) + 1
        ROW_COUNT = (column_distance - 1) * 2 + 3
        # 工作台位置
        loading = [0]
        for i, ele in enumerate(row_distance):
            loading.append(loading[-1] + ele)
        # 对地图进行建模
        res = np.zeros((ROW_COUNT, loading[-1] + 1))
        res_before = res
        products_map = np.zeros(loading[-1] + 1)
        products_info = dict()
        finish_products = []

        # 初始化任务
        init_all_agv_data()

        while len(finish_products) < product_num:
            update_data()
        if len(finish_products) == product_num:
            time_uses = (datetime.datetime.now() - time_start).microseconds / 1000
            return finish_interval, time_uses


def update_last_agv():
    """
    防止最后一个agv占用位置不离开的场景
    :return:
    """
    last_station_agv = None
    for i, value in agv_data_series.items():
        if (value.agv["x"] == 0 and value.agv["y"] == loading[-1]) and value.agv["plan"] is None:
            last_station_agv = i
    if last_station_agv is not None:
        have_product_and_no_agv_stations = list()
        for key, value in products_info.items():
            if value and key in loading:
                empty = True
                for i, item in agv_data_series.items():
                    if item.agv["plan"] is not None:
                        if loading[item.agv["plan"] - 1] == key:
                            empty = False
                    else:
                        if item.agv["y"] == key:
                            empty = False
                if empty and key != loading[-1]:
                    have_product_and_no_agv_stations.append(key)
        have_product_and_no_agv_stations = sorted(have_product_and_no_agv_stations)

        if have_product_and_no_agv_stations:
            index_next = loading.index(have_product_and_no_agv_stations[-1]) + 1
            agv_data_series[last_station_agv].agv["plan"] = index_next
            agv_data_series[last_station_agv].agv["finished"] = False
            agv_data_series[last_station_agv].agv["product"] = 1


def retrieve_agv():
    """
    当场上agv数量多于产品时，回收agv
    :return:
    """
    if product_num - len(finish_products) < len(agv_data_series):
        for item, value in agv_data_series.items():
            if value.agv["y"] == loading[-1] and value.agv["x"] != column_distance and (
                    value.agv["have_product"] is False) and (value.agv["finished"] is True) and value.agv[
                "plan"] is None:
                res[value.agv["x"], value.agv["y"]] = 0
                value.agv["x"] = 0
                value.agv["y"] = 0


def update_data():
    """
    主函数体
    :return:
    """
    global interval
    # print("=products_info=========", products_info)
    if len(finish_products) < product_num:
        # 产生第一个加工台的产品
        Products().init_first_workstations()
        # 回收多余的agv
        retrieve_agv()
        # agv分配方案确定
        update_agv_plan()
        # 防止最后一个agv占据位置，对其进行分配
        update_last_agv()

        for item, data in agv_data_series.items():
            data.agv_finished()
            if data.agv["plan"] is not None and data.agv["plan"] != 0:
                data.agv_arrived()
            if data.agv["finished"] is not True:
                data.get_agv_next()
                data.agv_update()
                data.agv_finished()
                data.agv_arrived()

        Products().update_products()
        Products().get_finish_products()
        Products().init_first_workstations()

        interval += 1
    if len(finish_products) == product_num:
        global finish_interval
        finish_interval = interval


def get_data(plan, i, j, road):
    i = int(i)
    j = int(j)
    road.append(str(i) + "_" + str(j))
    if plan[i, j] != "":
        plan_tmp = plan[i, j]
        plan_tmp_split = plan_tmp.split("_")
        i = plan_tmp_split[0]
        j = plan_tmp_split[1]
        return get_data(plan, i, j, road)
    return road


# o_finish_interval, o_time_uses = Update(4, 8, 8, [1, 2, 4, 2, 3, 4, 5], 1, [2, 15, 1, 13, 8, 5, 3, 12]).init_data()
# print(o_finish_interval, o_time_uses)
