# -*- coding: utf-8 -*-
"""
Created on Tue Jun 24 14:10:17 2025

@author: DELL
"""
# import math 
# from objects import Node
import timeSceduling as ts
WG = None
PG = None
VG = None
SG = None
DG = None
HG = None

def setGlobalParam(w,p,v,s,d,h):
    global WG,PG,VG,DG,SG,HG
    WG,PG,VG,DG,SG,HG = w,p,v,d,s,h
    
def ini_sol():
    global WG,PG,VG,DG,SG,HG
    w,p,v = WG,PG,VG
    x = {}
    A = [(0,k) for k in range(1, v+1)]
    E = [(0,0)]
    D = [(i,j) for i in range(1,w) for j in range(1,p+1)]
    x_d = [(i,j,m,n) for (i,j) in D + A for (m,n) in D + E]
    seqs = [[(0, k)] for k in range(1, v+1)]
    for j in range(p):
        agv = j%v
        seq = seqs[agv]
        for i in range(1, w):
            node = (i, j+1)
            seq.append(node)
    # if len(seqs) == 1:
    #     seqs.append([(0,2)])
    for seq in seqs:
        seq.append((0,0))
        for i in range(1, len(seq)):
            node = seq[i]
            last_node = seq[i-1]
            key = (*last_node, *node)
            x[key] = 1
    for key in x_d:
        if key not in x:
            x[key] = 0
    return x, seqs
            
if __name__ == "__main__":
    v=1
    p=10
    w=7
    s= [2,3,3,5,3,6,2]
    d= [2,2,2,2,2,2]
    h= 1
    setGlobalParam(w,p,v,s,d,h)
    ts.setGlobalParam(w, p, v, s, d, h)
    x, seqs = ini_sol()
    res = ts.timeScheduling(x)