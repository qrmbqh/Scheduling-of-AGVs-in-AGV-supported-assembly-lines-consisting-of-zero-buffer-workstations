# -*- coding: utf-8 -*-
"""
Created on Wed Jul  2 15:35:14 2025

@author: DELL
"""
import CBSWithoutStatus as H
import timeSceduling as ts
import random
from collections import defaultdict
import time
WG = None
PG = None
VG = None
SG = None
DG = None
HG = None

def setGlobalParam(w,p,v,s,d,h):
    global WG,PG,VG,DG,SG,HG
    WG,PG,VG,DG,SG,HG = w,p,v,d,s,h
    ts.setGlobalParam(w, p, v, s, d, h)
    
def relaxed_problem():
    """
    D: list of tasks (i,j)
    v: number of AGVs
    s: list of processing times per workstation, index 1-based
    t: dict t[i1][i2] = travel time between station i1 and i2
    Returns:
        task_schedule: {(i,j): {'agv': x, 'start': b, 'end': c}}
    """
    global WG,PG,VG,DG,SG,HG
    w, p, v, d, s, h = WG,PG,VG,DG,SG,HG
    T_d = [(i,j) for i in range(1,w+1) for j in range(1,w+1)]
    D = [(i,j) for i in range(1,w) for j in range(1,p+1)]
    t = {}
    for i,j in T_d:
        if i <= j:
            t[i,j] = sum(d[i-1:j-1])
        else:
            t[i,j] = sum(d[j-1:i-1])+2*h
    # Build precedence graph
    pred = defaultdict(list)
    for i, j in D:
        if (i - 1, j) in D:
            pred[(i, j)].append((i - 1, j))
        if (i, j - 1) in D:
            pred[(i, j)].append((i, j - 1))

    # Topological sort (BFS)
    in_deg = defaultdict(int)
    for u in D:
        for v_ in pred[u]:
            in_deg[u] += 1

    ready = [u for u in D if in_deg[u] == 0]
    topo_order = []
    while ready:
        u = ready.pop()
        topo_order.append(u)
        for v_ in D:
            if u in pred[v_]:
                in_deg[v_] -= 1
                if in_deg[v_] == 0:
                    ready.append(v_)

    # Initialize AGV state
    agv_pos = {k: 0 for k in range(1, v + 1)}  # depot position
    agv_time = {k: 0 for k in range(1, v + 1)}

    # Schedule
    task_schedule = {}
    for i, j in topo_order:
        min_end_time = float('inf')
        best_agv = None
        best_start = None
        best_end = None
        for agv in range(1, v + 1):
            # 前驱完成时间
            preds = pred[(i, j)]
            pred_times = [0]
            for pre_task in preds:
                pi,pj = pre_task
                if pi == i:
                    pred_times.append(task_schedule[pre_task]['start'])
                else:
                    pred_times.append(task_schedule[pre_task]['end'])
            # pred_end = max([task_schedule[p_]['end'] for p_ in preds] or [0])
            pred_end = max(pred_times)
            travel = t[agv_pos[agv], i] if (agv_pos[agv],i) in t.keys() else 0
            arrive_time = agv_time[agv] + travel
            # _t = t[i,i+1] if i > 1 else 0
            start_time = max(arrive_time, pred_end+s[i-1])
            end_time = start_time + t[i,i+1]
            if end_time < min_end_time:
                min_end_time = end_time
                best_agv = agv
                best_start = start_time
                best_end = end_time

        task_schedule[(i, j)] = {
            'agv': best_agv,
            'start': best_start,
            'end': best_end
        }
        agv_time[best_agv] = task_schedule[(i, j)]['end']
        agv_pos[best_agv] = i
    
    seqs=[[(0,k)] for k in range(1,v+1)]
    b = {}
    c = {}
    for task in task_schedule:
        agv, c_, b_ = task_schedule[task]['agv'], task_schedule[task]['start'],task_schedule[task]['end']
        seqs[agv-1].append(task)
        c[task], b[task] = c_, b_
    obj = task_schedule[(w-1,p)]['end']+s[w-1]
    return obj, seqs, b, c


def new_relaxed_problem():
    """
    D: list of tasks (i,j)
    v: number of AGVs
    s: list of processing times per workstation, index 1-based
    t: dict t[i1,i2] = travel time between station i1 and i2
    Returns:
        obj, seqs, b, c
    """
    global WG,PG,VG,DG,SG,HG
    w, p, v, d, s, h = WG,PG,VG,DG,SG,HG

    T_d = [(i, j) for i in range(1, w + 1) for j in range(1, w + 1)]
    D = [(i, j) for i in range(1, w) for j in range(1, p + 1)]

    # travel time
    t = {}
    for i, j in T_d:
        if i <= j:
            t[i, j] = sum(d[i - 1:j - 1])
        else:
            t[i, j] = sum(d[j - 1:i - 1]) + 2 * h

    # Build precedence graph
    pred = defaultdict(list)
    for i, j in D:
        if (i - 1, j) in D:
            pred[(i, j)].append((i - 1, j))
        if (i, j - 1) in D:
            pred[(i, j)].append((i, j - 1))

    # Topological sort (BFS-like)
    in_deg = defaultdict(int)
    for u in D:
        in_deg[u] = len(pred[u])

    ready = [u for u in D if in_deg[u] == 0]
    topo_order = []
    succ = defaultdict(list)
    for u in D:
        for v_ in D:
            if u in pred[v_]:
                succ[u].append(v_)

    while ready:
        u = ready.pop()
        topo_order.append(u)
        for v_ in succ[u]:
            in_deg[v_] -= 1
            if in_deg[v_] == 0:
                ready.append(v_)

    # Initialize AGV state
    agv_pos = {k: 0 for k in range(1, v + 1)}   # depot position
    agv_time = {k: 0 for k in range(1, v + 1)}  # time when AGV k becomes free

    # NEW: track last task on each AGV (for the “direct successor” constraint)
    last_task = {k: None for k in range(1, v + 1)}  # None or (i_prev, j_prev)

    # Schedule
    task_schedule = {}
    for i, j in topo_order:
        min_end_time = float('inf')
        best_agv = None
        best_start = None
        best_end = None

        for agv in range(1, v + 1):
            # ===== NEW constraint check =====
            lt = last_task[agv]
            if lt is not None:
                i_prev, j_prev = lt
                # if same workstation i, then (i, j) cannot be a direct successor when j >= j_prev + 2
                if j_prev == j and i >= i_prev + 2:
                    continue
            # ================================

            # predecessor completion time (your original logic)
            preds = pred[(i, j)]
            pred_times = [0]
            for pre_task in preds:
                pi, pj = pre_task
                if pi == i:
                    pred_times.append(task_schedule[pre_task]['start'])
                else:
                    pred_times.append(task_schedule[pre_task]['end'])
            pred_end = max(pred_times)

            travel = t[agv_pos[agv], i] if (agv_pos[agv], i) in t else 0
            arrive_time = agv_time[agv] + travel

            start_time = max(arrive_time, pred_end + s[i - 1])
            end_time = start_time + t[i, i + 1]

            if end_time < min_end_time:
                min_end_time = end_time
                best_agv = agv
                best_start = start_time
                best_end = end_time

        if best_agv is None:
            raise RuntimeError(f"No feasible AGV assignment for task ({i},{j}) under the new direct-successor constraint.")

        task_schedule[(i, j)] = {'agv': best_agv, 'start': best_start, 'end': best_end}
        agv_time[best_agv] = best_end
        agv_pos[best_agv] = i
        last_task[best_agv] = (i, j)  # NEW: update last task

    seqs = [[(0, k)] for k in range(1, v + 1)]
    b = {}
    c = {}
    for task in task_schedule:
        agv = task_schedule[task]['agv']
        c_ = task_schedule[task]['start']
        b_ = task_schedule[task]['end']
        seqs[agv - 1].append(task)
        c[task], b[task] = c_, b_

    obj = task_schedule[(w - 1, p)]['end'] + s[w - 1]
    return obj, seqs, b, c

def repair(seqs):
    seqs = F.copy(seqs)
    x = ts.seqs2x(seqs)
    tag, obj, runtime,b,c = ts.timeScheduling(x)
    return tag, obj,b,c

def relax_and_repair():
    t1 = time.time()
    obj_relaxed, seqs, b_relaxed, c_relaxed = new_relaxed_problem()
    status, obj_repaired, b_repaired,c_repaired = repair(seqs)
    t2 = time.time()
    return obj_repaired, t2-t1

import functions as F
if __name__ == "__main__":
    v = 3
    p = 12
    w = 6
    s = [7,6,10,9,10,7,]  # 举例
    d = [9,10,10,10,14,]     # len == wcc-1
    # s = [random.randint(3, 10) for _ in range(w)]
    # d = [random.randint(2, 2) for _ in range(w-1)]
    h = 1
    setGlobalParam(w,p,v,s,d,h)
    ts.setGlobalParam(w, p, v, s, d, h)
    # m = H.CBS(w, p, v, s, d, h)
    # makespan,t= m.CBS_NL(3,3)
    obj,t = relax_and_repair()
    print(obj, t)
    # obj_relaxed, seqs, b_relaxed, c_relaxed = relaxed_problem()
    # F.plot_vehicle_routes(seqs, b=b_relaxed,c=c_relaxed,s=s)
    # status, obj_repaired, b_repaired,c_repaired = repair(seqs)
    # F.plot_vehicle_routes(seqs, b=b_repaired,c=c_repaired,s=s)
    # print(f'obj relaxed={obj_relaxed}, obj repair={obj_repaired}, my obj={makespan}')
    # for k in sorted(sched.keys()):
    #     print(f"Task {k} assigned to AGV {sched[k]['agv']} | Start: {sched[k]['start']}, End: {sched[k]['end']}")
    
    # makespan = max(sched[k]['end'] for k in sched)
    # print(f"\nTotal makespan: {makespan}")
    
    
    # obj_relaxed, solution_relaxed, _ = ts.relaxed_problem_params(w, p, v, d, s, h)
    # obj_original,_ = ts.original_problem_params(w, p, v, d, s, h)
    # solution_repaired, vehicle_paths = repair_x_solution_fractional_to_integral(solution_relaxed, v, p, w)
    
    # print(f'relaxed obj = {obj_relaxed}, original obj = {obj_original}')