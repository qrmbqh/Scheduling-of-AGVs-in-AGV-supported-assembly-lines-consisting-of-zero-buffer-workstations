import unittest

import newCBSwithLNSdr_raw as raw


class _FakeProduct:
    def __init__(self):
        self.state = "wait"


class _BranchingStage:
    finished_times = []
    raw_find_calls = 0
    transform_calls = 0

    def __init__(self, *_args, finish_time=None, **_kwargs):
        self.PRODs = [_FakeProduct()]
        self.level = 1
        self.time = 0
        self.finish_time = finish_time

    def beginProcess(self):
        pass

    def updateWSsRTI(self):
        pass

    def updateAGVsRTS(self):
        pass

    def releaseLoadedAgvsRaw(self):
        pass

    def update(self):
        if self.finish_time is not None:
            self.time = self.finish_time
            self.PRODs[-1].state = "finish"
            self.finished_times.append(self.finish_time)

    def transform(self):
        _BranchingStage.transform_calls += 1
        raise AssertionError("raw CBS_NL must not call transform before assignment")

    def findAllSolutions(self):
        raise AssertionError("raw CBS_NL must use raw allocation")

    def findAllSolutions_raw(self):
        _BranchingStage.raw_find_calls += 1
        return [[("branch", 1)], [("branch", 2)]]

    def createBranches(self, _branches):
        fast = _BranchingStage(finish_time=5)
        slow = _BranchingStage(finish_time=10)
        fast.level = self.level + 1
        slow.level = self.level + 1
        return [fast, slow]


class RawStateAssignmentTests(unittest.TestCase):
    def setUp(self):
        def simple_allocate(agvs, workstations, _fixed, _dist, _rpt, _d):
            return [[(agv_id, ws_id) for agv_id, ws_id in zip(agvs, workstations)]]

        self.original_section_allocate = raw.SA.sectionAllocate
        self.original_section_allocate_repair = raw.SA.sectionAllocate_repair
        raw.SA.sectionAllocate = simple_allocate
        raw.SA.sectionAllocate_repair = simple_allocate
        self.addCleanup(self._restore_allocators)

    def _restore_allocators(self):
        raw.SA.sectionAllocate = self.original_section_allocate
        raw.SA.sectionAllocate_repair = self.original_section_allocate_repair

    def test_raw_solver_does_not_call_transform_before_assignment(self):
        stage = raw.STAGE(2, 4, 4, [1, 1, 1, 1], [1, 1, 1], 1)
        stage.beginProcess()

        def fail_transform(_stage):
            raise AssertionError("transform must not be called by raw solver")

        original_transform = raw.STAGE.transform
        raw.STAGE.transform = fail_transform
        self.addCleanup(lambda: setattr(raw.STAGE, "transform", original_transform))
        solver = raw.RawStateSegmentLNSMILP(4, 4, 2, [1, 1, 1, 1], [1, 1, 1], 1)

        result = solver._simulate_to_decision_init(stage)

        self.assertNotEqual("finish", result)

    def test_raw_assignments_use_only_free_agvs(self):
        stage = raw.STAGE(4, 5, 5, [1, 1, 1, 1, 1], [1, 1, 1, 1], 1)
        stage.beginProcess()
        stage.AGVs[1].setState("free", 0, 0, 0, stage.WSs[0], None, None)
        stage.AGVs[2].setState("waitLoad", 0, 0, 0, stage.WSs[1], stage.WSs[2], stage.WSs[1].prod)
        stage.AGVs[3].setState("halfFree", 0, 0, 1, stage.WSs[2], None, None)
        stage.WSs[1].setState(raw.PRODUCT(99), 1, "busyNoAgv")
        stage.WSs[1].prod.setState("atWS", stage.WSs[1], None)
        stage.WSs[2].setState(raw.PRODUCT(100), 1, "busyNoAgv")
        stage.WSs[2].prod.setState("atWS", stage.WSs[2], None)

        branches = stage._findAllSolutions_raw(filter_deadlock=False)
        used_agvs = {agv_id for branch in branches for section in branch for agv_id, _ in section}

        self.assertEqual({2}, used_agvs)

    def test_raw_assignment_does_not_enable_unenable_agvs(self):
        stage = raw.STAGE(3, 4, 4, [1, 1, 1, 1], [1, 1, 1], 1)
        stage.beginProcess()
        stage.AGVs[1].setState("free", 0, 0, 0, stage.WSs[0], None, None)
        before = stage.unenableAgvNum

        stage.findAllSolutions_raw()

        self.assertEqual(before, stage.unenableAgvNum)
        self.assertEqual("unenable", stage.AGVs[2].state)

    def test_raw_lns_finishes_small_instance(self):
        solver = raw.RawStateSegmentLNSMILP(
            4,
            4,
            2,
            [1, 1, 1, 1],
            [1, 1, 1],
            1,
            Imax=1,
            seed=0,
        )

        makespan, trace, elapsed = solver.run()

        self.assertGreater(makespan, 0)
        self.assertIsInstance(trace, list)
        self.assertGreaterEqual(elapsed, 0)

    def test_raw_cbs_nl_evaluates_limited_branches_before_returning_best(self):
        original_stage = raw.STAGE
        _BranchingStage.finished_times = []
        _BranchingStage.raw_find_calls = 0
        _BranchingStage.transform_calls = 0
        raw.STAGE = _BranchingStage
        self.addCleanup(lambda: setattr(raw, "STAGE", original_stage))
        solver = raw.CBS(0, 0, 0, [], [], 0)

        makespan, _elapsed = solver.CBS_NL(3, 3)

        self.assertEqual(5, makespan)
        self.assertEqual([10, 5], _BranchingStage.finished_times)
        self.assertGreater(_BranchingStage.raw_find_calls, 0)
        self.assertEqual(0, _BranchingStage.transform_calls)


if __name__ == "__main__":
    unittest.main()
