# -*- coding: utf-8 -*-
"""
对比测试: RawCBS_NL(no transform) vs IdleCBS_NL(3,3) vs CBS_NL(3,3)

算例生成方式与 小规模数据重算.py 保持一致：
  - 参数网格: WP × V × D × S, 每个组合生成 count 个算例
  - 使用 randomGenerator.random_nums() 生成 s 和 d

用法:
    python test_comparison_raw_vs_cbs.py
"""

import csv
import os
import sys
import time
import traceback
import importlib.util
import multiprocessing
from datetime import datetime

# 与 小规模数据重算.py 相同的依赖
import randomGenerator as RG
import s2str

# ===================================================================
#  使用 importlib 分别加载两个模块到独立命名空间，避免 STAGE 类冲突
# ===================================================================
_this_dir = os.path.dirname(os.path.abspath(__file__))

def _load_module(module_name, filename):
    """从文件路径加载模块到独立命名空间。"""
    filepath = os.path.join(_this_dir, filename)
    spec = importlib.util.spec_from_file_location(module_name, filepath)
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module

# 加载 raw 版本 (CBS_NL 决策前不做 transform)
raw_mod = _load_module("raw_module", "newCBSwithLNSdr_raw.py")

# 加载非 raw 版本 (含 CBS)
dr_mod = _load_module("dr_module", "newCBSwithLNSdr.py")

# 加载保留 transform、只分配 idle/free AGV 的 CBS_NL 版本
idle_transform_mod = _load_module(
    "idle_transform_module", "newCBSwithLNSdr_idle_transform.py"
)


# ===================================================================
#                          求解器调用
# ===================================================================
def _timeout_worker(result_queue, func, args, kwargs):
    try:
        result_queue.put(("ok", func(*args, **kwargs)))
    except Exception as e:
        result_queue.put(("error", f"{type(e).__name__}: {e}"))


def _run_with_timeout(func, timeout, *args, **kwargs):
    """在独立进程中执行 func，超时后终止该进程。"""
    ctx = multiprocessing.get_context("spawn")
    result_queue = ctx.Queue(maxsize=1)
    process = ctx.Process(
        target=_timeout_worker,
        args=(result_queue, func, args, kwargs),
    )
    process.start()
    process.join(timeout)
    if process.is_alive():
        process.terminate()
        process.join(1)
        if process.is_alive():
            process.kill()
            process.join()
        return dict(makespan=None, elapsed=None,
                    status=f"timeout ({timeout}s)", trace_len=None)

    if result_queue.empty():
        return dict(makespan=None, elapsed=None,
                    status=f"error: worker exited with code {process.exitcode}",
                    trace_len=None)

    status, payload = result_queue.get()
    if status == "ok":
        return payload
    return dict(makespan=None, elapsed=None,
                status=f"error: {payload}", trace_len=None)


def _solve_raw_lns_impl(w, p, v, s, d, h, n, l):
    """Raw CBS_NL 的实际调用：决策前不做 transform。"""
    solver = raw_mod.CBS(w=w, p=p, v=v, s=s, d=d, h=h)
    t0 = time.perf_counter()
    makespan, _elapsed = solver.CBS_NL(n, l)
    t1 = time.perf_counter()
    return dict(makespan=makespan, elapsed=t1 - t0, status="ok", trace_len=None)


def solve_raw_lns(inst, n=3, l=3, timeout=120):
    """
    调用 raw CBS_NL(n, l) 求解（带超时保护）。
    返回 dict : {makespan, elapsed, status, trace_len}
    """
    try:
        return _run_with_timeout(
            _solve_raw_lns_impl, timeout,
            inst["w"], inst["p"], inst["v"], inst["s"], inst["d"], inst["h"],
            n, l,
        )
    except Exception as e:
        return dict(makespan=None, elapsed=None,
                    status=f"error: {e}", trace_len=None)


def _solve_cbs_nl_impl(w, p, v, s, d, h, n, l):
    """CBS_NL 的实际调用（在线程中执行）。"""
    cbs = dr_mod.CBS(w=w, p=p, v=v, s=s, d=d, h=h)
    t0 = time.perf_counter()
    makespan, elapsed = cbs.CBS_NL(n, l)
    t1 = time.perf_counter()
    return dict(makespan=makespan, elapsed=t1 - t0, status="ok", trace_len=None)


def solve_cbs_nl(inst, n=3, l=3, timeout=120):
    """
    调用 CBS_NL(n, l) 求解（带超时保护）。
    返回 dict : {makespan, elapsed, status}
    """
    try:
        return _run_with_timeout(
            _solve_cbs_nl_impl, timeout,
            inst["w"], inst["p"], inst["v"], inst["s"], inst["d"], inst["h"],
            n, l,
        )
    except Exception as e:
        return dict(makespan=None, elapsed=None,
                    status=f"error: {e}", trace_len=None)


def _solve_idle_transform_cbs_nl_impl(w, p, v, s, d, h, n, l):
    """新 CBS_NL 的实际调用：保留 transform，但只分配当前 free AGV。"""
    cbs = idle_transform_mod.CBS(w=w, p=p, v=v, s=s, d=d, h=h)
    t0 = time.perf_counter()
    makespan, elapsed = cbs.CBS_NL(n, l)
    t1 = time.perf_counter()
    return dict(makespan=makespan, elapsed=t1 - t0, status="ok", trace_len=None)


def solve_idle_transform_cbs_nl(inst, n=3, l=3, timeout=120):
    """
    调用新 CBS_NL(n, l) 求解（带超时保护）。
    返回 dict : {makespan, elapsed, status}
    """
    try:
        return _run_with_timeout(
            _solve_idle_transform_cbs_nl_impl, timeout,
            inst["w"], inst["p"], inst["v"], inst["s"], inst["d"], inst["h"],
            n, l,
        )
    except Exception as e:
        return dict(makespan=None, elapsed=None,
                    status=f"error: {e}", trace_len=None)


# ===================================================================
#                          主测试流程
# ===================================================================
def run_comparison_grid(WP, V, D, S, h, count,
                        raw_kwargs=None,
                        cbs_kwargs=None,
                        idle_transform_kwargs=None,
                        output_csv=None,
                        verbose=True):
    """
    使用与 小规模数据重算.py 相同的参数网格方式遍历所有组合并求解。

    参数
    ----------
    WP : list[tuple]
        (w, p) 工位-产品数对，例如 [(6,7), (7,8), ...]
    V : list[int]
        AGV 数量列表。
    D : list[tuple]
        工位间距范围 (low_d, up_d) 列表。
    S : list[tuple]
        加工时间范围 (low_s, up_s) 列表。
    h : float
        横向道路距离。
    count : int
        每个 (w,p,v,s_range,d_range) 组合下生成的算例数。
    raw_kwargs : dict
        传给 raw CBS_NL 的参数。
    cbs_kwargs : dict
        传给 CBS_NL 的参数。
    output_csv : str
        输出 CSV 路径，默认自动生成带日期的文件名。
    verbose : bool
        是否打印进度。

    返回
    -------
    rows : list[dict]
    output_csv : str
    """
    if cbs_kwargs is None:
        cbs_kwargs = dict(n=3, l=3)
    if raw_kwargs is None:
        raw_kwargs = dict(cbs_kwargs)
    if idle_transform_kwargs is None:
        idle_transform_kwargs = dict(cbs_kwargs)

    if output_csv is None:
        date_str = datetime.now().strftime('%Y-%m-%d')
        output_csv = os.path.join(_this_dir, f"comparison_raw_vs_cbs_{date_str}.csv")

    # CSV 列名（对齐 小规模数据重算.py 的风格，再补充 RawCBS 和对比列）
    header = [
        "v", "p", "w", "taskcount",
        "low_s", "up_s", "S",
        "low_d", "up_d", "D",
        "h",
        "obj_cbs", "t_cbs",
        "obj_idle_transform_cbs", "t_idle_transform_cbs",
        "obj_raw_lns", "t_raw_lns", "raw_trace_len",
        "gap_pct",
    ]

    f = open(output_csv, "a", newline="", encoding="utf-8-sig")
    writer = csv.writer(f)
    writer.writerow(header)
    f.close()

    rows = []

    # 计算总组合数用于进度显示
    total_combos = len(WP) * len(V) * len(D) * len(S)
    combo_idx = 0

    for w, p in WP:
        for v in V:
            for l_d, u_d in D:
                for l_s, u_s in S:
                    combo_idx += 1
                    for _ in range(count):
                        # ---- 生成算例 (与 小规模数据重算.py 完全一致) ----
                        s = RG.random_nums(w, l_s, u_s)
                        d = RG.random_nums(w - 1, l_d, u_d)

                        inst = dict(w=w, p=p, v=v, h=h, s=s, d=d,
                                    l_s=l_s, u_s=u_s, l_d=l_d, u_d=u_d)

                        if verbose:
                            print(f"[组合{combo_idx}/{total_combos}] "
                                  f"w={w}, p={p}, v={v}, "
                                  f"s~({l_s},{u_s}), d~({l_d},{u_d}) ... ",
                                  end="", flush=True)

                        # ---- 带重试的求解 (对齐 小规模数据重算.py 的 try/except) ----
                        try:
                            cbs_result = solve_cbs_nl(inst, **cbs_kwargs)
                            idle_transform_result = solve_idle_transform_cbs_nl(
                                inst, **idle_transform_kwargs
                            )
                            raw_result = solve_raw_lns(inst, **raw_kwargs)
                        except Exception:
                            # 异常时重新生成一组随机数再试一次
                            s = RG.random_nums(w, l_s, u_s)
                            d = RG.random_nums(w - 1, l_d, u_d)
                            inst["s"], inst["d"] = s, d
                            try:
                                cbs_result = solve_cbs_nl(inst, **cbs_kwargs)
                                idle_transform_result = solve_idle_transform_cbs_nl(
                                    inst, **idle_transform_kwargs
                                )
                                raw_result = solve_raw_lns(inst, **raw_kwargs)
                            except Exception:
                                cbs_result = dict(makespan=None, elapsed=None,
                                                  status="error (retry failed)")
                                idle_transform_result = dict(
                                    makespan=None, elapsed=None,
                                    status="error (retry failed)"
                                )
                                raw_result = dict(makespan=None, elapsed=None,
                                                  status="error (retry failed)")

                        # ---- 计算 gap ----
                        gap_pct = None
                        if (raw_result.get("makespan") is not None
                                and cbs_result.get("makespan") is not None
                                and cbs_result["makespan"] != 0):
                            gap_pct = round(
                                (raw_result["makespan"] - cbs_result["makespan"])
                                / cbs_result["makespan"] * 100, 2
                            )

                        # ---- 写入 CSV ----
                        f = open(output_csv, "a", newline="", encoding="utf-8-sig")
                        writer = csv.writer(f)
                        writer.writerow([
                            v, p, w, p * w,
                            l_s, u_s, s2str.list2str(s),
                            l_d, u_d, s2str.list2str(d),
                            h,
                            cbs_result.get("makespan"),
                            round(cbs_result.get("elapsed"), 4) if cbs_result.get("elapsed") is not None else None,
                            idle_transform_result.get("makespan"),
                            round(idle_transform_result.get("elapsed"), 4) if idle_transform_result.get("elapsed") is not None else None,
                            raw_result.get("makespan"),
                            round(raw_result.get("elapsed"), 4) if raw_result.get("elapsed") is not None else None,
                            raw_result.get("trace_len"),
                            gap_pct,
                        ])
                        f.close()

                        row = {
                            "w": w, "p": p, "v": v, "h": h,
                            "l_s": l_s, "u_s": u_s, "l_d": l_d, "u_d": u_d,
                            "s": s, "d": d,
                            "cbs_makespan": cbs_result.get("makespan"),
                            "cbs_elapsed": cbs_result.get("elapsed"),
                            "cbs_status": cbs_result.get("status"),
                            "idle_transform_makespan": idle_transform_result.get("makespan"),
                            "idle_transform_elapsed": idle_transform_result.get("elapsed"),
                            "idle_transform_status": idle_transform_result.get("status"),
                            "raw_makespan": raw_result.get("makespan"),
                            "raw_elapsed": raw_result.get("elapsed"),
                            "raw_status": raw_result.get("status"),
                            "raw_trace_len": raw_result.get("trace_len"),
                            "gap_pct": gap_pct,
                        }
                        rows.append(row)

                        if verbose:
                            cbs_str = f"CBS={cbs_result.get('makespan')}" if cbs_result.get("makespan") is not None else "CBS=FAIL"
                            idle_transform_str = (
                                f"IdleCBS={idle_transform_result.get('makespan')}"
                                if idle_transform_result.get("makespan") is not None
                                else "IdleCBS=FAIL"
                            )
                            raw_str = f"Raw={raw_result.get('makespan')}" if raw_result.get("makespan") is not None else "Raw=FAIL"
                            gap_str = f"gap={gap_pct}%" if gap_pct is not None else ""
                            cbs_t = cbs_result.get("elapsed")
                            idle_transform_t = idle_transform_result.get("elapsed")
                            raw_t = raw_result.get("elapsed")
                            if cbs_t is not None and idle_transform_t is not None and raw_t is not None:
                                t_str = f"[{cbs_t:.1f}s / {idle_transform_t:.1f}s / {raw_t:.1f}s]"
                            else:
                                t_str = "[N/A]"
                            print(f"{cbs_str}, {idle_transform_str}, {raw_str}, {gap_str} {t_str}")
                            # 失败时打印详细错误（只打印第一个失败的，避免刷屏）
                            if cbs_result.get("makespan") is None:
                                print(f"  [CBS error] {cbs_result.get('status')}")
                            if idle_transform_result.get("makespan") is None:
                                print(f"  [IdleCBS error] {idle_transform_result.get('status')}")
                            if raw_result.get("makespan") is None:
                                print(f"  [Raw error] {raw_result.get('status')}")

    return rows, output_csv


def print_summary(rows):
    """打印汇总统计。"""
    both_ok = [r for r in rows
               if r.get("cbs_makespan") is not None
               and r.get("raw_makespan") is not None]
    all_ok = [r for r in rows
              if r.get("cbs_makespan") is not None
              and r.get("idle_transform_makespan") is not None
              and r.get("raw_makespan") is not None]
    cbs_timeout = sum(1 for r in rows if r.get("cbs_status") and "timeout" in str(r["cbs_status"]))
    idle_transform_timeout = sum(1 for r in rows if r.get("idle_transform_status") and "timeout" in str(r["idle_transform_status"]))
    raw_timeout = sum(1 for r in rows if r.get("raw_status") and "timeout" in str(r["raw_status"]))
    cbs_error = sum(1 for r in rows if r.get("cbs_status") and r["cbs_status"] != "ok" and "timeout" not in str(r["cbs_status"]))
    idle_transform_error = sum(1 for r in rows if r.get("idle_transform_status") and r["idle_transform_status"] != "ok" and "timeout" not in str(r["idle_transform_status"]))
    raw_error = sum(1 for r in rows if r.get("raw_status") and r["raw_status"] != "ok" and "timeout" not in str(r["raw_status"]))

    print()
    print("=" * 70)
    print("                    汇总统计")
    print("=" * 70)
    print(f"  总算例数:           {len(rows)}")
    print(f"  二者均成功:         {len(both_ok)}")
    print(f"  三者均成功:         {len(all_ok)}")
    print(f"  CBS 超时:           {cbs_timeout}")
    print(f"  IdleCBS 超时:       {idle_transform_timeout}")
    print(f"  Raw 超时:           {raw_timeout}")
    if cbs_error:
        print(f"  CBS 其他错误:       {cbs_error}")
    if idle_transform_error:
        print(f"  IdleCBS 其他错误:   {idle_transform_error}")
    if raw_error:
        print(f"  Raw 其他错误:       {raw_error}")
    print()

    if all_ok:
        raw_ms = [r["raw_makespan"] for r in all_ok]
        idle_transform_ms = [r["idle_transform_makespan"] for r in all_ok]
        cbs_ms = [r["cbs_makespan"] for r in all_ok]
        raw_times = [r["raw_elapsed"] for r in all_ok if r["raw_elapsed"] is not None]
        idle_transform_times = [r["idle_transform_elapsed"] for r in all_ok if r["idle_transform_elapsed"] is not None]
        cbs_times = [r["cbs_elapsed"] for r in all_ok if r["cbs_elapsed"] is not None]
        gaps = [r["gap_pct"] for r in all_ok]

        print(f"  {'指标':<25} {'RawCBS_NL':<18} {'IdleCBS_NL':<18} {'CBS_NL(3,3)':<18}")
        print("  " + "-" * 79)
        print(f"  {'makespan 均值':<25} {sum(raw_ms)/len(raw_ms):<18.2f} {sum(idle_transform_ms)/len(idle_transform_ms):<18.2f} {sum(cbs_ms)/len(cbs_ms):<18.2f}")
        print(f"  {'makespan 最小值':<25} {min(raw_ms):<18} {min(idle_transform_ms):<18} {min(cbs_ms):<18}")
        print(f"  {'makespan 最大值':<25} {max(raw_ms):<18} {max(idle_transform_ms):<18} {max(cbs_ms):<18}")
        if raw_times and idle_transform_times and cbs_times:
            print(f"  {'耗时均值 (s)':<25} {sum(raw_times)/len(raw_times):<18.4f} {sum(idle_transform_times)/len(idle_transform_times):<18.4f} {sum(cbs_times)/len(cbs_times):<18.4f}")
            print(f"  {'耗时总和 (s)':<25} {sum(raw_times):<18.4f} {sum(idle_transform_times):<18.4f} {sum(cbs_times):<18.4f}")
        print(f"  {'gap% 均值':<25} {sum(gaps)/len(gaps):<18.2f}")
        print(f"  {'gap% 最小值':<25} {min(gaps):<18}")
        print(f"  {'gap% 最大值':<25} {max(gaps):<18}")
        print()

        # 胜负统计
        raw_wins = sum(1 for g in gaps if g < 0)
        cbs_wins = sum(1 for g in gaps if g > 0)
        ties = sum(1 for g in gaps if g == 0)
        print(f"  胜负统计 (基于 makespan):")
        print(f"    RawCBS_NL 更优:  {raw_wins} 次 ({raw_wins/len(gaps)*100:.1f}%)")
        print(f"    CBS_NL  更优:  {cbs_wins} 次 ({cbs_wins/len(gaps)*100:.1f}%)")
        print(f"    平局:          {ties} 次 ({ties/len(gaps)*100:.1f}%)")
        print()
        avg_gap = sum(gaps) / len(gaps)
        print(f"  平均 gap (Raw - CBS)/CBS = {avg_gap:.2f}%")
        if avg_gap < 0:
            print(f"  -> RawCBS_NL 平均比 CBS_NL 好 {abs(avg_gap):.2f}%")
        elif avg_gap > 0:
            print(f"  -> CBS_NL 平均比 RawCBS_NL 好 {avg_gap:.2f}%")
    print("=" * 70)


# ===================================================================
#                          Main
# ===================================================================
if __name__ == "__main__":
    # ======================== 参数网格 (与 小规模数据重算.py 一致) ========================
    WP = [(6,7),(7,8),(8,9),(9,10)]     # (w, p) 工位-产品对
    V = [3,4,5]                                # AGV 数量
    D = [(2, 5)]                                 # 工位间距范围 (low_d, up_d)
    S = [(5,10),(10,15),(15,20),(20,25)]  # 加工时间范围 (low_s, up_s)
    h = 1                                        # 横向道路距离

    # 每个 (w,p,v,s_range,d_range) 组合下的算例数
    #  总组合数 = len(WP)*len(V)*len(D)*len(S) = 4*3*1*4 = 48
    #  总算例数 = 48 * count
    #  count=1  ->  48 例 (快速验证)
    #  count=5  -> 240 例 (适中)
    #  count=20 -> 960 例 (完整测试, 耗时长)
    count = 20

    # ======================== 求解器参数 ========================
    raw_kwargs = dict(
        n=3, l=3,
        timeout=3600,
    )

    # CBS_NL — 注意：CBS_NL(3,3) 在大加工时间/大算例上可能极慢
    cbs_kwargs = dict(
        n=3, l=3,
        timeout=3600,  # 单个算例超时 (秒)，CBS_NL 搜索空间大，给更长时限
    )

    idle_transform_kwargs = dict(
        n=3, l=3,
        timeout=3600,
    )

    # ======================== 输出文件 ========================
    date_str = datetime.now().strftime('%Y-%m-%d')
    output_csv = os.path.join(_this_dir, f"comparison_raw_vs_cbs_{date_str}.csv")

    # ======================== 运行 ========================
    print("=" * 70)
    print("     RawCBS_NL(no transform) vs IdleCBS_NL(3,3) vs CBS_NL(3,3) 对比测试")
    print("=" * 70)
    print(f"参数网格:")
    print(f"  WP (w,p) = {WP}")
    print(f"  V        = {V}")
    print(f"  S 范围   = {S}")
    print(f"  D 范围   = {D}")
    print(f"  h        = {h}")
    print(f"  count    = {count}")
    total_instances = len(WP) * len(V) * len(D) * len(S) * count
    print(f"  总组合数 = {len(WP)}*{len(V)}*{len(D)}*{len(S)} = {len(WP)*len(V)*len(D)*len(S)}")
    print(f"  总算例数 = {len(WP)*len(V)*len(D)*len(S)} * {count} = {total_instances}")
    print(f"RawCBS_NL: n={raw_kwargs['n']}, l={raw_kwargs['l']}, timeout={raw_kwargs['timeout']}s")
    print(f"IdleCBS_NL: n={idle_transform_kwargs['n']}, l={idle_transform_kwargs['l']}, timeout={idle_transform_kwargs['timeout']}s")
    print(f"CBS_NL:  n={cbs_kwargs['n']}, l={cbs_kwargs['l']}, timeout={cbs_kwargs['timeout']}s")
    print(f"输出:    {output_csv}")
    print()

    # 直接覆盖写入 CSV 头
    header = [
        "v", "p", "w", "taskcount",
        "low_s", "up_s", "S",
        "low_d", "up_d", "D",
        "h",
        "obj_cbs", "t_cbs",
        "obj_idle_transform_cbs", "t_idle_transform_cbs",
        "obj_raw_lns", "t_raw_lns", "raw_trace_len",
        "gap_pct",
    ]
    f = open(output_csv, "w", newline="", encoding="utf-8-sig")
    csv.writer(f).writerow(header)
    f.close()

    rows, out_path = run_comparison_grid(
        WP=WP, V=V, D=D, S=S, h=h, count=count,
        raw_kwargs=raw_kwargs,
        cbs_kwargs=cbs_kwargs,
        idle_transform_kwargs=idle_transform_kwargs,
        output_csv=output_csv,
        verbose=True,
    )

    # ======================== 汇总 ========================
    print_summary(rows)
    print(f"\n结果已保存到: {out_path}")
