# -*- coding: utf-8 -*-
"""
Created on Fri Sep 16 16:45:03 2022

@author: qrmbqh
"""

def list2str(f):
    num=len(f)
    m=''  #建立空字符串
    for i in range(num):
        x=str(f[i])
        m=m+x+","   #利用字符串叠加的方法
    return m