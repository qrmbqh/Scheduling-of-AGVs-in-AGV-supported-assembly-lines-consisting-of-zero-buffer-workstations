# -*- coding: utf-8 -*-
"""
Created on Thu Jan 23 17:11:13 2025
runtime = 1267
runtime is about 1240 s.
@author: 74110
"""

import GurobiWithoutStatus as GS
#import CBSWithoutStatus as CBS
import newCBSwithLNSdr as CBS
import csv
import s2str
import randomGenerator as rg
from datetime import datetime
import time
t1 = time.time()
def Numerical_nl(vc, wcc, pc, low_d, up_d, h, low_s, up_s, count, fileName):    
    for i in range(count):
        
        s = rg.random_nums(wcc, low_s, up_s)
        d = rg.random_nums(wcc-1, low_d,up_d)
        
        best_obj, best_bound, optimal_gap, timeConsume = GS.newAGVSchedul(vc, pc, wcc, s, d, h, 3600)
    
        for l in range(1,11):
            for n in range(1,11):
                cbs = CBS.CBS(wcc, pc, vc, s, d, h)
                cbs_makespan, cbs_makespan_t = cbs.CBS_NL(n, l)
                
                # mcbs = CBS.MCBS(wcc, pc, vc, s, d, h)
                # mcbs_makespan, mcbs_makespan_t = mcbs.CBS_NL(n, l)
                  
                f = open(fileName,'a',newline='')
                writer = csv.writer(f)
                writer.writerow([ i,
                                  vc,
                                  pc,
                                  wcc,
                                  pc*wcc,
                                  low_s, up_s,
                                  s2str.list2str(s),
                                  low_d,up_d,
                                  s2str.list2str(d),
                                  h,
                                  n,
                                  l,
                                  cbs_makespan, (cbs_makespan-best_obj)/best_obj, cbs_makespan_t,
                                  # mcbs_makespan,(mcbs_makespan-best_obj)/best_obj, mcbs_makespan_t,
                                  best_obj,timeConsume
                                  ])
                f.close()
        print(i)
    return

W = 7
P = 8
H = 1
V = 3
low_d,up_d = 2,5
# D = [(2,2),(1,3)]
low_s, up_s = 10,15
# S = [(5,10),(10,20)]
count = 10
current_date = datetime.now().date()
date_str = current_date.strftime('%Y-%m-%d')
fileName = 'figure_alpha&beta_data56_'+date_str+'.csv'
f = open(fileName,'a',newline='')
writer = csv.writer(f)
writer.writerow([ 'i',
                  'vc',
                  'pc',
                  'wcc',
                  'taskcount',
                  'low_s', 'up_s',
                  'S',
                  'low_d','up_d',
                  'D',
                  'h',
                  'n',
                  'l',
                  'cbs_makespan', 'gap_opt', 'cbs_makespan_t',
                  # mcbs_makespan,(mcbs_makespan-best_obj)/best_obj, mcbs_makespan_t,
                  'best_obj','timeConsume'
                  ])
f.close()

Numerical_nl(V, W, P, low_d, up_d, H, low_s, up_s, count, fileName)
t2 = time.time()