# -*- coding: utf-8 -*-
"""
Created on Thu Jul 31 09:51:06 2025

@author: DELL
"""

import gurobipy as gp
from gurobipy import GRB
import numpy as np
import getSolomonInstances as IN

def GurobiVRPTW(c_num, v_capa, v_num, demand, service_time, time_window, distance):
    '''

    Parameters
    ----------
    c_num : int
        customers数量，包含depot在内.
    v_capa : TYPE
        DESCRIPTION.
    v_num : TYPE
        DESCRIPTION.
    demand : TYPE
        DESCRIPTION.
    service_time : TYPE
        DESCRIPTION.
    time_window : TYPE
        DESCRIPTION.
    distance : TYPE
        DESCRIPTION.

    Returns
    -------
    None.

    '''
    m = gp.Model("VRPTW_no_vehicle_index")
    nodes = list(range(c_num))
    x = m.addVars(nodes, nodes, vtype=GRB.BINARY, name="x")
    t = m.addVars(nodes, vtype=GRB.CONTINUOUS, name="t")
    q = m.addVars(nodes, vtype=GRB.CONTINUOUS, name="q")
    
    # 目标函数
    m.setObjective(gp.quicksum(distance[i][j] * x[i, j] for i in nodes for j in nodes if i != j),
                   GRB.MINIMIZE)
    
    # 约束
    for j in nodes[1:]:
        m.addConstr(gp.quicksum(x[i, j] for i in nodes if i != j) == 1, name = 'c1')
        
    for i in nodes[1:]:
        m.addConstr(gp.quicksum(x[i, j] for j in nodes if j != i) == 1, name = 'c2')
    
    m.addConstr(gp.quicksum(x[0, j] for j in nodes if j != 0) <= v_num, name = 'c3')
    
    m.addConstr(gp.quicksum(x[i, 0] for i in nodes if i != 0) <= v_num, name = 'c4')
    
    M = 1e6
    for i in nodes[1:]:
        for j in nodes[1:]:
            if i != j:
                m.addConstr(t[i] + service_time[i] + distance[i][j] <= t[j] + M * (1 - x[i, j]), name = 'c5')
    
    for i in nodes:
        m.addConstr(t[i] >= time_window[i][0])
        m.addConstr(t[i] <= time_window[i][1])
    
    for i in nodes:
        for j in nodes:
            if i != j and i != 0 and j != 0:
                m.addConstr(q[j] >= q[i] + demand[j] - v_capa * (1 - x[i, j]))
    
    for i in nodes:
        m.addConstr(q[i] >= demand[i])
        m.addConstr(q[i] <= v_capa)
    
    # 求解
    # m.setParam("TimeLimit", 60)
    m.optimize()
    
    if m.status == GRB.OPTIMAL or m.status == GRB.TIME_LIMIT:
        for i in nodes:
            for j in nodes:
                if i != j and x[i, j].X > 0.5:
                    print(f"{i} -> {j}")

def feasibilityTest(solution, c_num, v_capa, v_num, demand, service_time, time_window, distance):
    customs = sorted(list(dict.fromkeys(x for sub in solution for x in sub)))
    x_given = {(i,j):0 for i in customs for j in customs}
    for route in solution:
        route_demand = sum(demand[_i] for _i in route if _i > 0)
        if route_demand > v_capa:
            return False
        i = 0
        for j in range(1, len(route)):
            x_given[route[i],route[j]] = 1
            i = j
    m = gp.Model("VRPTW_no_vehicle_index")
    # nodes = list(range(c_num))
    # x = m.addVars(nodes, nodes, vtype=GRB.BINARY, name="x")
    t = m.addVars(customs, vtype=GRB.CONTINUOUS, name="t")
    q = m.addVars(customs, vtype=GRB.CONTINUOUS, name="q")
    m.setParam(GRB.Param.OutputFlag, 0)
    # 目标函数
    m.setObjective(0, GRB.MINIMIZE)
    
    # 约束
    # for j in nodes[1:]:
    #     m.addConstr(gp.quicksum(x[i, j] for i in nodes if i != j) == 1, name = 'c1')
        
    # for i in nodes[1:]:
    #     m.addConstr(gp.quicksum(x[i, j] for j in nodes if j != i) == 1, name = 'c2')
    
    # m.addConstr(gp.quicksum(x[0, j] for j in nodes if j != 0) <= v_num, name = 'c3')
    
    # m.addConstr(gp.quicksum(x[i, 0] for i in nodes if i != 0) <= v_num, name = 'c4')
    
    M = 1e6
    for i in customs[1:]:
        for j in customs[1:]:
            if i != j:
                m.addConstr(t[i] + service_time[i] + distance[i][j] <= t[j] + M * (1 - x_given[i, j]), name = 'c5')
    
    for i in customs:
        m.addConstr(t[i] >= time_window[i][0])
        m.addConstr(t[i] <= time_window[i][1])
    
    # for i in nodes:
    #     for j in nodes:
    #         if i != j and i != 0 and j != 0:
    #             m.addConstr(q[j] >= q[i] + demand[j] - v_capa * (1 - x_given[i, j]))
    
    # for i in nodes:
    #     m.addConstr(q[i] >= demand[i])
    #     m.addConstr(q[i] <= v_capa)
    
    # 求解
    # m.setParam("TimeLimit", 60)
    m.optimize()
    
    if m.status == GRB.OPTIMAL:
        return True
    else:
        return False
            
def feasibilityTest_after_repair(x_given, customs, c_num, v_capa, v_num, demand, service_time, time_window, distance):
    # x_given = {(i,j):0 for i in range(c_num) for j in range(c_num)}
    # for route in solution:
    #     route_demand = sum(demand[_i] for _i in route if _i > 0)
    #     if route_demand > v_capa:
    #         return False
    #     i = 0
    #     for j in range(1, len(route)):
    #         x_given[route[i],route[j]] = 1
    #         i = j
    m = gp.Model("VRPTW_no_vehicle_index")
    # nodes = list(range(c_num))
    # x = m.addVars(nodes, nodes, vtype=GRB.BINARY, name="x")
    t = m.addVars(customs, vtype=GRB.CONTINUOUS, name="t")
    # q = m.addVars(nodes, vtype=GRB.CONTINUOUS, name="q")
    m.setParam(GRB.Param.OutputFlag, 0)
    # 目标函数
    m.setObjective(0, GRB.MINIMIZE)
    
    # 约束
    # for j in nodes[1:]:
    #     m.addConstr(gp.quicksum(x[i, j] for i in nodes if i != j) == 1, name = 'c1')
        
    # for i in nodes[1:]:
    #     m.addConstr(gp.quicksum(x[i, j] for j in nodes if j != i) == 1, name = 'c2')
    
    # m.addConstr(gp.quicksum(x[0, j] for j in nodes if j != 0) <= v_num, name = 'c3')
    
    # m.addConstr(gp.quicksum(x[i, 0] for i in nodes if i != 0) <= v_num, name = 'c4')
    
    M = 1e6
    for i in customs[1:]:
        for j in customs[1:]:
            if i != j:
                m.addConstr(t[i] + service_time[i] + distance[i][j] <= t[j] + M * (1 - x_given[i, j]), name = 'c5')
    
    for i in customs:
        m.addConstr(t[i] >= time_window[i][0])
        m.addConstr(t[i] <= time_window[i][1])
    
    # for i in nodes:
    #     for j in nodes:
    #         if i != j and i != 0 and j != 0:
    #             m.addConstr(q[j] >= q[i] + demand[j] - v_capa * (1 - x_given[i, j]))
    
    # for i in nodes:
    #     m.addConstr(q[i] >= demand[i])
    #     m.addConstr(q[i] <= v_capa)
    
    # 求解
    # m.setParam("TimeLimit", 60)
    m.optimize()
    
    if m.status == GRB.OPTIMAL:
        return True
    else:
        return False
        
import random
def VRPTW_repair(solution, c_num, v_capa, v_num, demand, service_time, time_window, distance,times=4,percent=0.25):
    for _ in range(times):
        tag= VRPTW_repair_once(solution, c_num, v_capa, v_num, demand, service_time, time_window, distance, percent)
        if tag:
            return True
    return False
        
        
def VRPTW_repair_once(solution, c_num, v_capa, v_num, demand, service_time, time_window, distance, percent):
    
    customs = sorted(list(dict.fromkeys(x for sub in solution for x in sub)))
    x_given = {(i,j):0 for i in customs for j in customs}
    for route in solution:
        route_demand = sum(demand[_i] for _i in route if _i > 0)
        if route_demand > v_capa:
            return False
        i = 0
        for j in range(1, len(route)):
            x_given[route[i],route[j]] = 1
            i = j
    if percent is None:
        percent = 0.0
    if percent > 1.0:
        percent = percent / 100.0
    percent = max(0.0, min(1.0, float(percent)))
    free_cnt = int(round(len(x_given.keys()) * percent))
    free_keys = set(random.sample(list(x_given.keys()), free_cnt)) if free_cnt > 0 else set()
    m = gp.Model("VRPTW_no_vehicle_index")
    x = {}
    for key in x_given.keys():
        # xp 必须提供该 key，否则报错更早暴露问题
        # if key not in xp:
        #     raise KeyError(f"xp 缺少 key={key} 的取值，无法固定/放开该变量。")

        if key in free_keys:
            # 放开：自由二进制
            var = m.addVar(lb=0, ub=1, vtype=GRB.BINARY, name=f"x{key}")
        else:
            # 固定：lb=ub=xp[key]
            # val = int(round(xp[key]))
            var = m.addVar(lb=x_given[key], ub=x_given[key], vtype=GRB.BINARY, name=f"x{key}")
        x[key] = var
    
    # x = m.addVars(customs, customs, vtype=GRB.BINARY, name="x")
    t = m.addVars(customs, vtype=GRB.CONTINUOUS, name="t")
    q = m.addVars(customs, vtype=GRB.CONTINUOUS, name="q")
    m.setParam(GRB.Param.OutputFlag, 0)
    # 目标函数
    m.setObjective(gp.quicksum(distance[i][j] * x[i, j] for i in customs for j in customs if i != j),
                   GRB.MINIMIZE)
    
    # 约束
    for j in customs[1:]:
        m.addConstr(gp.quicksum(x[i, j] for i in customs if i != j) == 1, name = 'c1')
        
    for i in customs[1:]:
        m.addConstr(gp.quicksum(x[i, j] for j in customs if j != i) == 1, name = 'c2')
    
    m.addConstr(gp.quicksum(x[0, j] for j in customs if j != 0) <= v_num, name = 'c3')
    
    m.addConstr(gp.quicksum(x[i, 0] for i in customs if i != 0) <= v_num, name = 'c4')
    
    M = 1e6
    for i in customs[1:]:
        for j in customs[1:]:
            if i != j:
                m.addConstr(t[i] + service_time[i] + distance[i][j] <= t[j] + M * (1 - x[i, j]), name = 'c5')
    
    for i in customs:
        m.addConstr(t[i] >= time_window[i][0])
        m.addConstr(t[i] <= time_window[i][1])
    
    for i in customs:
        for j in customs:
            if i != j and i != 0 and j != 0:
                m.addConstr(q[j] >= q[i] + demand[j] - v_capa * (1 - x[i, j]))
    
    for i in customs:
        m.addConstr(q[i] >= demand[i])
        m.addConstr(q[i] <= v_capa)
    
    # 求解
    # m.setParam("TimeLimit", 60)
    # solution = {}
    m.optimize()
    # for i in customs:
    #     for j in customs:
    #         solution[i,j] = round(x[i,j].X)
    # return solution
    if m.status == GRB.OPTIMAL:
        return True
    else:
        return False
    
if __name__ == '__main__':
    # ==== 输入数据 ====
    # c_num = 6
    # v_capa = 15
    # v_num = 3
    # demand = [0, 4, 6, 3, 5, 2]
    # service_time = [0, 1, 1, 1, 1, 1]
    # time_window = [(0, 100), (10, 20), (15, 25), (20, 30), (10, 25), (15, 35)]
    # distance = np.array([
    #     [0, 9, 14, 23, 30, 5],
    #     [9, 0, 15, 20, 21, 18],
    #     [14, 15, 0, 18, 10, 13],
    #     [23, 20, 18, 0, 12, 10],
    #     [30, 21, 10, 12, 0, 7],
    #     [5, 18, 13, 10, 7, 0]
    # ])
    instances = IN.getInstances(['c102'])
    GurobiVRPTW(**instances['c102'])