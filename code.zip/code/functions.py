# -*- coding: utf-8 -*-
"""
Created on Tue Jun 24 13:57:47 2025

@author: DELL
"""

import pickle
def copy(originObj): 
    """
    对象深拷贝
    
    参数:
    originObj:被拷贝对象
    返回:
    l: 拷贝对象
    """
    l = pickle.loads(pickle.dumps(originObj))
    assert type(l)== type(originObj)
    return l

import matplotlib.pyplot as plt

def plot_vehicle_routes(vehicle_paths, b=None, c=None, s=None, text=''):
    """
    绘制每辆车的任务路径图
    :param vehicle_paths: List[List[Tuple[int, int]]]，每个子列表表示一辆车的任务点
    """
    
    plt.figure(figsize=(10, 8) ,dpi = 300)
    
    colors = plt.cm.get_cmap('tab20', len(vehicle_paths))  # 颜色映射

    for idx, path in enumerate(vehicle_paths):
        if not path:
            continue
        xs, ys = zip(*path)  # 拆分为 x 和 y 坐标
        xs,ys = list(xs),list(ys)
        if xs[0]==0:
            xs.pop(0)
            ys.pop(0)
        if xs[-1]==0:
            xs.pop()
            ys.pop()
        # xs=xs[1:]
        # ys=ys[1:]
        plt.plot(xs, ys, marker='o', label=f"Vehicle {idx}", color=colors(idx))
        
        # 在每个点上标记坐标
        for i, (x, y) in enumerate(path):
            if x == 0:
                continue
            plt.text(x-0.1, y-0.1, f"{i}", fontsize=8, ha='right', va='bottom', color=colors(idx))
            if c:
                plt.text(x, y-0.3, f"{c[x,y]}", fontsize=8, ha='right', va='bottom', color=colors(idx))
            if b:
                plt.text(x, y+0.1, f"{b[x,y]}", fontsize=8, ha='right', va='bottom', color=colors(idx))
    if s:
        for idx, t in enumerate(s):
            plt.text(idx+1, 0.8, f"{t}", fontsize=10, ha='right', va='bottom', color='red')
    plt.title(text)
    plt.xlabel("X")
    plt.ylabel("Y")
    # plt.grid(True)
    # plt.legend()
    # plt.axis('equal')
    plt.tight_layout()
    plt.show()
    
def find_min_sum_tuple(points):
    """
    输入一个由 (x, y) 元组组成的列表，返回 x + y 最小的元组。
    
    :param points: List[Tuple[int, int]]
    :return: Tuple[int, int]
    """
    return min(points, key=lambda p: p[0] + p[1])

def seqs2x_params(routes, w, p, v):
    routes = copy(routes)
    x = {}
    A = [(0,k) for k in range(1, v+1)]
    E = [(0,0)]
    D = [(i,j) for i in range(1,w) for j in range(1,p+1)]
    x_d = [(i,j,m,n) for (i,j) in D + A for (m,n) in D + E]
    for veh in routes:
        # if not routes[veh]:
        #     continue
        routes[veh].insert(0, (0,veh))
        # routes[veh].append((0,0))
        for i in range(1, len(routes[veh])):
            node = routes[veh][i]
            last_node = routes[veh][i-1]
            key = (*last_node, *node)          # 先拼接成一个 tuple
            x[key] = 1
            # x[*last_node, *node] = 1
    for key in x_d:
        if key not in x:
            x[key] = 0
    return x

def find_max_station_and_product(routes):
    max_i = -1
    max_j = -1
    for route in routes.values():
        for (i, j) in route:
            if i > max_i:
                max_i = i
            if j > max_j:
                max_j = j
    return max_i, max_j

import random
def random_color():
     colors1 = '0123456789ABCDEF'
     num = "#"
     for i in range(6):
         num += random.choice(colors1)
     return num
 
def myRound(value):
    value_int = int(value)
    value_decimal = value - value_int
    if value_decimal >= 0.5:
        return value_int + 1
    else:
        return value_int

# def solution_plot(solution):
#     plt.figure(figsize = (6.4*2,4.8*2), dpi = 600)
#     for i,j in A:
#         color = random_color()
#         while True:
#             tag = 0
#             for (m,n) in D + E:
#                 if x[i,j,m,n].x > 0.5:
#                     if (m,n) in E:
#                         pass
#                         # plt.plot(m,n,"o", color = "#000000"){}
#                     else:
#                         plt.plot(m,n,"o", color = color)
#                     if (i,j) not in A and (m,n) not in E:
#                         plt.plot([i,m],[j,n], color = color)
#                     # else:
#                         # plt.plot([i,m],[0,n], color = color)
#                     if (m,n)!=(0,0):
#                         plt.text(m, n-0.2, round(c[m,n].x), color = "#000000")
#                         plt.text(m, n+0.1, round(b[m,n].x), color = "#000FFF")
#                         i,j = m,n
#                     else:
#                         break
#                     # D.remove((m,n))
#                     tag = 1
#                     break
#             if tag == 0:
#                 break
#     for (i,j) in c1:
#         plt.text(i, j-0.2, round(c[i,j].x), color = "#000000")
#     plt.xlabel("Workstations")
#     plt.ylabel("Products")