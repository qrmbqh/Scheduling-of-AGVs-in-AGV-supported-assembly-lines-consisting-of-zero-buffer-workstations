# -*- coding: utf-8 -*-
"""
Created on Thu Feb 26 17:48:21 2026

@author: qrmbqh
"""


from __future__ import annotations
import time
import random
import functions as F
from typing import List, Tuple, Callable
import math
from timeSceduling import evaluation, evaluation_relaxed,evaluation_repairMILP
import ini_solution as IS
import timeSceduling as ts
import getSolomonInstances as gSI
import getSolomonSolutions as gSS
import VRPTW
Task = Tuple[int, int]      # opaque task identifier (e.g. (job_id, something))
Route = List[Task]
Solution = List[Route]

# ---------------------------------------------------------------------------
#  Types
# ---------------------------------------------------------------------------

EvalFn = Callable[[Solution], tuple[bool, float]]   # (feasible?, objective)
Move   = Callable[[Solution], Solution]

# ---------------------------------------------------------------------------
#  Elementary neighbourhood operators
# ---------------------------------------------------------------------------

def findLenGEq(lsts,q):
    inds = []
    for l in lsts:
        if len(l) >= q:
            inds.append(lsts.index(l))
    return inds

def two_opt(sol: Solution) -> Solution:
    '''
    随机选择一个车辆，并从该车辆的任务序列随机截取一段，将这段任务序列逆序后插入原位置。
    '''
    s = F.copy(sol)
    # r = random.randrange(len(s))
    r = random.choice(findLenGEq(s,4))
    route = s[r]
    # if len(route) <= 4:
    #     return s
    i, j = sorted(random.sample(range(1, len(route)-1), 2))
    route[i:j] = reversed(route[i:j])
    return s

def two_opt_star(sol: Solution) -> Solution:
    '''
    从两个不同路径中各选一个断点，交换尾部子路径，构造邻域解。
    '''
    s = F.copy(sol)
    route_indices = findLenGEq(s, 4)
    if len(route_indices) < 2:
        return s  # 至少需要两条可操作路径

    r1 = random.choice(route_indices)
    route1 = s[r1]
    rs = list(range(len(s)))
    rs.remove(r1)
    r2 = random.choice(rs)
    route2 = s[r2]

    # 随机选断点（不选 depot，不选最后一个点）
    cut1 = random.randint(1, len(route1) - 2)
    cut2 = random.randint(1, len(route2) - 1)

    # 交换尾部
    new_route1 = route1[:cut1] + route2[cut2:]
    new_route2 = route2[:cut2] + route1[cut1:]

    s[r1] = new_route1
    s[r2] = new_route2
    return s

def or_opt(sol: Solution, k: int = 2) -> Solution:
    '''
    从某条路径中随机提取连续 k 个任务（不含起末 depot），
    插入到同路径或其他路径的某个新位置，构造邻域解。
    '''
    s = F.copy(sol)
    route_indices = findLenGEq(s, k + 3)  # 至少能截 k 段 + depot + 2
    if not route_indices:
        return s  # 没有可操作路径，直接返回原解

    r1 = random.choice(route_indices)
    route1 = s[r1]

    # 从 route1 中选取连续长度为 k 的任务段（不含 depot）
    i = random.randint(1, len(route1) - k - 1)
    block = route1[i:i + k]
    del route1[i:i + k]

    # 选择插入路径
    r2 = random.choice(range(len(s)))
    route2 = s[r2]

    # 插入到合法位置（不插入 depot），注意不能插回原位置
    insert_pos = random.randint(1, len(route2) - 1)
    route2[insert_pos:insert_pos] = block

    return s

def relocate(sol: Solution) -> Solution:
    '''
    随机取一辆车中的一个任务，再随机将其插入一辆车辆的任务序列的一个随机位置。
    '''
    s = F.copy(sol)
    # from_r = random.randrange(len(s))
    from_r = random.choice(findLenGEq(s,3))
    # if len(s[from_r]) <= 2:
    #     return s
    idx = random.randrange(1, len(s[from_r])-1)
    task = s[from_r].pop(idx)
    to_r = random.randrange(len(s))
    pos = random.randrange(1, len(s[to_r]))
    # pos = random.choice(range(max(idx-5,1), min(idx+5,len(s[to_r]))))
    s[to_r].insert(pos, task)
    return s

def intra_route_swap(sol: Solution) -> Solution:
    '''
    同一个车辆任务内部随机选两个进行位置交换。
    '''
    s = F.copy(sol)
    
    r_idx = random.choice(findLenGEq(s,4))
    route = s[r_idx]
    # if len(route) <= 4:
    #     return s  # need at least 2 movable tasks
    i, j = random.sample(range(1, len(route)-1), 2)
    # i = random.choice(range(1,len(route)-1))
    # j = random.choice(range(max(i-5,1), min(i+5, len(route)-1)))
    route[i], route[j] = route[j], route[i]
    return s


def inter_route_swap(sol: Solution) -> Solution:
    '''
    在不同的两个车辆中分别选择一个任务进行交换。
    '''
    if len(sol) < 2:
        return sol
    s = F.copy(sol)
    # r1, r2 = random.sample(range(len(s)), 2)
    r1, r2 = random.sample(findLenGEq(s,4),2)
    # if len(s[r1]) <= 2 or len(s[r2]) <= 2:
    #     return s
    i = random.randrange(1, len(s[r1])-1)
    j = random.randrange(1, len(s[r2])-1)
    s[r1][i], s[r2][j] = s[r2][j], s[r1][i]
    return s

def cross_exchange(sol: Solution, max_seg_len: int = 3) -> Solution:
    '''
    从两个路径中各随机选取一段连续任务子串，交换它们，构造邻域解。
    '''
    s = F.copy(sol)
    route_indices = findLenGEq(s, 4)
    if len(route_indices) < 2:
        return s  # 至少需要两条可操作路径

    r1, r2 = random.sample(route_indices, 2)
    route1 = s[r1]
    route2 = s[r2]

    # 计算最大允许段长（排除 depot）
    len1 = len(route1) - 2
    len2 = len(route2) - 2
    if len1 < 1 or len2 < 1:
        return s

    seglen1 = random.randint(1, min(len1, max_seg_len))
    seglen2 = random.randint(1, min(len2, max_seg_len))

    i1 = random.randint(1, len(route1) - seglen1 - 1)
    i2 = random.randint(1, len(route2) - seglen2 - 1)

    seg1 = route1[i1:i1 + seglen1]
    seg2 = route2[i2:i2 + seglen2]

    # 构造新路径
    new_route1 = route1[:i1] + seg2 + route1[i1 + seglen1:]
    new_route2 = route2[:i2] + seg1 + route2[i2 + seglen2:]

    s[r1] = new_route1
    s[r2] = new_route2
    return s


# ---------------------------------------------------------------------------
#  Main search driver
# ---------------------------------------------------------------------------
def random_neighbourhood_feasible_test(
    # initial: Solution,
    # evaluation: EvalFn,
    # iterations: int = 1000,
    # initial_temperature: float = 1.0,
    # max_worse_iteration = 100,
    # cooling_rate: float = 0.995,
    # min_temperature: float = 1e-4,
    vrptw_scale:int = 100,
    seed: int | None = None,
    neighbourhood:  list[Move] | None = None,
) -> tuple[Solution, float]:
    """
    Pure local search with simulated annealing (SA).

    Parameters
    ----------
    evaluation    : Function(sol) → (feasible, objective, time)
    iterations    : Total search steps
    initial_temperature : Starting temperature for SA
    cooling_rate  : Multiplicative decay per iteration (e.g. 0.995)
    min_temperature : Stop cooling once below this
    seed          : Random seed
    neighbourhood : List of move functions (must return new solution)

    Returns
    -------
    best_solution, best_objective
    """
    # t1=time.time()
    _, initial = IS.ini_sol()
    # F.plot_vehicle_routes(initial)
    if seed is not None:
        random.seed(seed)

    feasible, obj, _,_,_ = evaluation(initial)
    if not feasible:
        raise ValueError("Initial solution infeasible under evaluation.")

    # best = F.copy(initial)
    # best_obj = obj
    # best_b,best_c = None,None

    current = F.copy(initial)
    # current_obj = obj

    # T = initial_temperature
    moves = neighbourhood or [intra_route_swap,inter_route_swap, two_opt,two_opt_star, relocate,cross_exchange,or_opt]#
    
    move_fn = random.choice(moves)
    candidate = move_fn(current)
    
    # evaluations = [evaluation_relaxed,evaluation]
    tag_our, _, _, _, _ = evaluation(candidate)
    tag_relaxed, _, _, _, _ = evaluation_relaxed(candidate)
    
    instance_set = gSI.getInstanceNames()
    instance_name = random.choice(instance_set)
    # instance_name = 'c101'
    instance_params = gSI.getInstances([instance_name])
    v_num = instance_params[instance_name]['v_num']
    if vrptw_scale:
        instance_params[instance_name]['c_num'] = vrptw_scale
    initial_solution = gSS.getSolutionFromFile(instance_name, v_num, vrptw_scale)
    candidate = move_fn(initial_solution)
    tag_vrptw = VRPTW.feasibilityTest(candidate, **list(instance_params.values())[0])
    return tag_our, tag_relaxed, tag_vrptw,move_fn.__name__

def random_neighbourhood_feasible_test_v1(
    # initial: Solution,
    # evaluation: EvalFn,
    # iterations: int = 1000,
    initial_temperature: float = 1.0,
    max_worse_iteration = 100,
    cooling_rate: float = 0.995,
    min_temperature: float = 1e-4,
    seed: int | None = None,
    neighbourhood:  list[Move] | None = None,
) -> tuple[Solution, float]:
    """
    Pure local search with simulated annealing (SA).

    Parameters
    ----------
    evaluation    : Function(sol) → (feasible, objective, time)
    iterations    : Total search steps
    initial_temperature : Starting temperature for SA
    cooling_rate  : Multiplicative decay per iteration (e.g. 0.995)
    min_temperature : Stop cooling once below this
    seed          : Random seed
    neighbourhood : List of move functions (must return new solution)

    Returns
    -------
    best_solution, best_objective
    """
    # t1=time.time()
    _, initial = IS.ini_sol()
    # F.plot_vehicle_routes(initial)
    if seed is not None:
        random.seed(seed)

    feasible, obj, _,_,_ = evaluation(initial)
    if not feasible:
        raise ValueError("Initial solution infeasible under evaluation.")
    
    moves = neighbourhood or [intra_route_swap, inter_route_swap, relocate, two_opt]
    
    move_fn = random.choice(moves)
    candidate = move_fn(initial)

    current = F.copy(initial)
    # current_obj = obj

    # T = initial_temperature
    moves = neighbourhood or [intra_route_swap, inter_route_swap, relocate, two_opt]
    
    move_fn = random.choice(moves)
    candidate = move_fn(current)
    
    # evaluations = [evaluation_relaxed,evaluation]
    tag, _, _, _, _ = evaluation(candidate)
    tag_relaxed, _, _, _, _ = evaluation_relaxed(candidate)
    return tag, tag_relaxed


def neighbourhoodFeasibilityVRPTWTest(
    scale:int = 0,
    seed: int | None = None,
    neighbourhood:  list[Move] | None = None,
    ) -> tuple[Solution, float]:
    if seed is not None:
        random.seed(seed)
    instance_set = gSI.getInstanceNames()
    instance_name = random.choice(instance_set)
    # instance_name = 'c101'
    instance_params = gSI.getInstances([instance_name])
    v_num = instance_params[instance_name]['v_num']
    if scale:
        instance_params[instance_name]['c_num'] = scale
    initial_solution = gSS.getSingleInstanceSolution(instance_name, v_num, scale)
    # tag = VRPTW.feasibilityTest(initial_solution, **list(instance_params.values())[0])
    # F.plot_vehicle_routes(initial)
    moves = neighbourhood or [intra_route_swap,inter_route_swap, two_opt,two_opt_star, relocate,cross_exchange,or_opt]
    move_fn = random.choice(moves)
    candidate = move_fn(initial_solution)
    tag = VRPTW.feasibilityTest(candidate, **list(instance_params.values())[0])
    return tag

def random_neighbourhood_feasible_test_operation(
    times,
    move_fn,
    vrptw_scale:int = 100,
    seed: int | None = None,
    neighbourhood:  list[Move] | None = None,
) -> tuple[Solution, float]:
    """
    Pure local search with simulated annealing (SA).

    Parameters
    ----------
    evaluation    : Function(sol) → (feasible, objective, time)
    iterations    : Total search steps
    initial_temperature : Starting temperature for SA
    cooling_rate  : Multiplicative decay per iteration (e.g. 0.995)
    min_temperature : Stop cooling once below this
    seed          : Random seed
    neighbourhood : List of move functions (must return new solution)

    Returns
    -------
    best_solution, best_objective
    """
    # t1=time.time()
    _, initial = IS.ini_sol()
    # F.plot_vehicle_routes(initial)
    if seed is not None:
        random.seed(seed)

    feasible, obj, _,_,_ = evaluation(initial)
    if not feasible:
        raise ValueError("Initial solution infeasible under evaluation.")
    
    instance_set = gSI.getInstanceNames()
    instance_name = random.choice(instance_set)
    # instance_name = 'c101'
    instance_params = gSI.getInstances([instance_name])
    v_num = instance_params[instance_name]['v_num']
    if vrptw_scale:
        instance_params[instance_name]['c_num'] = vrptw_scale
    initial_solution = gSS.getSolutionFromFile(instance_name, v_num, vrptw_scale)
    tag_our, tag_relaxed, tag_vrptw=[],[],[]
    for _ in range(times):
        current = F.copy(initial)
        candidate = move_fn(current)
    
        tag_our_, _, _, _, _ = evaluation(candidate)
        tag_relaxed_, _, _, _, _ = evaluation_relaxed(candidate)
        
        candidate = move_fn(initial_solution)
        tag_vrptw_ = VRPTW.feasibilityTest(candidate, **list(instance_params.values())[0])
        tag_our.append(tag_our_), tag_relaxed.append(tag_relaxed_), tag_vrptw.append(tag_vrptw_)
    return tag_our, tag_relaxed, tag_vrptw, move_fn.__name__

def random_neighbourhood_feasible_test_operation_lns(
    times,
    move_fn,
    vrptw_scale:int = 100,
    seed: int | None = None,
    neighbourhood:  list[Move] | None = None,
) -> tuple[Solution, float]:
    """
    Pure local search with simulated annealing (SA).

    Parameters
    ----------
    evaluation    : Function(sol) → (feasible, objective, time)
    iterations    : Total search steps
    initial_temperature : Starting temperature for SA
    cooling_rate  : Multiplicative decay per iteration (e.g. 0.995)
    min_temperature : Stop cooling once below this
    seed          : Random seed
    neighbourhood : List of move functions (must return new solution)

    Returns
    -------
    best_solution, best_objective
    """
    # t1=time.time()
    _, initial = IS.ini_sol()
    # F.plot_vehicle_routes(initial)
    if seed is not None:
        random.seed(seed)

    feasible, obj, _,_,_ = evaluation(initial)
    if not feasible:
        raise ValueError("Initial solution infeasible under evaluation.")
    
    instance_set = gSI.getInstanceNames()
    instance_name = random.choice(instance_set)
    # instance_name = 'c101'
    instance_params = gSI.getInstances([instance_name])
    v_num = instance_params[instance_name]['v_num']
    if vrptw_scale:
        instance_params[instance_name]['c_num'] = vrptw_scale
    initial_solution = gSS.getSolutionFromFile(instance_name, v_num, vrptw_scale)
    tag_our, tag_relaxed, tag_relaxed_repair, tag_vrptw=[],[],[],[]
    for _ in range(times):
        current = F.copy(initial)
        candidate = move_fn(current)
    
        tag_our_, _, _, _, _ = evaluation(candidate)
        tag_relaxed_, _, _, _, _ = evaluation_relaxed(candidate)
        tag_repair_, _, _, _, _ = evaluation_repairMILP(candidate)
        candidate = move_fn(initial_solution)
        tag_vrptw_ = VRPTW.feasibilityTest(candidate, **list(instance_params.values())[0])
        tag_our.append(tag_our_), tag_relaxed.append(tag_relaxed_),tag_relaxed_repair.append(tag_repair_), tag_vrptw.append(tag_vrptw_)
        
    return tag_our, tag_relaxed, tag_relaxed_repair, tag_vrptw, move_fn.__name__

def random_neighbourhood_feasible_VRPTW_repair(
    times,
    move_fn,
    vrptw_scale:int = 50,
    seed: int | None = None,
    neighbourhood:  list[Move] | None = None,
) -> tuple[Solution, float]:
    """
    Pure local search with simulated annealing (SA).

    Parameters
    ----------
    evaluation    : Function(sol) → (feasible, objective, time)
    iterations    : Total search steps
    initial_temperature : Starting temperature for SA
    cooling_rate  : Multiplicative decay per iteration (e.g. 0.995)
    min_temperature : Stop cooling once below this
    seed          : Random seed
    neighbourhood : List of move functions (must return new solution)

    Returns
    -------
    best_solution, best_objective
    """
    _, initial = IS.ini_sol()
    
    instance_set = gSI.getInstanceNames()
    instance_name = random.choice(instance_set)
    # instance_name = 'c101'
    instance_params = gSI.getInstances([instance_name])
    v_num = instance_params[instance_name]['v_num']
    if vrptw_scale:
        instance_params[instance_name]['c_num'] = vrptw_scale
    initial_solution = gSS.getSolutionFromFile(instance_name, v_num, vrptw_scale)
    # customs = sorted(list(dict.fromkeys(x for sub in initial_solution for x in sub)))
    tag_vrptw,tag_vrptw_repair=[],[]
    tag_asp,tag_aspr=[],[]
    tag_rasp = []
    for _ in range(times):
        current = F.copy(initial)
        candidate = move_fn(current)
    
        tag_our_, _, _, _, _ = evaluation(candidate)
        tag_relaxed_, _, _, _, _ = evaluation_relaxed(candidate)
        tag_repair_, _, _, _, _ = evaluation_repairMILP(candidate)
        tag_asp.append(tag_our_)
        tag_aspr.append(tag_repair_)
        tag_rasp.append(tag_relaxed_)
        
        candidate = move_fn(initial_solution)
        tag_vrptw_ = VRPTW.feasibilityTest(candidate, **list(instance_params.values())[0])
        tag_vrptw_repair_ = VRPTW.VRPTW_repair(candidate, **list(instance_params.values())[0])
        # tag_vrptw_repair_ = VRPTW.feasibilityTest_after_repair(repair_solution, customs,**list(instance_params.values())[0])
        tag_vrptw.append(tag_vrptw_), tag_vrptw_repair.append(tag_vrptw_repair_)
        
    return tag_vrptw, tag_vrptw_repair,tag_asp,tag_aspr,tag_rasp,move_fn.__name__
# ---------------------------------------------------------------------------
#  Example (stub) – delete or replace in production
# ---------------------------------------------------------------------------
# import CBSWithoutStatus as H
if __name__ == "__main__":
    # res = neighbourhoodFeasibilityVRPTWTest(50)
    # print(res)
    v=3
    p=10
    w=6
    s= [2,3,3,5,3,6,2]
    d= [2,2,2,2,2,2]
    s = [random.randint(3, 10) for _ in range(w)]
    d = [random.randint(2, 5) for _ in range(w-1)]
    h= 1
    ts.setGlobalParam(w, p, v, s, d, h)
    IS.setGlobalParam(w, p, v, s, d, h)
    # t1=time.time()
    # ini_x, ini_seqs = IS.ini_sol()
    # F.plot_vehicle_routes(ini_seqs)
    # m = H.CBS(w, p, v, s, d, h)
    # makespan,t= m.CBS_NL(3,3)
    # sd = random.randint(0, 100)
    # sd = 29
    #intra_route_swap,inter_route_swap, two_opt,two_opt_star, relocate,cross_exchange,or_opt
    tag_vrptw, tag_vrptw_repair,tag_asp,tag_aspr = random_neighbourhood_feasible_VRPTW_repair(times=2,move_fn = intra_route_swap)
    # print(tag, tag_relaxed)
    # t2=time.time()
    # F.plot_vehicle_routes(best, b,c,s)
    # print(f"time={t}")
    # print("Best obj:", best_obj)
    # print(f'obj LS={best_obj},time={t}, my obj={makespan}')
    # for i, r in enumerate(best):
    #     print(f"Route {i}: {r}")
