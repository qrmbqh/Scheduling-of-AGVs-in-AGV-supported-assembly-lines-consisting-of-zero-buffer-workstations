# -*- coding: utf-8 -*-
"""
Created on Thu Feb 26 00:11:06 2026

@author: DELL
"""
from datetime import datetime
# performance evaluate
# import GurobiWithStatus as GSLS
# import GurobiWithoutStatus as GS
import CBSwithStatistic as CBS
import csv
import s2str
import randomGenerator as rg
import time
t1 = time.time()

def new_performance(wcc, vc, pc, low_d, up_d, h, low_s, up_s, time, count, fileName):
    for i in range(count):
        s = rg.random_nums(wcc, low_s, up_s)
        d = rg.random_nums(wcc-1, low_d,up_d)
        try:
            # t1 = time.perf_counter()
            print(str(i+1)+"th")
            # best_obj, best_bound, optimal_gap, timeConsume = GS.newAGVSchedul(vc, pc, wcc, s, d, h, t_limited=time)
            # print(best_obj, best_bound, optimal_gap, timeConsume)
            cbs = CBS.CBS(wcc, pc, vc, s, d, h)
            cbs_makespan, cbs_makespan_t, res = cbs.CBS_NL(3, 3)
            # print(cbs_makespan, cbs_makespan_t)
            # mcbs = CBS.MCBS(wcc, pc, vc, s, d, h)
            # mcbs_makespan, mcbs_makespan_t = mcbs.CBS_NL(3, 3, True)
        except Exception as E_results:
            print("捕捉有异常：",E_results)
            f = open(fileName,'a',newline='')
            writer = csv.writer(f)
            writer.writerow([ vc,
                              pc,
                              wcc,
                              pc*wcc,
                              low_s, up_s,
                              s2str.list2str(s),
                              low_d, up_d,
                              s2str.list2str(d),
                              h
                              ])
            f.close()
        else:
            f = open(fileName,'a',newline='')
            writer = csv.writer(f)
            writer.writerow([ vc,
                              pc,
                              wcc,
                              pc*wcc,
                              low_s, up_s,
                              s2str.list2str(s),
                              low_d, up_d,
                              s2str.list2str(d),
                              h,
                              # best_obj, best_bound, optimal_gap, timeConsume,
                              cbs_makespan, cbs_makespan_t,
                              res[0],res[1],res[2],res[3],res[4],res[5]
                              ])
            f.close()
    return
            
WP = [(12,15)]
V = [5]
D = [(2,5)]
S = [(10,15)]
H = 1
count = 1
total = count*len(D)*len(S)*len(WP)*len(V)
actual = total
current_date = datetime.now()
date_str = current_date.strftime('%Y-%m-%d')
current_date = datetime.now().date()
date_str = current_date.strftime('%Y-%m-%d')
date_str = "2026-02-26"
fileName = 'State statistic'+date_str+'.csv'
f = open(fileName,'a',newline='')
writer = csv.writer(f)
writer.writerow([ 'vc',
                  'pc',
                  'wcc',
                  'taskcount',
                  'low_s', 'up_s',
                  'S',
                  'low_d','up_d',
                  'D',
                  'h',
                  # 'best_obj', 'best_bound', 'optimal_gap', 'timeConsume',
                  'cbs_makespan', 'cbs_makespan_t',
                  'av_solset','max_solset','av_pool','max_pool','av_seed','max_seed'
                  ])
f.close()
for wcc, pc in WP:
    for vc in V:
        for low_d, up_d in D:
            for low_s, up_s in S:
                new_performance(wcc,vc,pc,low_d,up_d,H,low_s,up_s, 3600, count,fileName)
                actual -= count
                print('Progress: {:.2%}'.format(1-actual/total))
t2 = time.time()