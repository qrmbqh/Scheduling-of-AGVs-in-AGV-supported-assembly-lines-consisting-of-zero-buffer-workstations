# -*- coding: utf-8 -*-
"""
Created on Thu Oct 27 21:22:00 2022

@author: qrmbqh
"""
import randomColor as rc
# import list2str
import copy
from gurobipy import *
import time
import random
import matplotlib.pyplot as plt

def newAGVSchedul(vc, pc, wcc, s, d, h, vision=False, t_limited=float('inf')):
    #计算距离矩阵
    S = [0] + s
    t1 = time.perf_counter()
    T_d = [(i,j) for i in range(1,wcc+1) for j in range(1,wcc+1)]
    
    T = {}
    for i,j in T_d:
        if i <= j:
            T[i,j] = sum(d[i-1:j-1])
        else:
            T[i,j] = sum(d[j-1:i-1])+2*h
            
    #生成AGV集合
    V = list(range(1, vc+1))
            
    #定义开始的虚拟任务区域
    A = [(0,v) for v in V]
    E = [(0,0)]
    #任务区域zh
    D = [(i,j) for i in range(1,wcc) for j in range(1,pc+1)]
    # DD = copy.deepcopy(D)
    M = len(D)*max(S)*100
    
    #BD定义
    b1 = [(0,j) for j in range(pc+1)]
    b2 = [(i,0) for i in range(1,wcc)]
    
    #CD定义
    c1 = [(wcc, j) for j in range(pc + 1)]
    c2 = [(i,0) for i in range(1,wcc)]
    #定义结束的虚拟任务区域
    c_d = D + c1 + c2
    b_d = D + b1 + b2
    x_d = [(i,j,m,n) for (i,j) in D + A for (m,n) in D + E]
    #线性化用到的辅助变量区间定义
    # define model
    mdl = Model("Model")
    #define variables
    x = mdl.addVars(x_d, vtype = GRB.BINARY, name = 'x')
    b = mdl.addVars(b_d, lb = 0, name = 'b')
    c = mdl.addVars(c_d, lb = 0, name = 'c')
    #objective function #最小化完工时间
    obj1 = LinExpr(0)
    obj1.addTerms(1, c[wcc,pc])
    mdl.setObjective(obj1, GRB.MINIMIZE)
        
    for (i,j) in D + A:
        expr = LinExpr(0)
        for m,n in D + E:
            expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 1)
    
    #c2
    for m,n in D:
        expr = LinExpr(0)
        for i,j in D + A:
            expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 1)
    
    for i,j in D:
        expr = LinExpr(0)
        for m, n in D:
            if m > i and m+n <= i+j:
                expr.addTerms(1, x[i,j,m,n])
        mdl.addConstr(expr == 0)
        
    #c5
    for i,j in D:
        for m,n in D:
            expr = LinExpr(0)
            expr.addTerms(M, x[i,j,m,n])
            expr.addTerms(1, b[m-1,n])
            expr.addTerms(-1, b[i,j])
            mdl.addConstr(expr <= M + T[i+1,m])
    
    for i,j in b1:
        if j > 1:
            mdl.addConstr(b[i,j]==c[i+1,j-1])
    
    #7
    for i,j in D:
        for m,n in D:
            expr = LinExpr(0)
            expr.addTerms(M, x[i,j,m,n])
            expr.addTerms(-1,c[m,n])
            expr.addTerms(1, b[i,j])
            mdl.addConstr(expr <= M - T[i+1,m])
            
    #8
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(-1, c[i,j])
        expr.addTerms(1, c[i+1,j-1])
        mdl.addConstr(expr <= T[i,i+1])
       
    #9
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(-1, c[i,j])
        expr.addTerms(1, c[i+1,j])
        mdl.addConstr(expr >= T[i,i+1] + S[i+1])
    
    for j in range(1, pc+1):
        expr = LinExpr(0)
        expr.addTerms(1, c[1,j])
        expr.addTerms(-1, c[1,j-1])
        mdl.addConstr(expr >= S[1])
    
    #10
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(1, b[i,j])
        expr.addTerms(-1, c[i,j])
        mdl.addConstr(expr == T[i,i+1])
    
    # mdl.setParam(GRB.Param.PoolGap, 0)
    # mdl.setParam("PoolSearchMode", 0)
    # mdl.setParam(GRB.Param.OutputFlag, 0)  
    mdl.Params.TimeLimit = t_limited
    mdl.optimize()
    t_consumed = mdl.getAttr('Runtime')
    # t2= time.perf_counter()
    best_obj = mdl.ObjVal
    best_bound = mdl.ObjBound
    optimal_gap = abs(best_obj - best_bound) / abs(best_obj)
    # if vision:
    #     plt.figure(figsize = (6.4*2,4.8*2), dpi = 600)
    #     for i,j in A:
    #         color = rc.random_color()
    #         while True:
    #             tag = 0
    #             for (m,n) in D + E:
    #                 if x[i,j,m,n].x > 0.5:
    #                     if (m,n) in E:
    #                         pass
    #                         # plt.plot(m,n,"o", color = "#000000"){}
    #                     else:
    #                         plt.plot(m,n,"o", color = color)
    #                     if (i,j) not in A and (m,n) not in E:
    #                         plt.plot([i,m],[j,n], color = color)
    #                     # else:
    #                         # plt.plot([i,m],[0,n], color = color)
    #                     if (m,n)!=(0,0):
    #                         plt.text(m, n-0.2, round(c[m,n].x), color = "#000000")
    #                         plt.text(m, n+0.1, round(b[m,n].x), color = "#000FFF")
    #                         i,j = m,n
    #                     else:
    #                         break
    #                     # D.remove((m,n))
    #                     tag = 1
    #                     break
    #             if tag == 0:
    #                 break
    #     for (i,j) in c1:
    #         plt.text(i, j-0.2, round(c[i,j].x), color = "#000000")
    #     plt.xlabel("Workstations")
    #     plt.ylabel("Products")
    # for i,j,m,n in x_d:
    #     if x[i,j,m,n].x > 0.5:
    #         print(f'x{i,j,m,n}=1')
    # print(f'c[5,1]={c[5,1].x}')
    # print(f'b[5,1]={b[5,1].x}')
    # print(f'b[5,1]={b[5,0].x}')
    # print(f'c[1,4]={c[1,4].x}')
    # print(f'b[1,4]={b[1,4].x}')
    # print(f'b[0,4]={b[0,4].x}')
    # print(f'b[3,5]={b[3,5].x}')
    # print(f'b[1,6]={b[1,6].x}')
    return best_obj, best_bound, optimal_gap, t_consumed

if __name__ == "__main__":
    v = 3
    p = 9
    w = 8
    delta = 1e-4
    # s= [7, 3, 9, 7, 3, 6]
    seed = random.randint(0, 100)
    # seed = 29
    random.seed(seed)
    s= [random.randint(3, 10) for _ in range(w)]
    # s.sort()
    print(s)
    # s =[7, 27, 18, 19, 12, 29, 28, 8, 28, 8]
    # d= [2, 2, 2, 2, 2]
    d = [delta]*(w-1)
    d = [random.randint(1, 5) for _ in range(w-1)]
    h= 0
    obj,_,gap,t = newAGVSchedul(vc = v, pc = p, wcc = w, s = s, d = d, h = h, vision=True)
    print(obj)