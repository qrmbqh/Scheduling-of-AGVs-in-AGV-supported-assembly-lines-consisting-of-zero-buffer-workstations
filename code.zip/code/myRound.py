# -*- coding: utf-8 -*-
"""
Created on Thu Dec  1 22:18:23 2022

@author: qrmbqh
"""

def myRound(value):
    value_int = int(value)
    value_decimal = value - value_int
    if value_decimal >= 0.5:
        return value_int + 1
    else:
        return value_int