# -*- coding: utf-8 -*-
"""
Created on Fri Mar 13 11:56:44 2026

@author: lenovo
"""

import pandas as pd
import numpy as np
# from tqdm import tqdm
import CBSWithoutStatus as CBS
import s2str
import csv
import randomGenerator as RG

def parse_numbers(s: str):
    """
    将形如 '7,5,10,5,10,8,7,6,6,' 的字符串解析为整数列表
    """
    # 去掉首尾逗号后 split，再过滤掉空字符串
    return [int(x) for x in s.strip(",").split(",") if x]

df = pd.read_excel('agv_num待补充.xlsx',sheet_name='Sheet2')

fileName = "agv_num_supplement2.csv"
f = open(fileName,'a',newline='')
writer = csv.writer(f)
writer.writerow([ 'vc',
                  'pc',
                  'wcc',
                  'taskcount',
                  'low_s', 'up_s',
                  'S',
                  'low_d','up_d',
                  'D',
                  'h',
                  'cbs_makespan'
                  ])
f.close()

wcc = 14
h=1
for pc in [10,12,14,16,18,20]:
    s = RG.random_nums(wcc, 5, 10)
    d = RG.random_nums(wcc-1, 2, 5)
    for vc in range(1,wcc+1):
        cbs = CBS.CBS(wcc, pc, vc, s, d, h)
        cbs_makespan, cbs_makespan_t = cbs.CBS_NL(3, 3)
        f = open(fileName,'a',newline='')
        writer = csv.writer(f)
        writer.writerow([ vc,
                          pc,
                          wcc,
                          pc*wcc,
                          5, 10,
                          s2str.list2str(s),
                          1, 1,
                          s2str.list2str(d),
                          h,
                          cbs_makespan
                          ])
        f.close()