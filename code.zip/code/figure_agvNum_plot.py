# -*- coding: utf-8 -*-
"""
Created on Wed Feb 26 00:22:58 2025

@author: 74110
"""
import pandas as pd
import matplotlib.pyplot as plt

# 示例: 构造一个演示 DataFrame
file_path = "figure_agvNum_data2025-03-08.csv"  # 请替换为你的文件路径
df = pd.read_csv(file_path)

# df = pd.DataFrame({
#     "vc": [1,1,2,2,3,3,4,4],
#     "cbs_makespan": [100, 98, 80, 82, 65, 63, 58, 59]
# })
plt.rcParams.update({
    'font.size': 18,  # 字体大小
    'font.family': 'times new roman',  # 字体家族
    'mathtext.fontset': 'stix',  # 让数学公式字体与主字体匹配
})

plt.rcParams['font.family'] = 'Times New Roman'  # 你可以选择其他字体，比如 'SimHei'（支持中文）
df_grouped = (
    df.groupby("vc")["cbs_makespan"]
      .mean()                           # 求均值
      .reset_index(name="mean_makespan")
)

# 按 vc 升序排序，确保绘图时横坐标有序
df_grouped.sort_values("vc", inplace=True)
df_grouped

vc_max = df_grouped["vc"].max()  # 最大 vc 值
mean_max = df_grouped.loc[df_grouped["vc"] == vc_max, "mean_makespan"].iloc[0]
mean_min = df_grouped.loc[df_grouped["vc"] == 1, "mean_makespan"].iloc[0]
max_imp = mean_min-mean_max
# print("最大 vc =", vc_max)
# print("该 vc 对应的 mean_makespan =", mean_max)

df_grouped["percentage"] = (
    abs((df_grouped["mean_makespan"] - mean_min))
    / max_imp 
    * 100
)
df_grouped

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6),dpi=600)

# ---- 子图1: mean_makespan 随 vc 的变化 ----
ax1.plot(df_grouped["vc"], df_grouped["mean_makespan"], marker='o',linewidth=3)
ax1.set_title("(a)")
ax1.set_xlabel("$v$")
ax1.set_ylabel("Makespan")
ax1.grid(True)

# ---- 子图2: (mean_makespan - mean_max)/mean_max * 100% ----
ax2.plot(df_grouped["vc"]*100/10, df_grouped["percentage"], marker='o', color="red", linewidth=3)
ax2.set_title("(b)")
ax2.set_xlabel("$\\frac{v}{w}$ (%)")
ax2.set_ylabel("Gain (%)")
ax2.grid(True)

plt.tight_layout()
plt.show()
