# -*- coding: utf-8 -*-
"""
Created on Sun Nov 20 15:32:50 2022

@author: qrmbqh
"""
from gurobipy import *
import math
import myRound
import pandas as pd

def QnAll(vNum, l):
    qs = []
    N = len(l)
    x_d = [i for i in range(N)]
    mdl = Model("Model")
    mdl.setParam('OutputFlag', 0)
    x = mdl.addVars(x_d, vtype = GRB.INTEGER, name = 'x')
    y = mdl.addVar(lb=0.0, ub=GRB.INFINITY, vtype=GRB.CONTINUOUS)
    obj = LinExpr(0)
    obj.addTerms(1,y)
    mdl.setObjective(obj, GRB.MINIMIZE)
    
    mdl.addConstr(quicksum(x[n] for n in x_d) == vNum)
    for n in x_d:
        mdl.addConstr(x[n] <= l[n])
        mdl.addConstr(x[n] >= math.floor(vNum * (l[n]/sum(l))))
        mdl.addConstr(x[n] <= math.ceil(vNum * (l[n]/sum(l))))
        
    mdl.setParam(GRB.Param.PoolSolutions, 1024)
    # mdl.setParam(GRB.Param.PoolGap, 0.10)
    mdl.setParam(GRB.Param.PoolSearchMode, 2)
    # mdl.write("qn.lp")
    mdl.optimize()
    
    nSolution = mdl.SolCount
    for solution in range(nSolution):
        q = []
        mdl.setParam(GRB.Param.SolutionNumber, solution)
        for n in x_d:
            q.append(int(x[n].Xn))
        qs.append(q)
    return qs
 
def QAll(vNum, l):
    qs = []
    N = len(l)
    x_d = [i for i in range(N)]
    mdl = Model("Model")
    mdl.setParam('OutputFlag', 0)
    x = mdl.addVars(x_d, lb=0, vtype = GRB.INTEGER, name = 'x')
    mdl.setObjective(0, GRB.MINIMIZE)
    
    mdl.addConstr(quicksum(x[n] for n in x_d) == vNum)
    for n in x_d:
        mdl.addConstr(x[n] <= l[n])
        # mdl.addConstr(x[n] >= 0)
        # mdl.addConstr(x[n] <= math.ceil(vNum * (l[n]/sum(l))))
        
    mdl.setParam(GRB.Param.PoolSolutions, 1024)
    # mdl.setParam(GRB.Param.PoolGap, 0.10)
    mdl.setParam(GRB.Param.PoolSearchMode, 2)
    # mdl.write("qn.lp")
    mdl.optimize()
    
    nSolution = mdl.SolCount
    for solution in range(nSolution):
        q = []
        mdl.setParam(GRB.Param.SolutionNumber, solution)
        for n in x_d:
            q.append(int(x[n].Xn))
        qs.append(q)
    return qs

def QNew(vNum, l):
    fractions = [vNum*(li/sum(l)) for li in l]
    qs = []
    N = len(l)
    x_d = [i for i in range(N)]
    mdl = Model("Model")
    mdl.setParam('OutputFlag', 0)
    x = mdl.addVars(x_d, lb=0, vtype = GRB.INTEGER, name = 'x')
    mdl.setObjective(0, GRB.MINIMIZE)
    
    mdl.addConstr(quicksum(x[n] for n in x_d) == vNum)
    for n in x_d:
        mdl.addConstr(x[n] <= int(fractions[n]) + 1)
        mdl.addConstr(x[n] >= int(fractions[n]))
        # mdl.addConstr(x[n] <= math.ceil(vNum * (l[n]/sum(l))))
        
    mdl.setParam(GRB.Param.PoolSolutions, 1024)
    # mdl.setParam(GRB.Param.PoolGap, 0.10)
    mdl.setParam(GRB.Param.PoolSearchMode, 2)
    # mdl.write("qn.lp")
    mdl.optimize()
    
    nSolution = mdl.SolCount
    for solution in range(nSolution):
        q = []
        mdl.setParam(GRB.Param.SolutionNumber, solution)
        for n in x_d:
            q.append(int(x[n].Xn))
        qs.append(q)
    return qs


def QnCeil(vNum, l):
    q = []
    for n in range(len(l)):
        if n == 0:
            q.append(math.ceil(l[n]*vNum/sum(l)))
        else:
            qn = min(math.ceil(l[n]*vNum/sum(l)), vNum - sum(q))
            q.append(qn)
    return [q]

def QnBoth(vNum, l):
    q1 = []
    q2 = []
    qs = []
    for n in range(len(l)):
        if n == 0:
            rate = l[n]*vNum/sum(l)
            q1.append(math.ceil(rate))
            q2.append(myRound.myRound(rate))
        else:
            rate = l[n]*vNum/sum(l)
            q1n = min(math.ceil(rate), vNum - sum(q1))
            q2n = min(myRound.myRound(rate), vNum - sum(q1))
            q1.append(q1n)
            q2.append(q2n)
    qs.append(q1)
    
    while sum(q2) < vNum:
        for n in range(len(l)):
            if q2[n] < l[n]:
                q2[n] += 1
                break 
    if q1 != q2:
        qs.append(q2)
    return qs

def QnBothModify(vNum, l):
    q1 = []
    q2 = []
    qs = []
    rt = []
    for n in range(len(l)):
        if n == 0:
            rate = l[n]*vNum/sum(l)
            q1.append(math.ceil(rate))
            q2.append(myRound.myRound(rate))
            rt.append(l[n] - myRound.myRound(rate))
        else:
            rate = l[n]*vNum/sum(l)
            q1n = min(math.ceil(rate), vNum - sum(q1))
            q2n = min(myRound.myRound(rate), vNum - sum(q1))
            q1.append(q1n)
            q2.append(q2n)
            rt.append(l[n] - q2n)
    qs.append(q1)
    n = vNum - sum(q2)
    if n > 0:
        addOne = pd.Series(rt).sort_values(ascending = False).index[:n]
        for i in addOne:
            q2[i] += 1
        
    if q1 != q2:
        qs.append(q2)
    return qs
    
if __name__ == '__main__':
    qs = QNew(1, [2,1,1])
    print(qs)
    qs = QAll(1, [2,1,1])
    print(qs)
    # qs = QnCeil(3, [2,3])
    # print(qs)
    # qs = QnBoth(3, [2,3])
    # print(qs)