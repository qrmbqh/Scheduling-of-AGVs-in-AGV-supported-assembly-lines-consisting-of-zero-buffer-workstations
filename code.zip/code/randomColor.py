# -*- coding: utf-8 -*-
"""
Created on Tue Oct 12 10:35:22 2021

@author: qrmbqh
"""
import random

def random_color():
     colors1 = '0123456789ABCDEF'
     num = "#"
     for i in range(6):
         num += random.choice(colors1)
     return num