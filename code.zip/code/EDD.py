# -*- coding: utf-8 -*-
"""
Created on Thu Feb 23 20:46:15 2023

@author: qrmbqh
"""

from gurobipy import *

def conveyorModel(wcc,pc,s,d,h):
    C = {}
    S = [0] + s
    T_d = [(i,j) for i in range(1,wcc+1) for j in range(1,wcc+1)]

    T = {}
    for i,j in T_d:
        if i <= j:
            T[i,j] = sum(d[i-1:j-1])
        else:
            T[i,j] = sum(d[j-1:i-1]) + 2 * h
            
    D = [(i,j) for i in range(1,wcc) for j in range(1,pc+1)]
    
    #BD定义
    b1 = [(0,j) for j in range(pc+1)]
    b2 = [(i,0) for i in range(1,wcc)]
    
    #CD定义      
    c1 = [(wcc, j) for j in range(pc + 1)]
    c2 = [(i,0) for i in range(1,wcc)]
    #定义结束的虚拟任务区域
    c_d = D + c1 + c2
    b_d = D + b1 + b2
    
    mdl = Model("Model")
    mdl.setParam('OutputFlag', 0)#是否输出log信息
    #define variables
    
    b = mdl.addVars(b_d, lb = 0, name = 'b')
    c = mdl.addVars(c_d, lb = 0, name = 'c')
    
    obj1 = LinExpr(0)
    obj1.addTerms(1, c[wcc,pc])
    
    mdl.setObjective(obj1, GRB.MINIMIZE)
    
    #8
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(-1, c[i,j])
        expr.addTerms(1, c[i+1,j-1])
        mdl.addConstr(expr <= T[i,i+1])
       
    #9
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(-1, c[i,j])
        expr.addTerms(1, c[i+1,j])
        mdl.addConstr(expr >= T[i,i+1] + S[i+1])
    
    for i,j in D:
            expr = LinExpr(0)
            expr.addTerms(1, c[i,j])
            expr.addTerms(-1, c[i,j-1])
            mdl.addConstr(expr >= S[i])
    #10
    for i,j in D:
        expr = LinExpr(0)
        expr.addTerms(1, b[i,j])
        expr.addTerms(-1, c[i,j])
        mdl.addConstr(expr >= T[i,i+1])
    
    #13 
    for i,j in D:
        mdl.addConstr(c[i+1,j] >= b[i,j])
        
    for i,j in D:
        mdl.addConstr(b[i-1,j] >= c[i,j-1])
    
    mdl.setParam(GRB.Param.PoolGap, 0)
    mdl.setParam("PoolSearchMode", 0)
    mdl.optimize()
    for w in range(wcc):
        for p in range(pc):
            C[w,p] = c[w+1,p+1].x
    return C

def Heuristic(workStations, AGVs, tasks, Roads, time, T, C):
    x_d = []
    wc = len(workStations)
    ws = []
    ag = []
    noSpecialW = []#所有可以分配AGV的工位
    specialW = []#有AGV正在载货前往的工位
    for workstation in workStations:
        if workstation.id < wc-1:
            if workstation.status == 1 or workstation.status == 3:
                noSpecialW.append(workstation.id)
    
    for road in Roads:
        if road.status == 1:
            # ws.append(road.id + 1)
            specialW.append(road.id + 1)
    #找到所有可以分配的AGV，自由AGV
    for agv in AGVs:
        if agv.status == 3:
            ag.append(agv.id)
    #如果没有一般可分配的工位，那AGV都不需要了，直接返回
    if len(noSpecialW) == 0:
        for a in ag:
            if AGVs[a].presentLoc.id == wc-1:
                if AGVs[a].presentLoc.presentProd == None:
                    AGVs[a].presentLoc.status = 0
                else:
                    AGVs[a].presentLoc.status = 1
            else:
                AGVs[a].presentLoc.status = 1
            AGVs[a].presentLoc = None
            AGVs[a].status = -1
        return
    #AGV进入系统的机制
    for agv in AGVs:
        if len(ag) < len(noSpecialW) and agv.status == -1:
            agv.presentLoc = workStations[0]
            agv.status = 3
            ag.append(agv.id)
    #定义域
    ws = noSpecialW + specialW   
    for a in ag:
        for w in ws:
            x_d.append((AGVs[a].presentLoc.id, w))
            
    # print(ag, ws,x_d)
    if len(x_d) > 0:
        m = Model("model")
        m.setParam('OutputFlag',0)
        x = m.addVars(x_d, vtype = GRB.BINARY, name = 'x')
        obj = LinExpr(0)
        for w in ws:
            if w not in specialW:
                for a in ag:
                    obj.addTerms(C[w, workStations[w].presentProd.id], x[AGVs[a].presentLoc.id, w])
                
        m.setObjective(obj, GRB.MINIMIZE)
        if len(ag) > len(noSpecialW):
            for a in ag:
                expr = LinExpr(0)
                for w in ws:
                    expr.addTerms(1, x[AGVs[a].presentLoc.id, w])
                m.addConstr(expr <= 1)
                
            for w in noSpecialW:
                expr = LinExpr(0)
                for a in ag:
                    expr.addTerms(1, x[AGVs[a].presentLoc.id, w])
                m.addConstr(expr == 1)
            
            for w in specialW:
                expr = LinExpr(0)
                for a in ag:
                    expr.addTerms(1, x[AGVs[a].presentLoc.id, w])
                m.addConstr(expr == 0)

            for w in ws:
                if w-1 in ws:
                    expr1 = LinExpr(0)
                    expr2 = LinExpr(0)
                    for a in ag:
                        expr1.addTerms(1, x[AGVs[a].presentLoc.id, w])
                        expr2.addTerms(1, x[AGVs[a].presentLoc.id, w - 1])
                    m.addConstr(expr1 >= expr2)
        else:
            for a in ag:
                expr = LinExpr(0)
                for w in noSpecialW:
                    expr.addTerms(1, x[AGVs[a].presentLoc.id, w])
                m.addConstr(expr == 1)
                
            for w in ws:
                expr = LinExpr()
                for a in ag:
                    expr.addTerms(1, x[AGVs[a].presentLoc.id, w])
                m.addConstr(expr <= 1)

            for w in specialW:
                expr = LinExpr(0)
                for a in ag:
                    expr.addTerms(1, x[AGVs[a].presentLoc.id, w])
                m.addConstr(expr == 0)
                
            for w in ws:
                if w-1 in ws:
                    expr1 = LinExpr(0)
                    expr2 = LinExpr(0)
                    for a in ag:
                        expr1.addTerms(1, x[AGVs[a].presentLoc.id, w])
                        expr2.addTerms(1, x[AGVs[a].presentLoc.id, w - 1])
                    m.addConstr(expr1 >= expr2)
                    
        m.optimize()
        try:
            for a in ag:
                tag = 0
                for w in ws:
                    if x[AGVs[a].presentLoc.id, w].x > 0.5:
                        tasks[workStations[w].id, workStations[w].presentProd.id].status = 1
                        tasks[workStations[w].id, workStations[w].presentProd.id].agv = AGVs[a]
                        workStations[w].status = 4
                        AGVs[a].LeaveWorkStation(workStations[w], tasks, T, time, wc)
                        tag = 1
                        break
                if tag == 0:
                    if AGVs[a].presentLoc.id == wc-1:
                        if AGVs[a].presentLoc.presentProd == None:
                            AGVs[a].presentLoc.status = 0
                        else:
                            AGVs[a].presentLoc.status = 1
                    else:
                        if AGVs[a].presentLoc.status != 4:
                            AGVs[a].presentLoc.status = 1
                    AGVs[a].presentLoc = None
                    AGVs[a].status = -1
        except:
            return
    workStations[0].timeToFree(workStations, tasks, Roads)