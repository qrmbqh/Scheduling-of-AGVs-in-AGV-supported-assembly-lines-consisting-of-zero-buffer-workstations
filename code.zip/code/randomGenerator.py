# -*- coding: utf-8 -*-
"""
Created on Thu Jan 23 14:32:52 2025

@author: 74110
"""

import numpy as np
import math

def generate_random_numbers(n, mean, variance):
    # 根据均值和方差反推范围 [a, b]
    range_width = math.sqrt(12 * variance + 1) - 1
    a = int(math.ceil(mean - range_width / 2))
    b = int(math.floor(mean + range_width / 2))
    
    # 确保范围是正整数
    a = max(1, a)
    
    # 生成随机正整数
    random_integers = list(np.random.randint(a, b + 1, size=n))
    return random_integers


def random_nums(n, low, high):
    """
    生成符合均匀分布的随机正整数。
    
    参数：
    - low: 整数，范围的下界（包含）。
    - high: 整数，范围的上界（包含）。
    - n: 整数，要生成的随机正整数个数。
    
    返回：
    - 一个数组，包含 n 个符合均匀分布的随机正整数。
    """
    if low < 1:
        raise ValueError("下界必须为正整数")
    if low > high:
        raise ValueError("下界必须小于或等于上界")
    
    # 使用 np.random.randint 生成随机整数
    random_integers = list(np.random.randint(low, high + 1, size=n))
    return random_integers